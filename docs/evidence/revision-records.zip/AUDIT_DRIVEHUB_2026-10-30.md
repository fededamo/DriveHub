# Audit DriveHub — 30 ottobre 2026

## Ambito e risultato

DriveHub è un’applicazione desktop JavaFX per gestire un concessionario: catalogo, acquisti, vendita di auto alla concessionaria, noleggi e test drive. Usa PostgreSQL e distingue clienti, venditori e manager. Il carico assunto è di poche istanze desktop contemporanee sullo stesso database, come in una dimostrazione universitaria.

**La base architetturale è sensata, ma il progetto presenta difetti funzionali importanti prima di poter essere considerato affidabile per l’esame.** I problemi principali riguardano denaro, stati dei veicoli e concorrenza.

La cartella `DriveHub/Relazione_SWE` è esclusa dalla valutazione. Il confronto didattico usa il disciplinare `NotesOnTheProjectWork_Jan2025.pdf` e le parti pertinenti delle slide su pattern, testing, UML e casi d’uso presenti in `Slides and notes - academic year 202526-20261020`. Il disciplinare fornito riporta internamente l’A.A. 2024/25.

Questo documento riporta l’audit già svolto: non attesta che i difetti siano stati corretti.

## Verifiche svolte

- Compilazione diretta di sorgenti e test con `javac -Xlint:all`: riuscita, senza avvisi.
- Test unitari di dominio e prezzi: **14 superati su 14**.
- Prove temporanee con DAO simulati: **13 controlli superati**, comprendenti la riproduzione di diversi difetti descritti sotto.
- Maven: bloccato da un plugin assente nella cache e dalla rete non disponibile. L’ambiente ha Java 17; il progetto dichiara Java 21.
- PostgreSQL configurato non raggiungibile; JavaFX non avviabile per indisponibilità del display.

La repository è rimasta invariata durante l’audit. Le prove temporanee sono state salvate in `/tmp/drivehub-review-20261030`; la loro permanenza non è garantita, trattandosi di una directory temporanea.

I casi di concorrenza descritti sotto derivano dall’analisi del codice e delle query, senza una prova simultanea su PostgreSQL reale. Le prove con DAO simulati verificano il comportamento dei servizi, non i vincoli e l’isolamento del database reale.

## Must fix — difetti funzionali e rischi sui dati

### 1. La suite può cancellare il database dell’applicazione

Riferimento: [DemoSqlValidationTest.java](DriveHub/src/test/java/it/unifi/drivehub/DemoSqlValidationTest.java), da riga 24.

- **Cos’è:** Un test esegue `demo.sql` usando la configurazione ordinaria dell’applicazione.
- **Problema:** Lo script comincia cancellando tutte le operazioni, gli utenti e il catalogo, poi esegue il commit. Un normale `mvn test` può quindi sostituire i dati del database configurato.
- **Correzione:** Usare un database di test separato, con configurazione esplicita e inizializzazione della fixture.
- **Se rimane:** L’esecuzione dei test può distruggere dati inseriti durante sviluppo o dimostrazione. Non ho eseguito questo test.

### 2. Una proposta di vendita può sovrascrivere un’auto del concessionario

Riferimento: [SaleToDealershipService.java](DriveHub/src/main/java/it/unifi/drivehub/service/SaleToDealershipService.java), da riga 72.

- **Cos’è:** Il cliente propone un veicolo indicando il VIN, cioè il numero di telaio.
- **Problema:** Se il VIN esiste, il servizio aggiorna targa, chilometri, prezzo e stato senza verificare disponibilità e titolarità. Ho riprodotto il passaggio di un’auto già `SALE` a `WAITING`.
- **Correzione:** Accettare il riutilizzo soltanto per un veicolo precedentemente venduto al cliente proponente, verificando stato e storico nella transazione.
- **Se rimane:** Un cliente può alterare l’inventario usando un VIN presente nel catalogo e proporre alla concessionaria un’auto che possiede già.

### 3. Lo stesso veicolo può essere pagato due volte

Riferimento: [SaleToDealershipService.java](DriveHub/src/main/java/it/unifi/drivehub/service/SaleToDealershipService.java), da riga 93.

- **Cos’è:** Ogni proposta genera una richiesta distinta, successivamente approvabile.
- **Problema:** Si possono creare due proposte sullo stesso VIN e approvarle entrambe. La prova ha prodotto due acquisti della concessionaria e due accrediti da 16.000 euro.
- **Correzione:** Impedire più richieste aperte per veicolo anche nel database; all’approvazione verificare nuovamente richiesta e stato `WAITING`.
- **Se rimane:** La concessionaria paga più volte per acquisire una sola auto, anche senza operazioni simultanee.

### 4. Due operazioni possono perdere un aggiornamento del saldo

Riferimento: [PostgresBankAccountDao.java](DriveHub/src/main/java/it/unifi/drivehub/dao/postgres/PostgresBankAccountDao.java), da riga 32.

- **Cos’è:** I servizi leggono il saldo, lo modificano in Java e riscrivono il valore completo.
- **Problema:** Due transazioni possono leggere entrambe 1.000 euro e addebitare 100 e 200 euro, lasciando 900 oppure 800 euro invece di 700. La lettura non blocca il conto.
- **Correzione:** Leggere il conto con `SELECT … FOR UPDATE` nelle transazioni, oppure aggiornare il saldo direttamente in SQL con controllo del saldo disponibile.
- **Se rimane:** Pagamenti, ricariche e rimborsi possono produrre saldi errati.

### 5. Le transazioni non impediscono prenotazioni concorrenti incompatibili

Riferimento: [RentalService.java](DriveHub/src/main/java/it/unifi/drivehub/service/RentalService.java), da riga 81; [TestDriveService.java](DriveHub/src/main/java/it/unifi/drivehub/service/TestDriveService.java), da riga 37.

- **Cos’è:** Noleggi e test drive controllano la disponibilità prima dell’inserimento.
- **Problema:** Due transazioni possono vedere contemporaneamente libero lo stesso periodo e inserire entrambi i noleggi. Analogamente, due prenotazioni possono superare il limite di tre test drive del cliente; mancano blocchi condivisi sui controlli.
- **Correzione:** Bloccare le righe di veicolo e cliente necessarie prima delle verifiche, con ordine coerente fra operazioni; proteggere inoltre le sovrapposizioni nel database.
- **Se rimane:** Poche sessioni simultanee bastano per generare prenotazioni impossibili. Questo riscontro deriva dall’analisi delle query; non è stato eseguito contro PostgreSQL.

### 6. Una richiesta può essere elaborata più volte da sessioni concorrenti

Riferimento: [PurchaseService.java](DriveHub/src/main/java/it/unifi/drivehub/service/PurchaseService.java), da riga 148.

- **Cos’è:** Completamento, rifiuto e scadenza spostano denaro e cancellano la richiesta.
- **Problema:** La richiesta viene letta senza blocco e la cancellazione non verifica quante righe ha eliminato. Il controllo delle scadenze usa inoltre oggetti letti prima della transazione: due sessioni possono elaborare la stessa richiesta.
- **Correzione:** Rileggere e bloccare la richiesta nella transazione, verificandone lo stato prima di ogni movimento economico.
- **Se rimane:** Possono comparire vendite duplicate, rimborsi ripetuti o conflitti fra pagamento e rifiuto.

### 7. Il cambio di stato può rimettere in commercio auto vendute o riservate

Riferimento: [RentalService.java](DriveHub/src/main/java/it/unifi/drivehub/service/RentalService.java), da riga 118.

- **Cos’è:** Il venditore può alternare un veicolo fra vendita e noleggio.
- **Problema:** Il servizio controlla lo stato richiesto, ma non quello di partenza. Ho riprodotto `SOLD → SALE` e `BLOCKED → RENT`; inoltre un noleggio iniziato ieri non viene annullato dal filtro sulle prenotazioni future.
- **Correzione:** Consentire soltanto le transizioni previste dallo stato corrente, sotto blocco, e impedire il passaggio alla vendita durante un noleggio in corso.
- **Se rimane:** Una schermata rimasta aperta può rendere nuovamente disponibile un’auto già assegnata a qualcuno.

### 8. Il cambio email può rendere inutilizzabile l’account

Riferimento: [AuthService.java](DriveHub/src/main/java/it/unifi/drivehub/service/AuthService.java), da riga 67.

- **Cos’è:** La gestione account aggiorna l’indirizzo email.
- **Problema:** Il servizio salva prima della validazione del dominio. `a b@c.it` supera il controllo SQL, ma viene rifiutato quando l’utente viene ricostruito al login; ho riprodotto questa divergenza.
- **Correzione:** Applicare la stessa validazione del dominio prima dell’aggiornamento e del commit.
- **Se rimane:** L’utente perde l’accesso e serve una correzione manuale nel database.

### 9. La cancellazione account salta i controlli sullo storico

Riferimento: [PostgresUserDao.java](DriveHub/src/main/java/it/unifi/drivehub/dao/postgres/PostgresUserDao.java), da riga 212.

- **Cos’è:** Il DAO dovrebbe impedire la cancellazione di utenti con operazioni associate.
- **Problema:** La UI passa `Cliente` e `Venditore`, mentre il controllo riconosce soltanto `CLIENT` e `SALESMAN`. Per un venditore con sole vendite concluse, la cancellazione può riuscire e azzerare il riferimento nelle vendite tramite `ON DELETE SET NULL`.
- **Correzione:** Normalizzare il ruolo una volta e usare la stessa rappresentazione in tutti i metodi; includere anche le richieste del cliente.
- **Se rimane:** Si perde l’attribuzione storica delle operazioni al venditore.

### 10. Il registro contabile confonde acquisti e vendite

Riferimento: [Sale.java](DriveHub/src/main/java/it/unifi/drivehub/domain/operation/Sale.java), da riga 49.

- **Cos’è:** `Sale` registra sia le vendite ai clienti sia gli acquisti dalla clientela.
- **Problema:** Entrambe le factory producono importi positivi. La dashboard manager identifica invece gli acquisti dal cliente attraverso un importo negativo: un’acquisizione viene quindi mostrata come vendita.
- **Correzione:** Uniformare il segno alla convenzione usata dalla dashboard: negativo per il pagamento al cliente, positivo per l’incasso.
- **Se rimane:** Il registro presenta una direzione economica sbagliata e non permette di distinguere correttamente le operazioni.

### 11. Il prezzo concordato cambia dopo il pagamento dell’acconto

Riferimento: [PurchaseService.java](DriveHub/src/main/java/it/unifi/drivehub/service/PurchaseService.java), da riga 164.

- **Cos’è:** Il cliente versa il 20% e paga il saldo dopo l’approvazione.
- **Problema:** Al saldo il prezzo viene ricalcolato usando gli sconti e l’anno correnti. Ho riprodotto un acquisto iniziale da 20.000 euro, con 4.000 euro di acconto, concluso a 10.000 euro dopo una modifica dello sconto.
- **Correzione:** Memorizzare il totale concordato quando viene versato l’acconto e calcolare il saldo da quel totale.
- **Se rimane:** Il saldo non corrisponde più al restante 80% dell’accordo iniziale.

### 12. La cancellazione obbligatoria dei test drive può fallire dopo il pagamento

Riferimento: [VehicleEventPublisher.java](DriveHub/src/main/java/it/unifi/drivehub/event/VehicleEventPublisher.java), da riga 28.

- **Cos’è:** Un Observer annulla i test drive futuri dopo vendita o noleggio.
- **Problema:** La notifica avviene dopo il commit; l’Observer apre un’altra transazione e il publisher nasconde eventuali errori. Ho verificato che il noleggio restituisce successo anche quando la cancellazione fallisce.
- **Correzione:** Eseguire la cancellazione obbligatoria nella stessa transazione dell’operazione e propagare l’errore.
- **Se rimane:** Il cliente paga, ma il veicolo può conservare prenotazioni incompatibili senza che l’interfaccia lo segnali.

## Should fix — test, manutenibilità e coerenza con il corso

### 13. Il test denominato “FullWorkflow” non verifica i flussi completi

Riferimento: [FullWorkflowIntegrationTest.java](DriveHub/src/test/java/it/unifi/drivehub/FullWorkflowIntegrationTest.java), da riga 29.

- **Cos’è:** È il principale test di integrazione applicativo presente.
- **Problema:** Verifica soprattutto login e caricamento dati; non attraversa acquisto completo, proposta accettata/rifiutata, rimborso e fallimento con rollback. I difetti precedenti possono quindi restare anche con questi test verdi.
- **Correzione:** Aggiungere test dei servizi per percorsi normali e alternativi, identificati con i casi d’uso; separare le prove PostgreSQL da quelle con DAO simulati.
- **Se rimane:** Manca la dimostrazione funzionale richiesta dal disciplinare nelle parti dedicate a controller di business, casi alternativi e DAO.

### 14. Anche docs descrive una versione diversa dal codice attuale

Riferimento: [package-diagram.puml](DriveHub/docs/diagrams/package-diagram.puml), da riga 10; [source-manifest.json](DriveHub/docs/evidence/full-stack/source-manifest.json).

- **Cos’è:** Diagrammi e risultati di test dovrebbero documentare il progetto consegnato.
- **Problema:** Compaiono `ServiceUiGateway`, `CheckoutService`, FXML e stati `AVAILABLE/RESERVED`, assenti nell’implementazione attuale. Nei due manifest delle evidenze, **149 percorsi su 150 non esistono più** e il `pom.xml` ha un hash diverso.
- **Correzione:** Archiviare chiaramente le evidenze precedenti e aggiornare i diagrammi alla struttura e ai flussi attuali.
- **Se rimane:** La documentazione contraddice il codice e i vecchi risultati non dimostrano la qualità della versione consegnata.

### 15. Le istruzioni non consentono di preparare un’installazione pulita

Riferimento: [README.md](DriveHub/README.md), da riga 67.

- **Cos’è:** Il README presenta JDK e Maven come prerequisiti e indica `mvn javafx:run`.
- **Problema:** L’applicazione richiede anche un database già creato, con schema, dati e credenziali corretti. Il bootstrap non prepara automaticamente questi elementi.
- **Correzione:** Documentare creazione del database, configurazione, inizializzazione dello schema e caricamento facoltativo dei dati dimostrativi.
- **Se rimane:** Un docente o compagno con una copia pulita non riesce a riprodurre la dimostrazione seguendo il README.

### 16. Il rendering delle tabelle esegue query sul thread grafico

Riferimento: [ClientDashboardView.java](DriveHub/src/main/java/it/unifi/drivehub/presentation/view/ClientDashboardView.java), da riga 516.

- **Cos’è:** Le celle calcolano descrizione e prezzo richiamando i servizi.
- **Problema:** Per una riga valutata vengono effettuate più query e aperte nuove connessioni; il rendering può ripeterle. Le chiamate avvengono sul thread JavaFX, quindi una query lenta blocca anche l’interfaccia.
- **Correzione:** Caricare dati, modelli e sconti per aggiornamento della tabella, preparare i valori fuori dal thread grafico e lasciare alle celle soltanto la visualizzazione.
- **Se rimane:** Anche un catalogo universitario contenuto può produrre attese e finestre apparentemente bloccate.

### 17. Il prezzo inserito dal manager non determina il prezzo applicato

Riferimento: [PriceCalculatorService.java](DriveHub/src/main/java/it/unifi/drivehub/service/PriceCalculatorService.java), da riga 26.

- **Cos’è:** Il manager inserisce un prezzo specifico quando aggiunge un veicolo.
- **Problema:** Il calcolo usa sempre `model.releasePrice` e ignora `vehicle.price`. Nella prova, impostare 1.234 euro sul veicolo ha lasciato il prezzo calcolato a 20.000 euro.
- **Correzione:** Coerentemente con la formula descritta nel README, rendere il prezzo del veicolo un valore calcolato e togliere l’inserimento manuale ingannevole.
- **Se rimane:** Il manager crede di impostare un prezzo che non viene applicato.

### 18. Le factory statiche sono presentate come GoF Factory Method

Riferimento: [README.md](DriveHub/README.md), da riga 17.

- **Cos’è:** `Vehicle.create()`, `Client.create()` e metodi analoghi centralizzano costruzione e validazione.
- **Problema:** Sono factory statiche; manca la delega polimorfica fra Creator e ConcreteCreator mostrata nelle slide del corso sul Factory Method.
- **Correzione:** Descriverle con il nome corretto e motivare separatamente Observer e Visitor effettivamente presenti.
- **Se rimane:** Durante l’orale la spiegazione del pattern non corrisponde alla sua struttura nel codice e nelle slide.

### 19. Un setter lascia l’entità invalida quando fallisce

Riferimento: [Vehicle.java](DriveHub/src/main/java/it/unifi/drivehub/domain/vehicle/Vehicle.java), da riga 81.

- **Cos’è:** `setLicencePlate()` dovrebbe preservare il vincolo fra targa e chilometri.
- **Problema:** Assegna la nuova targa prima di validare. Ho verificato che rimuovere la targa da un veicolo con 100 km solleva un’eccezione ma lascia comunque `targa = null` e `km = 100`.
- **Correzione:** Normalizzare in una variabile locale, verificare il vincolo e assegnare soltanto dopo il controllo.
- **Se rimane:** Chi intercetta l’eccezione può continuare a usare un oggetto che viola gli invarianti dichiarati.

## Nice to have — riduzioni semplici

### 20. Sono rimasti una dipendenza e uno stato di sessione inutilizzati

Riferimento: [pom.xml](DriveHub/pom.xml), da riga 29; [AppContext.java](DriveHub/src/main/java/it/unifi/drivehub/AppContext.java), da riga 154.

- **Cos’è:** Il progetto include `javafx-fxml` e mantiene `currentUser` con getter, setter e logout.
- **Problema:** La UI corrente viene costruita in Java e non usa FXML; nessun chiamante corrente usa quello stato di sessione.
- **Correzione:** Eliminare la dipendenza e i membri inutilizzati, compreso l’import rimasto superfluo.
- **Se rimane:** Si mantengono componenti che fanno apparire disponibile un’infrastruttura non usata dal programma.

## Verdetto e limiti

**Verdict:** buona base per un progetto SWE, ma prima della consegna correggere gestione dei dati di test, denaro e transizioni; poi dimostrare i flussi con test ripetibili e riallineare i diagrammi.

**Lean:** almeno **−16 righe e −1 dipendenza** eliminabili immediatamente.

**Not checked:** esecuzione completa con JDK 21 e Maven, comportamento reale delle transazioni concorrenti su PostgreSQL, interazione grafica e accessibilità della UI, rendering completo dei diagrammi. `Relazione_SWE` esclusa; non ho valutato la completezza della specifica e dei template eventualmente contenuti lì.
