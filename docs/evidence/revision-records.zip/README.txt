Fotografia dei registri esterni delle revisioni DriveHub.
Gli originali di lavoro restano esterni al repository.
Per ripristinare i percorsi relativi, estrarre nella directory genitore di DriveHub, senza sovrascrivere registri locali piu recenti.
I metadati iniziali di specifica/proposta/README del tracker restano storici: il piano e i singoli ticket riportano gli esiti finali.
Relazione_SWE e materiali didattici esclusi.
