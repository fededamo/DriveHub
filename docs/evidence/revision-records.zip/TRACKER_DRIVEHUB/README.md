# Tracker DriveHub

Tracker Markdown locale esterno al repository del progetto, scelto dall'utente.

- [Piano, decisioni e avanzamento](../PIANO_REVISIONI_DRIVEHUB.md).
- [Convenzioni del tracker](../DriveHub/docs/agents/issue-tracker.md).
- [Documentazione del dominio](../DriveHub/docs/agents/domain.md).

## Revisioni

Intervento: `revisioni/`.

- [Specifica delle revisioni](revisioni/spec.md): pubblicata da `to-spec`, con `Status: ready-for-agent` e `State: open`.
- [Indice dei 18 ticket](revisioni/proposta-ticket.md): suddivisione e dipendenze approvate, un file per ticket con `Status: ready-for-agent` e `State: open`.
- [Primo ticket: ambiente e test isolati](revisioni/issues/01-ambiente-e-test-isolati.md): unico inizialmente senza blocchi, corrisponde a R00 del piano.

Specifica e ticket sono pubblicati; implementazione non ancora avviata. Prossima skill: `implement` sul ticket 01 / R00. Il registro generale resta la fonte dell'avanzamento complessivo; non mantiene copie dei test o risultati non eseguiti.

Questo tracker e il piano, essendo esterni a `DriveHub/`, non sono versionati dal repository del progetto. `Relazione_SWE` resta esclusa.
