# Specifica — Correzione e consolidamento di DriveHub

Status: ready-for-agent
State: open
Data: 31 ottobre 2026

Sintesi del piano e delle decisioni già approvate. La specifica è pronta per la suddivisione in ticket; non attesta implementazione o test superati.

## Problem Statement

DriveHub deve permettere a clienti, venditori e manager di dimostrare acquisti, cessioni, noleggi e test drive con importi e stati coerenti, anche quando poche istanze desktop operano contemporaneamente sullo stesso database. I difetti individuati negli audit possono invece produrre pagamenti duplicati, aggiornamenti persi del conto, variazioni del prezzo dopo l'acconto, sovrascrittura di veicoli altrui e prenotazioni incompatibili.

Le verifiche attuali non dimostrano sistematicamente i flussi e le alternative; alcuni test possono modificare i dati applicativi. Il rendering delle tabelle può bloccare l'interfaccia e una parte della documentazione descrive una versione precedente o usa etichette teoriche imprecise. L'autore del progetto deve poter correggere e verificare il lavoro per passi, sapendo quali problemi siano ancora aperti.

## Solution

Correggere i 20 rilievi preservando l'architettura JavaFX, servizi, dominio e DAO con PostgreSQL. Isolare prima i test; poi rendere atomiche e sicure sotto concorrenza le operazioni economiche, le prenotazioni e le transizioni. Ogni intervento comprende i chiamanti, la persistenza, le fixture e la documentazione interessati.

Offrire sia il prezzo consigliato sia una base manuale del manager. Applicare a entrambe la formula esistente e fissare il totale dell'acquisto al versamento dell'acconto. Usare prove osservabili dei percorsi normali, alternativi e di errore, aggiornando il registro generale senza conteggiare come riuscite verifiche non eseguite.

La documentazione della relazione universitaria è esclusa e resta a cura dell'utente. Piano, specifica e ticket sono conservati nel tracker locale esterno al progetto, come richiesto.

## User Stories

1. Come sviluppatore, voglio compilare e verificare il progetto con Java 21, così da rispettare il requisito dichiarato senza abbassarlo per adattarlo all'ambiente corrente.
2. Come sviluppatore, voglio che i test che scrivono dati usino un database dedicato esplicitamente configurato, così da non cancellare i dati applicativi per errore.
3. Come sviluppatore, voglio che una configurazione di test non sicura venga rifiutata prima delle scritture distruttive, così da separare realmente test e applicazione.
4. Come sviluppatore, voglio ricreare schema e fixture di test in modo ripetibile, così da ottenere prove indipendenti dall'ordine e dai dati di una demo precedente.
5. Come sviluppatore, voglio distinguere prove senza database e prove PostgreSQL, così da sapere che cosa è stato verificato e che cosa manca.
6. Come cliente, voglio che un cambio email non valido venga rifiutato senza modificare i miei dati, così da conservare l'accesso precedente.
7. Come utente, voglio che la normalizzazione e i controlli dell'email siano coerenti con quelli dell'accesso e del dominio, così da non salvare un'identità inutilizzabile.
8. Come manager, voglio che una modifica non valida di un veicolo lasci invariati i dati precedenti, così da poter correggere l'errore senza usare un oggetto invalido.
9. Come cliente, voglio che addebiti e accrediti concorrenti mantengano il saldo corretto del conto dimostrativo, così da non perdere movimenti economici.
10. Come cliente, voglio che un pagamento senza disponibilità sufficiente fallisca senza effetti parziali, così da non ritrovarmi con saldo negativo o operazioni incomplete.
11. Come manager, voglio vedere il prezzo consigliato del veicolo, così da disporre di una valutazione basata sulle regole esistenti.
12. Come manager, voglio scegliere una base manuale per il singolo veicolo, così da sostituire la base del modello mantenendo la stessa formula di valutazione.
13. Come manager, voglio distinguere nell'interfaccia la base manuale dal prezzo effettivo, così da sapere quali sconti e svalutazioni incidono sul risultato.
14. Come manager, voglio tornare alla modalità consigliata, così da ripristinare la valutazione a partire dalla base del modello.
15. Come manager, voglio che la modalità di prezzo scelta sopravviva a salvataggio e rilettura, così da non cambiare significato tra due sessioni.
16. Come cliente, voglio vedere un prezzo effettivo coerente con la modalità selezionata, così da non pagare un importo calcolato ignorando la base manuale.
17. Come cliente, voglio che il preventivo di noleggio usi la valutazione corretta del veicolo, così da avere prezzi coerenti tra catalogo e prenotazione.
18. Come cliente, voglio ricevere una stima della cessione secondo le regole già previste, così da distinguere la mia proposta dalla successiva scelta commerciale del manager.
19. Come cliente, voglio riservare un veicolo disponibile versando l'acconto del 20%, così da avviare un acquisto senza renderlo prenotabile da un altro cliente.
20. Come cliente, voglio che il totale concordato venga fissato al versamento dell'acconto, così da non subire modifiche successive di base, sconti o anno di calcolo.
21. Come venditore, voglio autorizzare una richiesta di acquisto secondo il flusso esistente, così da abilitare il saldo entro la scadenza prevista.
22. Come cliente, voglio pagare la differenza tra totale concordato e acconto, così da completare l'acquisto per l'importo pattuito.
23. Come cliente, voglio che il saldo senza approvazione o dopo la scadenza venga rifiutato anche dal servizio, così da mantenere le regole indipendenti dalla schermata usata.
24. Come cliente, voglio che il rifiuto dell'acquisto restituisca l'acconto secondo il comportamento esistente, così da non perdere denaro per una richiesta non accettata.
25. Come cliente, voglio che la scadenza applichi una sola volta la penale e il rimborso previsti, così da non ricevere rimborsi duplicati o trattenute ripetute.
26. Come concessionaria, voglio che saldo, rifiuto e scadenza concorrenti elaborino una richiesta una sola volta, così da evitare vendite e movimenti economici duplicati.
27. Come concessionaria, voglio che vendita e cancellazione obbligatoria dei test drive siano atomiche, così da non dichiarare venduto un veicolo lasciando prenotazioni incompatibili.
28. Come cliente, voglio proporre un veicolo con VIN non ancora presente, così da poterlo cedere alla concessionaria come nel flusso esistente.
29. Come cliente, voglio poter riproporre un veicolo già registrato solo se risulta venduto a me nell'ultima vendita, così da tutelare i veicoli della concessionaria e degli altri clienti.
30. Come concessionaria, voglio una sola richiesta aperta per veicolo, così da non acquisire e pagare più volte la stessa auto.
31. Come venditore, voglio che l'accettazione di una cessione verifichi ancora richiesta e stato del veicolo, così da impedire approvazioni obsolete o duplicate.
32. Come cliente, voglio ricevere un solo accredito per una cessione accettata, così da avere un pagamento coerente con l'operazione conclusa.
33. Come venditore, voglio rifiutare una cessione senza perdere lo storico di un veicolo già venduto, così da mantenere corretti inventario e attribuzioni precedenti.
34. Come manager, voglio distinguere entrate e uscite della concessionaria nel registro economico, così da riconoscere vendite ai clienti, acquisizioni e penali.
35. Come cliente, voglio prenotare solo periodi di noleggio disponibili, così da non condividere il veicolo con una prenotazione incompatibile.
36. Come concessionaria, voglio che richieste concorrenti non superino i controlli di disponibilità, così da mantenere le prenotazioni valide anche da più istanze desktop.
37. Come venditore, voglio cambiare la destinazione soltanto tra vendita e noleggio negli stati ammessi, così da non riaprire veicoli venduti, riservati o in attesa di valutazione.
38. Come cliente, voglio che un noleggio già in corso impedisca il passaggio del veicolo alla vendita, così da conservare la disponibilità per il periodo assegnato.
39. Come cliente, voglio un rimborso integrale dei noleggi futuri cancellati per destinare il veicolo alla vendita, così da non pagare un servizio che non riceverò.
40. Come concessionaria, voglio che cambio destinazione, cancellazioni e rimborsi riescano insieme, così da non lasciare prenotazioni eliminate senza rimborso.
41. Come cliente, voglio prenotare test drive rispettando disponibilità, orari e limite di tre prenotazioni attive, così da seguire le regole esistenti anche con richieste concorrenti.
42. Come concessionaria, voglio che test drive e noleggi concorrenti rispettino la priorità commerciale, così da non lasciare prenotazioni incompatibili.
43. Come cliente, voglio che la conferma di un noleggio annulli tutti i test drive futuri del veicolo, così da rispettare la regola commerciale concordata.
44. Come concessionaria, voglio conservare i test drive già avvenuti, così da non perdere lo storico durante una cancellazione dei futuri.
45. Come cliente, voglio che un errore nella cancellazione obbligatoria dei test drive faccia fallire anche l'operazione economica collegata, così da non ricevere un successo incompleto.
46. Come cliente, voglio che le richieste e le operazioni associate impediscano una cancellazione dell'identità non consentita, così da mantenere lo storico coerente.
47. Come venditore, voglio che le mie vendite concluse mantengano l'attribuzione anche durante una richiesta di cancellazione dell'identità, così da non perdere la responsabilità storica.
48. Come utente, voglio che i controlli di cancellazione interpretino coerentemente il ruolo mostrato dall'interfaccia, così da non aggirare i vincoli attraverso una diversa denominazione.
49. Come utente, voglio scorrere il catalogo senza query eseguite dalle celle, così da mantenere l'interfaccia reattiva.
50. Come utente, voglio ricevere un esito chiaro dei caricamenti e poter riprovare dopo un errore, così da non restare davanti a una finestra bloccata o a dati obsoleti.
51. Come utente, voglio che i controlli grafici modificati restino comprensibili e utilizzabili da tastiera, così da non perdere accessibilità durante le correzioni.
52. Come sviluppatore, voglio test dei flussi principali e alternativi con risultati osservabili, così da individuare regressioni che il solo caricamento dei dati non dimostra.
53. Come valutatore, voglio collegare ogni regola al componente responsabile e al test pertinente, così da verificare il percorso requisiti, progetto e verifica.
54. Come autore del progetto, voglio diagrammi coerenti con le classi, gli stati e i flussi consegnati, così da poter spiegare l'implementazione reale.
55. Come autore del progetto, voglio descrivere pattern e principi con nomi corretti ed esempi concreti, così da motivare benefici e compromessi durante l'esame.
56. Come valutatore, voglio istruzioni per un'installazione pulita e per eseguire le prove, così da riprodurre la dimostrazione senza presupporre un database già preparato.
57. Come sviluppatore, voglio risultati di verifica riferibili alla versione corrente e vecchie evidenze identificate come storiche, così da non attribuire al codice attuale risultati di un'altra versione.
58. Come sviluppatore, voglio eliminare dipendenze e membri realmente inutilizzati senza cambiare comportamenti, così da mantenere il progetto più semplice da comprendere.
59. Come autore del progetto, voglio un registro aggiornato di decisioni, attività, prove e limiti, così da riprendere il lavoro senza ricostruire la conversazione.

## Implementation Decisions

- **Perimetro e architettura.** Mantenere stack, separazione fra presentazione, servizi, dominio e DAO, e componenti esistenti. Nessuna riscrittura o dipendenza aggiunta per risolvere pochi casi. Le modifiche raggiungono tutti i chiamanti, mapping, fixture e diagrammi coinvolti.
- **Ambiente.** Il requisito resta Java 21. Predisporre un ambiente di build utilizzabile e un PostgreSQL dedicato ai test prima di certificare le correzioni. Il database applicativo è ricreabile, ma solo dopo averne identificato esplicitamente la destinazione; la separazione dai test resta obbligatoria.
- **Invarianti ed email.** Validare prima di modificare oggetti o persistere dati. Un setter rifiutato conserva lo stato precedente; il cambio email applica regole coerenti con dominio e accesso, inclusa la gestione dei duplicati.
- **Saldi.** Proteggere lettura e modifica del conto nella stessa transazione, usando il meccanismo minimo coerente con i DAO. Tutti gli addebiti, accrediti e rimborsi adottano lo stesso protocollo e un ordine dei lock coerente, anche per rimborsi su più conti.
- **Modalità del prezzo.** Il manager sceglie fra base del modello e base manuale. La scelta deve essere esplicita e persistente, senza dedurla dall'uguaglianza dei valori numerici. Il prezzo consigliato resta visibile; è possibile tornare a usarlo. Base selezionata e risultato della formula sono distinti nell'interfaccia.
- **Formula conservata.** Applicare alla base selezionata il maggiore sconto promozionale tra modello e veicolo, la riduzione usato del 20% se prevista dalla targa, il fattore annuo 0,95 e il fattore chilometrico 0,95 elevato ai chilometri divisi per 20.000. Conservare i comportamenti di validazione e arrotondamento monetario esistenti, senza inventare nuove regole di prezzo. Applicare la formula una sola volta.
- **Prezzi dei flussi.** Catalogo e noleggio usano il prezzo effettivo coerente con la modalità selezionata. Il noleggio mantiene tariffa base giornaliera dello 0,1%, progressione geometrica esistente e giorni inclusivi. La stima iniziale della cessione rimane distinta dalla base commerciale del catalogo e mantiene le regole esistenti.
- **Totale concordato.** Conservare nella richiesta di acquisto il totale fissato quando viene addebitato l'acconto del 20%. Il saldo è quel totale meno l'acconto: cambi successivi di base, sconti o anno non modificano l'accordo. Aggiornare dominio, schema, mapping, fixture e rappresentazione del saldo. Modalità del prezzo e totale concordato sono concetti distinti.
- **Richieste economiche.** Per completamento, rifiuto e scadenza rileggere e proteggere la richiesta dentro la transazione, ricontrollando tipo e stato. Verificare gli esiti delle scritture prima di eseguire movimenti duplicati. Non usare per la decisione finale oggetti letti prima della transazione.
- **Acquisto esistente.** Conservare il blocco atomico del veicolo disponibile e i controlli già presenti di approvazione e scadenza. Il rifiuto mantiene il rimborso dell'acconto previsto; la scadenza mantiene penale del 20% dell'acconto e rimborso dell'80%, ciascuno elaborato una sola volta. Non aggiungere nuovi percorsi di annullamento.
- **Cessione con VIN esistente.** Consentirla soltanto se il veicolo è venduto, l'ultima vendita effettiva al cliente è intestata al proponente e non esistono altre richieste aperte. Lo storico di una vendita più vecchia al proponente non basta se un altro cliente ha acquistato dopo. I controlli non possono essere aggirati da operazioni concorrenti.
- **Unicità e approvazione della cessione.** Una sola richiesta aperta per veicolo, protetta anche dal database. L'approvazione verifica nuovamente richiesta e veicolo in attesa e genera un solo accredito. Rifiutare una proposta preserva lo storico dei veicoli già venduti e segue il comportamento esistente per i veicoli nuovi non accettati.
- **Registro economico.** Adottare il punto di vista della concessionaria: incassi delle vendite e penali positivi, pagamenti delle acquisizioni negativi. Factory, mapping, fixture, commenti e presentazione devono concordare; il conto del cliente riceve comunque l'accredito dovuto.
- **Prenotazioni.** Coordinare controlli e inserimenti su veicolo e cliente per disponibilità, limite dei test drive e interazione con i noleggi. Proteggere anche nel database le sovrapposizioni dei noleggi e conservare l'unicità test drive già presente. Definire un protocollo di lock condiviso fra servizi.
- **Destinazione del veicolo.** Il cambio commerciale riguarda soltanto vendita e noleggio negli stati ammessi. Gli stati venduto, riservato e in attesa non sono riapribili tramite questo comando. Un noleggio il cui periodo include oggi, anche se iniziato ieri, impedisce il passaggio alla vendita.
- **Rimborsi dei noleggi.** Nel passaggio da noleggio a vendita, cancellare i noleggi futuri e rimborsarne integralmente gli importi nella stessa transazione del cambio stato. Un conto mancante o un errore impedisce il successo parziale; non saltare silenziosamente un rimborso.
- **Test drive e Observer.** Alla vendita e alla conferma di un noleggio, cancellare tutti i test drive futuri del veicolo conservando quelli passati. La cancellazione obbligatoria partecipa alla transazione economica e gli errori necessari al rollback vengono propagati. Conservare un uso motivato di Observer senza affidare un invariante a notifiche dopo il commit che possono fallire senza conseguenze.
- **Cancellazione identità.** Ruolo coerente tra presentazione, servizi e DAO; richieste e storico inclusi nei controlli. La concorrenza non deve consentire di perdere attribuzioni storiche fra controllo e cancellazione. Conservare la cancellabilità delle identità prive di vincoli secondo le regole esistenti.
- **Tabelle JavaFX.** Preparare i dati per aggiornamento della tabella fuori dal thread grafico con gli strumenti già disponibili. Le celle visualizzano valori preparati senza aprire connessioni. Gestire caricamenti falliti o superati da aggiornamenti successivi senza bloccare la finestra o applicare dati obsoleti; aggiornare la UI dal thread corretto.
- **Documentazione e pulizia.** Allineare diagrammi e istruzioni alla versione consegnata; identificare le evidenze precedenti come storiche. Distinguere factory statiche da Factory Method GoF e DAO/DI/composition root dai GoF. Motivare SOLID, dipendenze, costruzione dei servizi e uso di DDD con esempi reali e limiti. Rimuovere dipendenza FXML e stato di sessione soltanto dopo aver verificato l'assenza di usi.
- **Tracciamento.** Il piano esterno mantiene avanzamento complessivo, prove e prossimo passo. La specifica definisce il comportamento atteso; i futuri ticket avranno dipendenze e criteri verificabili. Nessun auto-commit o pubblicazione remota impliciti.

## Testing Decisions

### Confini già approvati

Il piano approvato conferma le interfacce pubbliche del dominio e dei servizi come confine principale per verificare i comportamenti. Il confine aggiuntivo della persistenza verifica mapping, vincoli, commit, rollback e concorrenza reali su PostgreSQL dedicato; i controlli mirati JavaFX coprono soltanto le parti modificate. Non sono richiesti nuovi confini pubblici o una nuova architettura di test.

- I test osservano importi, dati riletti, stati, richieste, storico, risultati ed errori; non impongono l'ordine interno delle chiamate salvo quanto necessario a dimostrare una proprietà transazionale.
- Usare valori attesi indipendenti dal calcolo sotto test, senza ricostruire nell'assert lo stesso algoritmo. Un test non deve diventare falso solo perché cambia una decomposizione interna a comportamento invariato.
- Ogni correzione non banale lascia una prova di regressione: riproduzione rossa quando fattibile, cambiamento minimo, prova verde, poi verifica del flusso coinvolto. I test di disponibilità e saldi non si limitano a verificare invocazioni su DAO simulati.
- I test che scrivono dati rifiutano una destinazione non identificata come database di test prima di inizializzare o resettare dati. Fixture isolate e ripetibili; nessun uso implicito del contesto applicativo globale.
- Le prove concorrenti impiegano connessioni PostgreSQL distinte e una sincronizzazione esplicita, evitando di basarsi su attese arbitrarie. Coprire conflitti su veicolo, richiesta, cliente e conto e controllare esiti e assenza di scritture parziali.
- Verificare il rollback reale anche dopo un errore successivo a un movimento economico, inclusi cancellazione obbligatoria dei test drive e rimborsi multipli. Un mock dimostra una decisione, non la semantica di una transazione PostgreSQL.
- Usare date di prova controllate e testare confini inclusivi del noleggio, un noleggio iniziato ieri e cambi di valutazione successivi all'acconto. Non legare la validità dei test a una specifica data di demo.
- Eseguire prima prove mirate, poi la suite completa sullo stato finale. Registrare ambiente, comandi, versione e limiti; test saltati per infrastruttura assente restano verifiche non eseguite.

### Moduli e precedenti da riutilizzare

- `DomainInvariantsTest`: precedente per entità reali, conto dimostrativo, validazioni, date e vincoli; estenderne il tipo di assert per dimostrare stato invariato dopo un errore.
- `PriceCalculatorServiceTest`: precedente per importi attesi e formula; estendere a base manuale, modalità consigliata, ritorno al consigliato e prezzi dei flussi coinvolti.
- `FullWorkflowIntegrationTest`: punto di partenza per costruzione dei servizi e letture delle operazioni; oggi verifica soprattutto accesso e caricamento, quindi non prova già i flussi completi. Isolarlo prima di usarlo per operazioni economiche o scadenze.
- `DatabaseConnectionIntegrationTest` e `DemoSqlValidationTest`: precedenti per JDBC e fixture, da separare dalla configurazione applicativa prima dell'esecuzione. Non considerarli già sicuri per i dati.
- Per acquisto, cessione, noleggio, test drive e account servono prove dei percorsi normali, alternativi, concorrenti e di fallimento. Verificare i dati dopo commit e dopo rollback, non solo gli oggetti rimasti nella sessione.
- Per le viste interessate verificare reattività, caricamento/errore/riprova, correttezza dei dati mostrati e uso da tastiera. Controllare che rendering e scorrimento non eseguano nuove query; registrare se l'ambiente grafico non è disponibile.
- Per la consegna verificare installazione pulita, diagrammi renderizzati quando possibile, correttezza dei riferimenti ai componenti e tracciabilità fra regole, progetto e test.

### Esempi di accettazione numerici

| Scenario | Risultato atteso |
|---|---|
| Base manuale 10.000 €, sconto 10%, nessun'altra riduzione | Prezzo effettivo 9.000 €. |
| Conto da 1.000 €, due addebiti concorrenti da 100 € e 200 € | Saldo finale 700 €, entrambi i movimenti conservati. |
| Acquisto da 20.000 €, acconto 4.000 €, successiva modifica di basi/sconti | Saldo da pagare 16.000 € e vendita totale 20.000 €. |
| Scadenza di un acquisto con acconto 4.000 € | Penale 800 € e rimborso 3.200 €, una sola volta. |
| Due approvazioni della stessa cessione da 16.000 € | Un solo accredito di 16.000 € al cliente e una sola acquisizione di -16.000 € nel registro della concessionaria. |

### Copertura obbligatoria dei rilievi

Ogni riga è un criterio da dimostrare durante l'implementazione. La tabella non rappresenta risultati già ottenuti.

| Criterio | Audit | Attività del piano | Evidenza richiesta per la chiusura |
|---|---|---|---|
| AC01 | #1 | R00 | Prove distruttive limitate al PostgreSQL di test; configurazione non sicura rifiutata e dati sentinella applicativi invariati. |
| AC02 | #2 | R05 | VIN del catalogo o di altro cliente rifiutato senza modifiche; VIN già venduto accettato solo per l'ultimo compratore. |
| AC03 | #3 | R05 | Proposte e approvazioni duplicate, sequenziali e concorrenti, senza seconda richiesta aperta o secondo pagamento. |
| AC04 | #4 | R02 | Movimenti concorrenti sul conto senza aggiornamenti persi né saldo negativo. |
| AC05 | #5 | R06 | Prenotazioni concorrenti senza sovrapposizioni vietate, superamento del limite cliente o incompatibilità noleggio/test drive. |
| AC06 | #6 | R04 | Saldo, rifiuto e scadenza concorrenti senza doppia vendita, doppio addebito o doppio rimborso. |
| AC07 | #7 | R06 | Veicoli venduti/riservati/in attesa non riaperti; noleggio in corso protetto; futuri cancellati e integralmente rimborsati atomicamente. |
| AC08 | #8 | R01 | Email non valida rifiutata prima della persistenza, dati precedenti e accesso preservati. |
| AC09 | #9 | R07 | Cancellazione impedita da richieste e storico, ruoli interpretati coerentemente, attribuzioni conservate anche con concorrenza. |
| AC10 | #10 | R05 | Acquisizioni negative, vendite e penali positive nel registro; importi del conto cliente coerenti. |
| AC11 | #11 | R04 | Totale concordato persistito all'acconto e saldo invariato dopo modifiche successive dei prezzi. |
| AC12 | #12 | R04, R06 | Cancellazione obbligatoria test drive nella transazione; un suo errore annulla anche pagamento e scritture collegate; passato conservato. |
| AC13 | #13 | R00, R01–R08, R11 | Flussi completi e alternative verificati tramite servizi, prove DB separate, copertura delle regole collegata a test effettivi. |
| AC14 | #14 | R09 | Diagrammi coerenti con la versione corrente, evidenze precedenti storiche e risultati nuovi riferibili alla versione verificata. |
| AC15 | #15 | R09 | Installazione pulita riproducibile, configurazione DB e distinzione inizializzazione/reset/demo e comandi di verifica documentati. |
| AC16 | #16 | R08 | Rendering e scorrimento senza query, caricamento fuori dal thread grafico, errori/riprova e aggiornamenti coerenti. |
| AC17 | #17 | R03 | Prezzo consigliato e base manuale entrambi funzionanti secondo la formula, modalità persistente e importi mostrati coerenti. |
| AC18 | #18 | R09 | Terminologia corretta di factory statiche/GoF/DAO/DI e spiegazioni di principi e compromessi sostenute dal codice. |
| AC19 | #19 | R01 | Setter rifiutato lascia targa, chilometri e altri dati precedenti invariati. |
| AC20 | #20 | R10 | Componenti realmente inutilizzati rimossi dopo ricerca dei riferimenti; compilazione e avvio verificati. |

La matrice dei flussi del piano va completata con i nomi effettivi dei test durante l'implementazione. La spiegazione teorica comprende anche direzione delle dipendenze, responsabilità, uso di DI e limiti delle affermazioni su SOLID e DDD.

## Out of Scope

- `Relazione_SWE`: nessuna lettura, ricerca, modifica, generazione o verifica; è gestita dall'utente.
- Nuove funzionalità commerciali, nuovi ruoli, nuovi processi aziendali o nuovi percorsi di annullamento non previsti dal progetto corrente.
- Eliminazione del prezzo manuale o sua interpretazione come totale finale: entrambe contraddicono le decisioni esplicite dell'utente.
- Migrazione o conservazione obbligatoria dei dati preesistenti: il database è dichiarato ricreabile. Restano necessari identificazione della destinazione e isolamento dei test.
- Nuovi framework, ORM, architetture distribuite, code di messaggi o pattern inseriti soltanto per aumentare la quantità di teoria presente.
- Riscrittura completa dell'interfaccia, audit generale di accessibilità o prestazioni oltre ai flussi e controlli modificati.
- Installazione in produzione, pubblicazioni remote, invio di messaggi, creazione di issue su servizi esterni, commit e push automatici.
- Certificazione di conformità a programmi o disciplinari diversi da quelli disponibili; risultati runtime non eseguiti e copertura numerica non misurata.

## Further Notes

- Fonti: [piano approvato e registro](../../PIANO_REVISIONI_DRIVEHUB.md), [audit funzionale](../../AUDIT_DRIVEHUB_2026-10-30.md), [valutazione teorica](../../VALUTAZIONE_TEORICA_DRIVEHUB_2026-10-30.md), [glossario](../../DriveHub/GLOSSARY.md) e [ADR 0001](../../DriveHub/docs/adr/0001-base-manuale-e-prezzo-concordato.md). In caso di conflitto, prevalgono le decisioni esplicite dell'utente; in particolare AC17 segue il requisito di conservare entrambe le opzioni di prezzo.
- I confini di verifica sono già stati approvati nel piano e riconfermati dalla sua approvazione finale: non occorre una nuova intervista per riproporre le stesse scelte. Questa sintesi non introduce un nuovo confine di test.
- Attività di riferimento R00–R11 e dipendenze restano nel piano. Prima attività implementativa R00; la suddivisione in ticket avverrà nel passaggio successivo, con un file per ticket e dipendenze esplicite.
- Baseline di codice individuata: commit `c2a81122ee6be44760ded4160fde229bd33e837c`. Sono già presenti modifiche documentali non committate per piano, glossario, ADR e configurazione delle skill; non vanno scartate o attribuite all'implementazione delle correzioni.
- Alla redazione, la ricognizione precedente ha individuato Java 17 attivo a fronte del requisito Java 21 e un JDK Windows non utilizzabile nella prova effettuata. Maven è disponibile; PostgreSQL non è stato contattato. La disponibilità dell'ambiente va verificata in R00, senza considerare questi limiti come risultati di test.
- Il disciplinare citato dagli audit riporta l'A.A. 2024/25; non è stato riletto direttamente in questa fase. I documenti forniti orientano il consolidamento teorico, senza certificare requisiti didattici successivi.
- Il progetto assume poche sessioni desktop concorrenti, come nella dimostrazione universitaria. Le protezioni economiche e di disponibilità restano necessarie anche con questo carico.
- Nessuna scadenza fissata: scegliere il cambiamento più piccolo che soddisfi criteri e verifiche. Stato alla pubblicazione: specifica pronta, ticket non ancora creati, **0 rilievi su 20 chiusi** e nessuna nuova prova applicativa eseguita.

## Comments

- 31 ottobre 2026: specifica pubblicata con etichetta `ready-for-agent`, usando piano, glossario, ADR e confini di verifica già approvati. Nessun nuovo triage necessario.
