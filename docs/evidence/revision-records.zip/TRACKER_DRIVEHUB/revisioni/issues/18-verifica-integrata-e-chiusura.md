# 18: Dimostrare i flussi integrati e chiudere soltanto i rilievi provati

Suddivisione e dipendenze approvate dall'utente il 31 ottobre 2026.

**What to build:** L'autore dispone di un quadro attendibile della correzione dei 20 rilievi, con test dei flussi, limiti e prossimo passo documentati.

**Blocked by:** 16: Riprodurre l'installazione e spiegare correttamente il progetto; 17: Documentare con diagrammi ed evidenze la versione consegnata

Status: ready-for-agent
State: closed

**Piano:** R11
**Specifica:** AC13
**Storie utente:** US52, US53, US59

## Acceptance criteria

- [x] Collegati AC01–AC20 a ticket, comportamenti e nomi effettivi delle prove; percorsi principali, alternativi ed errori non confusi con semplici caricamenti.
- [x] Suite finale eseguita sullo stato integrato con ambiente e comandi registrati, includendo prove PostgreSQL concorrenti e rollback reali.
- [x] Verificati flussi JavaFX modificati e coerenza di istruzioni/diagrammi/evidenze, senza accedere alla relazione.
- [x] Risultati documentano test realmente eseguiti; controlli saltati o bloccati non vengono conteggiati come riusciti o usati per chiudere un rilievo.
- [x] Diff controllato rispetto a specifica e convenzioni; regressioni residue corrette nelle attività interessate o lasciate esplicitamente aperte.
- [x] Registro e ticket aggiornati con verifiche, limiti e prossimo passo; zero auto-commit, push o pubblicazioni remote.

## Note per l'implementazione

Non rinviare qui i test di regressione dei singoli ticket: ciascuno deve già consegnare un comportamento verificato. Questa è la prova dell'integrazione finale.

Il ticket comprende chiamanti, dati/fixture, messaggi, test e documentazione interessati. Rispettare i confini di test già approvati; non verificare un effetto PostgreSQL soltanto con DAO simulati. `Relazione_SWE` sempre esclusa.

Fonti: [specifica](../spec.md), [piano e registro](../../../PIANO_REVISIONI_DRIVEHUB.md), [glossario](../../../DriveHub/GLOSSARY.md), [ADR prezzi](../../../DriveHub/docs/adr/0001-base-manuale-e-prezzo-concordato.md).

## Comments

- 31 ottobre 2026: ticket pubblicato da `to-tickets` dopo approvazione di granularità e dipendenze. Esecuzione non ancora avviata; verificare i blocchi prima di iniziare.
- 3 novembre 2026: avviato soltanto18.01–17 chiusi e senza criteri aperti verificati; baseline locale di1796file,326ignorati inclusi, relazione esclusa. Nuovo cluster dedicato127.0.0.1:55436 e Xvfb90; mirati363/363 riusciti dopo un primo tentativo con4timeout conservato separatamente. [Matrice e prove18](../../../DriveHub/docs/evidence/r11-integrated/verification.md); GUI, suite finale e review in corso. Nessuno staging/commit/push.
- 3 novembre2026 — chiusura18:6/6criteri verificati. [Matrice AC01–AC20](../../../DriveHub/docs/evidence/r11-integrated/acceptance-matrix.md), mirati363/363, sette harnessJavaFX,18SVG rigenerati e finale394/394 (47senzaDB/347PostgreSQL), zero failure/errori/salti; gare/rollback reali. Sentinella finale fase2 READ ONLY13tabelle/7sequenze invariate e cluster arrestato. /tmp persa all'interruzione: strumenti/cluster ricreati,1796hash iniziali recuperati, input produttivi invariati; confronto esterno finale sentinella fase1 non eseguito e non contato. Review indipendenti Standards/Spec sul solo delta locale e limiti nel [rapporto18](../../../DriveHub/docs/evidence/r11-integrated/verification.md). R11/AC12/AC13 completati,20/20rilievi nei confini verificati; nessun residuo funzionale dimostrato. Preservati1796file iniziali, ignorati/target e originali storici; nessuno staging/commit/push/pubblicazione, relazione sempre esclusa. Ulteriori certificazioniOS/screenreader/installer/migrazione fuori perimetro.
