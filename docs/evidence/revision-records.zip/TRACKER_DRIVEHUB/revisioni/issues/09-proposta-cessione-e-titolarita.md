# 09: Proporre una cessione solo per un veicolo consentito

Suddivisione e dipendenze approvate dall'utente il 31 ottobre 2026.

**What to build:** Un cliente può proporre un VIN nuovo o il veicolo già venduto a lui, senza sovrascrivere inventario altrui e senza richieste aperte duplicate.

**Blocked by:** 01: Rendere build e test ripetibili senza toccare i dati applicativi

Status: ready-for-agent
State: closed

**Piano:** R05
**Specifica:** AC02, AC03, AC13
**Storie utente:** US28, US29, US30

## Acceptance criteria

- [x] VIN esistente accettato solo se il veicolo risulta venduto, l'ultima vendita effettiva è al proponente e non ci sono altre richieste aperte; controlli nella transazione.
- [x] VIN appartenente alla concessionaria o a un altro cliente rifiutato senza cambiare dati, stato o richieste.
- [x] Una vendita più vecchia al proponente non basta quando esiste un compratore successivo; la verifica usa lo storico effettivo.
- [x] Unicità della richiesta aperta per veicolo protetta anche nel DB; due proposte concorrenti lasciano al massimo una richiesta e nessuna scrittura parziale.
- [x] VIN nuovo ancora proponibile con la stima esistente; aggiornati validazioni, mapping, fixture e messaggi interessati.
- [x] Prove normali, alternative e concorrenti ripetibili su dati isolati.

## Note per l'implementazione

Nessuna nuova procedura di prova esterna della proprietà: i VIN già noti usano lo storico del progetto, quelli nuovi seguono il comportamento esistente.

Il ticket comprende chiamanti, dati/fixture, messaggi, test e documentazione interessati. Rispettare i confini di test già approvati; non verificare un effetto PostgreSQL soltanto con DAO simulati. `Relazione_SWE` sempre esclusa.

Fonti: [specifica](../spec.md), [piano e registro](../../../PIANO_REVISIONI_DRIVEHUB.md), [glossario](../../../DriveHub/GLOSSARY.md), [ADR prezzi](../../../DriveHub/docs/adr/0001-base-manuale-e-prezzo-concordato.md).

## Comments

- 31 ottobre 2026: ticket pubblicato da `to-tickets` dopo approvazione di granularità e dipendenze. Esecuzione non ancora avviata; verificare i blocchi prima di iniziare.


### Esecuzione — 2 novembre 2026

- Prerequisito 01 e precedenti 01–08 controllati tutti chiusi. Letti istruzioni,
  piano, glossario, ADR e documentazione/evidenze d'ambiente prima delle modifiche.
  Baseline di 401 file acquisita in `/tmp/drivehub-ticket09-baseline`, compreso
  tutto il lavoro locale precedente. Nessun commit/staging, relazione esclusa.
- Implementato solo 09: VIN noto con lock/rilettura, SOLD, ultima vendita
  effettiva al proponente e nessuna richiesta aperta di qualsiasi tipo. Modello
  e anno coerenti con il VIN; base/modalità preservate. Richiesta e veicolo nella
  stessa transazione, aggiornamento obbligatorio di una riga.
- Tipo esplicito dello storico PURCHASE/ACQUISITION/PENALTY, persistito da tutte
  le factory/mapping. Vendita effettiva per data e poi ID, senza deduzione da
  importi/segni. Nessuna anticipazione del ticket 10. Tutte le 40 operazioni demo
  conservate; fixture SOLD del 05 completata con la vendita al proponente.
- UNIQUE request(vehicle) anche nel DB; VIN nuovo conserva stima/base modello.
  Gare su VIN noto e stesso VIN nuovo: una richiesta, un veicolo completo,
  nessuna sovrascrittura del perdente. Connessioni distinte, lock osservati con
  pg_stat_activity/pg_blocking_pids, nessuno sleep, timeout e cleanup.
- TDD: rifiuto VIN concessionaria RED 1 failure → stessa regressione GREEN 1/1;
  SOLD senza vendita RED 1 → GREEN 2/2; unicità/gare RED 2 failure su 3 → GREEN
  5/5; scrittura saltata/modello errato RED 2 su 3 → casi 31/31; messaggio
  generico RED 1 → nuove prove incluse nei mirati 142/142 e suite finale 195/195.
- Comandi: `python3 /tmp/drivehub-ticket09-maven.py <etichetta> <argomenti Maven>`;
  selezioni esatte, log/XML e versioni in
  [verification.md](../../../DriveHub/docs/evidence/r05-sale-proposal/verification.md).
  Finale `-Ppostgres-tests clean test`: **195/195**, zero failure/errori/saltati,
  41 senza DB e 154 PostgreSQL; isolamento/sentinella e fixture ripetibili inclusi.
  Nuovi 24/24. Conti 04, formula/base/centesimi 05, accordo 06, unicità
  elaborazioni 07 e cancellazione atomica/Observer 08 passati nella nuova suite.
- Ambiente temporaneo 07 verificato prima del riuso: Java 21, Maven 3.9.16, PG16,
  sei variabili e file privato 0600, solo cluster 127.0.0.1:55432 e copia
  applicativa sentinella. Avvio sandbox negato, escalation riuscita; nessun DB
  applicativo preesistente contattato. Cluster ora arrestato. 171/171 del 08
  resta una baseline storica. `/tmp` temporanea.
- Nessuna vista modificata: messaggi leggibili dal servizio al catch esistente;
  nessuna nuova verifica JavaFX/tastiera. Nessuna migrazione storica, procedura
  esterna di proprietà, accettazione/rifiuto o segno contabile del 10,
  prenotazione 11, altra transizione o prestazione anticipati.
- **6/6 criteri runtime verificati; ticket in-progress finché mancano le due
  revisioni finali indipendenti Standards/Spec sul diff della sola sessione.**
  Prossimo passo: completare questo stesso ticket, senza passare al successivo.


### Chiusura verificata — 2 novembre 2026

- **State: closed, 6/6 criteri soddisfatti.** La nota in-progress sopra è storica.
  Revisioni indipendenti sul diff fissato della sola sessione: Standards
  **0 violazioni/0 smell azionabili**, Spec **0 rilievi**; contesti nuovi,
  confronti rispetto alla baseline locale, non rispetto a HEAD.
- Suite finale **195/195** e mirati **142/142** realmente eseguiti. Nessun codice
  o test cambiato dopo suite/review; hash della versione, patch, log/XML,
  report delle due revisioni e limiti nel rapporto collegato sopra.
- 387 dei 401 file iniziali identici; 14 aggiornamenti intenzionali, nessuna
  eliminazione. Tutti i ticket 01–08 e le evidenze storiche intatti, storico demo
  identico salvo tipo esplicito; HEAD/indice invariati. Nessun commit/staging.
- Chiuso AC02/#2; R05 resta parziale per 10, AC03 limitatamente alle proposte
  verificato, approvazioni e contabilità escluse. Totale rilievi chiusi **8/20**;
  AC13 trasversale. Nessuna vista modificata o prova JavaFX/tastiera nuova.
- Cluster dedicato arrestato; ambiente temporaneo da ricontrollare prima del
  riuso. Schema da adeguare e storico da classificare dai fatti su installazioni
  esistenti, senza inferire tipi dai segni. Nessun blocco residuo del ticket 09.
- Prossimo passo: ticket 10 solo su nuova richiesta; nessun successivo avviato.
