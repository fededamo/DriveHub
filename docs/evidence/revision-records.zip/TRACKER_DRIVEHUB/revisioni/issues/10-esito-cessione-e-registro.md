# 10: Accettare o rifiutare una cessione senza doppi pagamenti

Suddivisione e dipendenze approvate dall'utente il 31 ottobre 2026.

**What to build:** Il venditore conclude una cessione una sola volta; il cliente riceve l'accredito dovuto e il manager vede l'acquisizione come uscita della concessionaria.

**Blocked by:** 07: Elaborare saldo, rifiuto e scadenza una sola volta; 09: Proporre una cessione solo per un veicolo consentito

Status: ready-for-agent
State: closed

**Piano:** R05
**Specifica:** AC03, AC10, AC13
**Storie utente:** US30, US31, US32, US33, US34

## Acceptance criteria

- [x] Riutilizzato il protocollo di protezione della richiesta del ticket 07; approvazione/rifiuto rileggono e verificano richiesta, tipo e stato del veicolo nella transazione.
- [x] Due approvazioni, sequenziali o concorrenti, di una cessione da 16.000 € producono un solo accredito di 16.000 € e un solo cambio di disponibilità.
- [x] Registro della concessionaria con acquisizione -16.000 €; vendite ai clienti e penali restano entrate positive. Factory, mapping, commenti, fixture e vista manager concordano.
- [x] Rifiuto di nuovo veicolo segue la rimozione prevista senza lasciare catalogo sporco; rifiuto di veicolo con storico mantiene lo storico e ripristina lo stato ammesso.
- [x] Fondi/dati mancanti o errore di scrittura non lasciano accrediti, richieste o veicoli parzialmente aggiornati.
- [x] Verificati flussi completi di accettazione/rifiuto e competizioni approvazione/approvazione e approvazione/rifiuto su PostgreSQL.

## Note per l'implementazione

Il blocco del conto protetto dal ticket 04 è già prerequisito transitivo del ticket 07. Non cambiare il punto di vista contabile al cliente.

Il ticket comprende chiamanti, dati/fixture, messaggi, test e documentazione interessati. Rispettare i confini di test già approvati; non verificare un effetto PostgreSQL soltanto con DAO simulati. `Relazione_SWE` sempre esclusa.

Fonti: [specifica](../spec.md), [piano e registro](../../../PIANO_REVISIONI_DRIVEHUB.md), [glossario](../../../DriveHub/GLOSSARY.md), [ADR prezzi](../../../DriveHub/docs/adr/0001-base-manuale-e-prezzo-concordato.md).

## Comments

- 31 ottobre 2026: ticket pubblicato da `to-tickets` dopo approvazione di granularità e dipendenze. Esecuzione non ancora avviata; verificare i blocchi prima di iniziare.

- 2 novembre 2026: completato e verificato soltanto il ticket 10. Prerequisiti 07/09
  e ticket 01–09 controllati chiusi; baseline locale acquisita prima delle modifiche.
  [Evidenze, versione e comandi](../../../DriveHub/docs/evidence/r05-sale-outcome/verification.md).
- Richiesta e veicolo riletti/bloccati nella transazione: SALE/WAITING; conto 04
  e verifiche delle righe conservati. Storico completo sulla stessa connessione,
  distinto dall'ultima PURCHASE della titolarità 09. Rifiuto VIN nuovo senza residui;
  veicolo con qualsiasi storico conservato e ripristinato SOLD.
- Accredito cliente +16000 e acquisizione concessionaria -16000; vendite e penali
  positive, tipi espliciti, dominio/schema/factory/fixture/registro/messaggi allineati.
- RED/GREEN ripetibili su servizi pubblici e PostgreSQL dedicato, inclusi stessa
  baseline isolata per obsolescenza, gare osservabili nei due ordini senza sleep,
  dati mancanti, vincoli, scritture saltate e rollback dopo effetti effettivi.
- Comandi: `mvn -Ppostgres-tests -Dtest=SaleOutcomeIntegrationTest,SaleTypeTest test`;
  mirati estesi **206/206**; finale `mvn -Ppostgres-tests clean test` **259/259**,
  zero failure/errori/saltati (45 senza DB, 214 PostgreSQL), isolamento/sentinella.
  Java21/PG16 del 07 ricontrollati prima del riuso. Baseline 195/195 del 09 storica.
- JavaFX/Robot/tastiera finale **UI CHECK SUCCESS**: cliente/venditore/manager,
  sessione obsoleta, segni/tipi anche a zero e contrasto selezione. Review indipendenti
  Standards/Spec: **0 rilievi**, patch della sola sessione fissata nelle evidenze.
- 377 file preesistenti identici, 13 modifiche intenzionali, nessuna eliminazione;
  prove storiche preservate. HEAD/indice invariati, nessun commit/staging.
  Cluster dedicato e Xvfb arrestati; Relazione_SWE sempre esclusa.
- R05 completata, AC03/#3 e AC10/#10 chiusi; 10/20 rilievi integralmente chiusi.
  Limiti: nessuna migrazione applicativa (D02); schema/importi storici da adeguare
  prima dell'uso, senza dedurre i tipi dal segno. Screen reader, prenotazioni 11,
  altre transizioni, account e prestazioni esclusi. Nessun blocco residuo del 10;
  nessun ticket successivo avviato. Prossimo passo: ticket 11 solo su nuova richiesta.
