# 14: Consultare le tabelle senza query nel rendering

Suddivisione e dipendenze approvate dall'utente il 31 ottobre 2026.

**What to build:** Catalogo e tabelle interessate restano utilizzabili durante caricamenti lenti, mostrano i prezzi corretti e permettono la riprova dopo errori.

**Blocked by:** 05: Usare prezzo consigliato o base manuale lungo catalogo e noleggio

Status: ready-for-agent
State: closed

**Piano:** R08
**Specifica:** AC16
**Storie utente:** US49, US50, US51

## Acceptance criteria

- [x] Modelli, sconti e prezzi preparati per aggiornamento fuori dal thread grafico, usando strumenti JavaFX e servizi già presenti.
- [x] Celle dedicate alla visualizzazione; scorrimento e rendering non aprono connessioni né eseguono nuove query.
- [x] Dati mostrati coerenti con modalità consigliata/manuale del ticket 05 e aggiornati dopo modifiche.
- [x] Caricamenti falliti o superati da richieste successive non bloccano la finestra o ripristinano dati vecchi; UI aggiornata sul thread corretto.
- [x] Verificati caricamento lento, errore/riprova, aggiornamento tabella, etichette e uso da tastiera delle parti modificate; limiti grafici registrati se presenti.

## Note per l'implementazione

Nessuna riscrittura generale della UI o nuova infrastruttura di cache. Verificare il comportamento osservabile delle tabelle interessate.

Il ticket comprende chiamanti, dati/fixture, messaggi, test e documentazione interessati. Rispettare i confini di test già approvati; non verificare un effetto PostgreSQL soltanto con DAO simulati. `Relazione_SWE` sempre esclusa.

Fonti: [specifica](../spec.md), [piano e registro](../../../PIANO_REVISIONI_DRIVEHUB.md), [glossario](../../../DriveHub/GLOSSARY.md), [ADR prezzi](../../../DriveHub/docs/adr/0001-base-manuale-e-prezzo-concordato.md).

## Comments

- 31 ottobre 2026: ticket pubblicato da `to-tickets` dopo approvazione di granularità e dipendenze. Esecuzione non ancora avviata; verificare i blocchi prima di iniziare.

- 2 novembre 2026: avviato solo14; prerequisito05 e01–13 chiusi, baseline nuova390/390 con isolamento/sentinella. Fotografia1089file, lavoro precedente preservato. RED rendering856connessioni/query → GREEN0/0; RED blocco modelli su lock PostgreSQL → GREEN reattivo; RED risultato obsoleto dopo marca svuotata → GREEN con invalidazione. Test identici per coppia, GUI estesa passata; prove finali e review ancora da completare. Nessun commit, nessun successivo, Relazione_SWE esclusa.

- 2 novembre 2026 — chiusura: **5/5 criteri verificati**, solo14. Tre coppie RED/GREEN con sorgente identico; nuova baseline390/390, mirati25/25 e148/148, finale `mvn -Ppostgres-tests clean test` **394/394** (47 senza DB/347 PostgreSQL), zero failure/errori/salti, isolamento/sentinella compresi. GUI finale e modelli lenti/obsoleti **UI CHECK SUCCESS**; zero connessioni/query durante celle/scorrimento sulle tre dashboard, quattro letture collettive per listino. Tastiera, caricamento bloccato osservabile, errore SQL/riprova e risultato/errore obsoleto, aggiornamenti delle basi/sconti/modalità e vista già aperta verificati. Sette schermate ispezionate; limiti del titolo abbreviato, screen reader, altri OS e cancellazione JDBC registrati. Review indipendenti Standards **0 violazioni/0 smell azionabili**, Spec **0 rilievi**, sul solo diff congelato di sessione. Sentinella finale in sola lettura, cluster dedicato e Xvfb arrestati; nessun DB applicativo preesistente. Baseline1089file:1082 identici,7 modifiche intenzionali,zero eliminazioni; HEAD/indice invariati. [Prove, comandi, hash, review e limiti](../../../DriveHub/docs/evidence/r08-tables/verification.md). R08/AC16/#16 completati,14/20 rilievi chiusi; nessun successivo, nessun commit/staging, Relazione_SWE esclusa.
