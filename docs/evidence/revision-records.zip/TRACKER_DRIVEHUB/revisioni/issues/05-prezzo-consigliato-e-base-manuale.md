# 05: Usare prezzo consigliato o base manuale lungo catalogo e noleggio

Suddivisione e dipendenze approvate dall'utente il 31 ottobre 2026.

**What to build:** Il manager sceglie la base del modello o una base manuale persistente; clienti e servizi vedono il prezzo effettivo ottenuto dalla stessa formula.

**Blocked by:** 01: Rendere build e test ripetibili senza toccare i dati applicativi

Status: ready-for-agent
State: closed

**Piano:** R03
**Specifica:** AC17, AC13
**Storie utente:** US11, US12, US13, US14, US15, US16, US17, US18

## Acceptance criteria

- [x] Modalità automatica/manuale esplicita e persistente, senza inferirla dall'uguaglianza numerica delle basi; schema, mapping e fixture coerenti.
- [x] Prezzo consigliato sempre distinguibile dalla base manuale; il manager può tornare al consigliato e la scelta sopravvive a salvataggio/rilettura.
- [x] La formula esistente viene applicata una sola volta alla base scelta: base manuale 10.000 € e sconto 10%, senza altre riduzioni, producono 9.000 €.
- [x] Interfaccia distingue base e risultato; catalogo e tariffa di noleggio usano la valutazione corretta, preservando formula geometrica e giorni inclusivi.
- [x] La stima iniziale della cessione resta distinta dalla scelta commerciale del manager e conserva le regole esistenti.
- [x] Aggiornati tutti i chiamanti e i test di formula/persistenza/modalità, con controllo mirato delle viste modificate e tastiera.

## Note per l'implementazione

ADR 0001 vincolante: il manuale è una base, non il totale finale. Non eliminare l'opzione manuale; nessuna migrazione dei vecchi dati obbligatoria.

Il ticket comprende chiamanti, dati/fixture, messaggi, test e documentazione interessati. Rispettare i confini di test già approvati; non verificare un effetto PostgreSQL soltanto con DAO simulati. `Relazione_SWE` sempre esclusa.

Fonti: [specifica](../spec.md), [piano e registro](../../../PIANO_REVISIONI_DRIVEHUB.md), [glossario](../../../DriveHub/GLOSSARY.md), [ADR prezzi](../../../DriveHub/docs/adr/0001-base-manuale-e-prezzo-concordato.md).

## Comments

- 31 ottobre 2026: ticket pubblicato da `to-tickets` dopo approvazione di granularità e dipendenze. Esecuzione non ancora avviata; verificare i blocchi prima di iniziare.


### Implementazione e chiusura — 31 ottobre 2026

- Verificati prerequisito 01 e ticket 02/03/04 `closed`; letti AGENTS, piano,
  glossario, ADR 0001 e ambiente Java 21/PostgreSQL documentato. Solo ticket 05,
  nessun commit; Relazione_SWE sempre esclusa.
- Mappati tutti i chiamanti di creazione/modifica/calcolo: Vehicle, DAO e mapping,
  CatalogService, PriceCalculatorService, acquisto/acconto/saldo, noleggio,
  cessione e viste manager/cliente/venditore. Modalità enum AUTOMATIC/MANUAL e
  colonna price_mode esplicite, indipendenti dall'uguaglianza numerica; schema/demo
  aggiornati. La scelta commerciale aggiorna solo base/modalità.
- Una sola formula esistente, con tutte le riduzioni preservate. Automatico dalla
  base corrente del modello; manuale dalla base manager; consigliato calcolato
  separatamente. Ritorno al consigliato disponibile e persistito. Stima cessione
  nella richiesta, senza sovrascrivere la base commerciale né applicarla due volte.
- RED pubblico dominio: `python3 /tmp/drivehub-r00-maven.py ticket 05-red
  -Dtest=PriceCalculatorServiceTest#manualBaseReceivesPromotionOnce test` →
  18000 anziché 9000, 1 failure attesa; stesso comando etichetta `ticket 05-green` → 1/1.
  RED servizio/catalogo PostgreSQL con `ticket 05-persistence-red -Ppostgres-tests
  -Dtest=PriceSelectionIntegrationTest test` → stessa failure dopo rilettura;
  `ticket 05-persistence-green` → 1/1. RED cessione tramite servizio pubblico:
  base manuale sovrascritta dalla stima, poi corretto e verificato nei mirati.
- Mirati iniziali19/19 e prima suite82/82. Revisione indipendente Spec ha trovato
  frazioni di centesimo non coerenti con DECIMAL(10,2): aggiunti RED pubblici con
  base 10000.005, due failure9000.00 invece 9000.01. Dominio normalizzato HALF_UP
  prima della formula, dopo validazione segno; factory manuale e setter condividono
  la regola, incluso rifiuto -0.001. `ticket 05-rounding-green -Ppostgres-tests
  -Dtest=PriceCalculatorServiceTest,PriceSelectionIntegrationTest test` → **21/21**.
- `python3 /tmp/drivehub-r00-maven.py ticket 05-final-full -Ppostgres-tests clean test`
  → **84/84**, 0failure/errori/saltati, **33 senza DB + 51 PostgreSQL**. Compilati 63
  sorgenti principali e 11 test con target21. Comprese 16 prove concorrenza conti 04,
  fixture, isolamento/sentinella; nessun DAO simulato come prova della persistenza.
- PostgreSQL reale: entrambe modalità rilette, manuale uguale al modello seguito
  da cambio base modello, ritorno automatico, zero/input invalidi/centesimi,
  prezzo catalogo e acquisto, tariffa geometrica a 1 e 3 giorni inclusivi, stima cessione
  separata e approvazione. Protocollo conti 04 invariato; totale concordato non congelato.
- JavaFX Robot/Xvfb isolato: **UI CHECK SUCCESS** anche dopo l'ultima modifica.
  Frecce selezionano il veicolo; Tab/Spazio modificano/salvano la base 10000 e
  il ritorno automatico; riletture verificano gli esiti. Catalogo cliente noleggio
  aperto da tastiera. Quattro screenshot ispezionati: base/consigliato/effettivo e
  tariffa iniziale chiaramente distinti; label associata al campo, focus visibile.
- Revisione finale indipendente sul diff della sola sessione, due contesti nuovi:
  **Standards 0; Spec 0 rilievi residui**. Hash 16/16 verificati. Dei 62 file locali
  preesistenti, 57 invariati; 5 adeguati intenzionalmente preservando il lavoro precedente.
  HEAD invariato, nessuno staging. PostgreSQL temporaneo e Xvfb arrestati.
- Limiti: schema ricreabile senza migrazione storica; nessun SQL al DB applicativo
  preesistente. Primo rendering con tutta la demo oltre timeout; GUI finale su
  fixture ridotta 2 veicoli, nessuna certificazione prestazionale. Query nelle celle
  e caricamento asincrono restano al 14; congelamento totale al 06 e altri difetti ai
  rispettivi ticket. Warning JavaFX preesistente; ambiente/tmp temporaneo.
- **6/6 criteri verificati, State: closed**, R03 completata, rilievo #17 chiuso.
  [Evidenze, comandi, log, XML, screenshot, patch e revisioni](../../../DriveHub/docs/evidence/r03-prices/verification.md).
  Prossimo passo del piano: ticket 06 soltanto in una successiva richiesta.
