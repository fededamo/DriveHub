# 01: Rendere build e test ripetibili senza toccare i dati applicativi

Suddivisione e dipendenze approvate dall'utente il 31 ottobre 2026.

**What to build:** Lo sviluppatore può compilare con Java 21, eseguire prove senza database e prove PostgreSQL dedicate e ricreare le fixture senza coinvolgere il database applicativo.

**Blocked by:** None (can start immediately)

Status: ready-for-agent
State: closed

**Piano:** R00
**Specifica:** AC01, AC13, AC15
**Storie utente:** US01, US02, US03, US04, US05, US56

## Acceptance criteria

- [x] Java 21 e Maven utilizzabili verificati senza abbassare il requisito del progetto; comandi ed eventuali dipendenze mancanti registrati.
- [x] Ogni test che modifica dati riceve una configurazione esplicita di PostgreSQL dedicato; non usa implicitamente il contesto applicativo globale.
- [x] Configurazione non sicura rifiutata prima di inizializzazione/reset; prova non distruttiva con dati sentinella dimostra che il database applicativo non viene modificato.
- [x] Schema e fixture di test caricabili più volte con esiti coerenti; prove SQL dimostrative e gestione scadenze isolate dai dati della demo.
- [x] Comandi distinti per prove senza DB e prove PostgreSQL documentati; test saltati o infrastruttura mancante segnalati come verifiche non eseguite.
- [x] Prove mirate su isolamento, fixture e configurazione superate; aggiornati istruzioni di esecuzione e registro, senza dichiarare corretti i restanti difetti.

## Note per l'implementazione

Il database è ricreabile, ma solo dopo averne identificato la destinazione. Preferire la configurazione esplicita e gli strumenti già disponibili; nessuna nuova dipendenza per pochi casi.

Il ticket comprende chiamanti, dati/fixture, messaggi, test e documentazione interessati. Rispettare i confini di test già approvati; non verificare un effetto PostgreSQL soltanto con DAO simulati. `Relazione_SWE` sempre esclusa.

Fonti: [specifica](../spec.md), [piano e registro](../../../PIANO_REVISIONI_DRIVEHUB.md), [glossario](../../../DriveHub/GLOSSARY.md), [ADR prezzi](../../../DriveHub/docs/adr/0001-base-manuale-e-prezzo-concordato.md).

## Comments

- 31 ottobre 2026: ticket pubblicato da `to-tickets` dopo approvazione di granularità e dipendenze. Esecuzione non ancora avviata; verificare i blocchi prima di iniziare.

- 31 ottobre 2026 — Avvio implementazione: confermati reset demo sul DB predefinito e scadenze tramite Singleton. Confini già approvati: configurazione, fixture e isolamento su PostgreSQL reale. README e documenti di dominio preesistenti preservati.

## Avanzamento del 31 ottobre 2026 — implementazione locale

**Stato: in-progress. Non passare al ticket successivo.** Nessun rilievo chiuso finché
le verifiche Java 21 e PostgreSQL richieste non sono superate. Nessun commit: richiesta
esplicita dell'utente durante questa sessione; modifiche soltanto locali.

### Implementato

- Configurazione unica `TestDatabase`: URL, ruolo e password di test obbligatori;
  database/ruolo `drivehub_test` distinti da quelli applicativi. Rifiuto preventivo
  di target applicativi, override JDBC, host multipli e configurazione incompleta.
- Prima di ogni reset, query PostgreSQL di verifica di database/utente effettivi,
  proprietario, schema e assenza di privilegi amministrativi, appartenenze ad altri
  ruoli o proprietà di altri database. Schema e demo eseguiti interi in transazione.
- `AppContext(DatabaseManager)` riusa la composizione esistente. Connessione, demo e
  flussi usano la configurazione di test; fixture ricreata prima di ciascun flusso,
  scadenza esplicita con date relative. Nessuna modifica a schema/demo applicativi.
- Tag `postgres`, `mvn test` senza DB e profilo `postgres-tests` per la suite completa;
  plugin resources fissato a 3.3.1, già disponibile in cache, anziché dipendere dalla
  versione implicita di Maven. Nuove istruzioni in `DriveHub/docs/testing.md` e README.
- Prove aggiunte: rifiuto della configurazione prima della connessione, ricaricamento
  ripetuto di righe/sequenze, scadenza isolata e sentinella applicativa in sola lettura.

### Verifiche realmente eseguite

| Verifica / comando | Esito attuale |
|---|---|
| `java -version`; `mvn -version` | Java Linux 17.0.20.1, Maven 3.9.16. Requisito del POM rimasto 21. |
| JDK Windows `jdk-21.0.12.101-hotspot/bin/java.exe -version` | Non eseguibile nella sandbox: WSL `UtilBindVsockAnyPort:317: socket failed 1`. |
| Primo `mvn -o -Dtest=TestDatabaseConfigurationTest test` | Non avviato: resources 3.4.0 implicito non in cache. Fissato resources 3.3.1 disponibile. Nessuna prova RED/GREEN Maven completata. |
| Secondo `mvn -o -Dtest=TestDatabaseConfigurationTest test` | Fallito in compilazione: `invalid target release: 21`. Segnalata anche cache incompleta del plugin Surefire 3.2.5. |
| `mvn -o -Ppostgres-tests test` (suite completa, tentativo finale) | Fallito prima dei test: `invalid target release: 21`; nessuna prova PostgreSQL eseguita. |
| `javac -Xlint:all` sui 70 sorgenti in directory temporanea, con JAR locali | Superato con Java 17, senza warning. Controllo supplementare; non valida la build Java 21 e non modifica target/source del progetto. |
| Launcher JUnit locale: `TestDatabaseConfigurationTest` | 7/7 test superati su Java 17; nessun DB contattato. |
| Launcher JUnit locale: package `it.unifi.drivehub`, escluso tag `postgres` | 21/21 test superati, 0 saltati, su Java 17. Nessuna prova di persistenza eseguita. |
| Launcher JUnit locale: `DatabaseConnectionIntegrationTest`, variabili DB rimosse esplicitamente | Fallimento atteso prima della connessione: manca `DRIVEHUB_TEST_DB_URL`; 1 fallito, 0 saltati. |
| Configurazione PostgreSQL esplicita | Mancano tutte le sei variabili test/sentinella; `psql` assente, Docker non integrato in WSL. La sonda TCP locale è vietata (`Operation not permitted`): nessuna conclusione sull'esistenza del server. |
| Download JDK / rete | DNS di `api.adoptium.net` non disponibile dalla sandbox. Nessuna installazione eseguita. |
| XML POM, selezione tag e ricerca mirata dei chiamanti | Superati: nessun Singleton applicativo o `new DatabaseManager()` nei test; tutti i test DB hanno il tag. |
| `git diff --check` / `git diff --cached --check`, perimetro esplicito senza relazione | Superati; modifiche preesistenti dell'utente preservate e piano/tracker esterni al repository. |

Log temporanei: `/tmp/drivehub-r00-red.log`, `/tmp/drivehub-r00-targeted.log`,
`/tmp/drivehub-r00-full.log`, `/tmp/drivehub-r00-java17/`. Non sono evidenze di
PostgreSQL né una consegna di build Java 21.

### Revisione finale

Skill `code-review` applicata su diff locale selezionato rispetto alla baseline
`c2a81122ee6be44760ded4160fde229bd33e837c`, adattata al divieto di commit dell'utente.
Standard: 0 violazioni e 0 smell concreti. Specifica: 0 difetti implementativi
confermati, criteri Java 21/PostgreSQL ancora parziali. Revisione statica distinta
dalle prove runtime mancanti. Nessun commit creato; indice Git lasciato senza le
modifiche di questa sessione, file locali conservati.

### Prossimo passo della sessione precedente (eseguito nella ripresa)

Riprendere **questo ticket 01** in un ambiente con JDK 21 Linux, dipendenze Maven e
accesso autorizzato a PostgreSQL 16. Predisporre database/ruolo dedicati e sentinella
come in `DriveHub/docs/testing.md`; eseguire configurazione, fixture/scadenze e
sentinella, quindi `mvn -Ppostgres-tests test`. Chiudere soltanto dopo avere registrato
gli esiti positivi dei criteri ancora aperti. `Relazione_SWE` sempre esclusa.

## Chiusura verificata — 31 ottobre 2026

**State: closed. Tutti i 6 criteri soddisfatti.** Il precedente blocco d'ambiente è
risolto. OpenJDK 21.0.12.1 Linux e PostgreSQL 16.15 estratti da pacchetti ufficiali
Ubuntu sotto `/tmp/drivehub-r00-tools/root`; Maven 3.9.16 verificato con Java 21.
Nessuna installazione di sistema. Il cluster nuovo su `127.0.0.1:55432` usa dati in
`/tmp/drivehub-r00-pgdata`: database/ruolo `drivehub_test` e copia applicativa distinta
`drivehub` con marchio sentinella. Nessun SQL sul database applicativo preesistente.

- `mvn -Dtest=TestDatabaseConfigurationTest test`: 7/7 passati con Java 21.
- `mvn test`: 21/21 senza DB, 0 saltati.
- Profilo `postgres-tests`, selezione dei quattro test DB: 7/7 passati, 0 saltati;
  coperti connessione, fixture/righe/sequenze ripetibili, scadenza e sentinella.
- Prova negativa reale: assegnato temporaneamente `CREATEDB` al solo ruolo di test;
  il test di connessione/reset fallisce con `Reset rifiutato` prima del reset.
  Sentinelle nel DB di test e nella copia applicativa entrambe preservate; attributo
  ripristinato `NOCREATEDB` in `finally` prima della suite finale.
- `mvn -Ppostgres-tests clean test`: **BUILD SUCCESS, 28 test, 0 failure/error/skipped**;
  ricompilati 62 sorgenti principali e 8 di test con target Java 21.
- Istruzioni locali e generali aggiornate; log e hash conservati nelle
  [evidenze R00](../../../DriveHub/docs/evidence/r00/verification.md).
- Revisione precedente standard/spec senza difetti confermati; codice invariato nella
  ripresa. I controlli finali riguardano evidenze, documenti e perimetro locale.

Il warning preesistente sul modello JavaFX resta segnalato; UI grafica e altri difetti
funzionali non sono certificati da R00. Ambiente temporaneo, da ricreare se /tmp viene
cancellata; credenziali solo nel file privato locale, mai nelle evidenze. Server temporaneo
arrestato al termine. Nessun commit, nessun file della relazione consultato o modificato.

**Prossimo passo:** ticket 02 / R01, da avviare in una successiva richiesta; nessun altro
ticket lavorato in questa sessione. Chiuso il rilievo #1; #13 soltanto nella parte R00.

Controlli finali: link/whitespace e hash dei sorgenti validi, nessuna credenziale nelle evidenze, file ambiente privato 0600, `git diff --check` superato; indice vuoto e HEAD invariato. `pg_ctl stop` completato.
