# 02: Conservare il veicolo invariato dopo una modifica non valida

Suddivisione e dipendenze approvate dall'utente il 31 ottobre 2026.

**What to build:** Il manager può ricevere un errore di validazione della targa senza lasciare il veicolo in uno stato invalido.

**Blocked by:** 01: Rendere build e test ripetibili senza toccare i dati applicativi

Status: ready-for-agent
State: closed

**Piano:** R01
**Specifica:** AC19, AC13
**Storie utente:** US08

## Acceptance criteria

- [x] Normalizzazione e validazione della nuova targa precedono ogni assegnazione; tutti i chiamanti continuano a rispettare il vincolo targa/chilometri.
- [x] Togliere la targa a un veicolo con 100 km solleva l'errore previsto e lascia targa, chilometri e altri dati precedenti invariati.
- [x] Modifiche valide, compresa la normalizzazione della targa, mantengono il comportamento esistente.
- [x] Una regressione sul comportamento pubblico dell'entità fallisce prima della correzione e passa dopo; esiti e rilievo coperto registrati.

## Note per l'implementazione

Correggere la causa nel dominio. Nessun refactor generale delle entità o nuovo livello di validazione.

Il ticket comprende chiamanti, dati/fixture, messaggi, test e documentazione interessati. Rispettare i confini di test già approvati; non verificare un effetto PostgreSQL soltanto con DAO simulati. `Relazione_SWE` sempre esclusa.

Fonti: [specifica](../spec.md), [piano e registro](../../../PIANO_REVISIONI_DRIVEHUB.md), [glossario](../../../DriveHub/GLOSSARY.md), [ADR prezzi](../../../DriveHub/docs/adr/0001-base-manuale-e-prezzo-concordato.md).

## Comments

- 31 ottobre 2026: ticket pubblicato da `to-tickets` dopo approvazione di granularità e dipendenze. Esecuzione non ancora avviata; verificare i blocchi prima di iniziare.


### 31 ottobre 2026 — implementazione e chiusura verificata

- Verificato il prerequisito: ticket 01 chiuso, 6/6 criteri ed evidenze R00 Java 21/PostgreSQL presenti. Ripresi OpenJDK Linux 21.0.12.1, Maven 3.9.16 e PostgreSQL 16.15 da `/tmp`, secondo `DriveHub/docs/testing.md`.
- Causa corretta soltanto in `Vehicle.setLicencePlate`: normalizzazione in variabile locale, controllo targa/chilometri, assegnazione dopo il controllo. Firma e messaggio invariati; nessun refactor, dipendenza o modifica di schema/fixture.
- Regressione pubblica `DomainInvariantsTest.testRejectedVehiclePlateChangeLeavesVehicleUnchanged`: veicolo con 100 km, rimozione tramite `null`, stringa vuota o soli spazi/tab; errore previsto e tutti gli otto attributi più `isUsed()` invariati. Prima della correzione: **3 failure attese**, targa persa e `isUsed()` falso; dopo: **3/3 passati** sullo stesso test.
- Verificati i chiamanti di `setLicencePlate`, `setKilometers` e `Vehicle.create`: unico chiamante applicativo del setter `SaleToDealershipService.submitSaleProposal`; controllati UI di invio/errore, catalogo, factory, DAO e CHECK SQL. Nessun adeguamento necessario. Test aggiuntivi confermano normalizzazione, aggiornamenti validi, rimozione con zero km e rifiuto di chilometri positivi senza targa.
- Comandi eseguiti tramite `python3 /tmp/drivehub-r00-maven.py <etichetta> <argomenti Maven>`: `ticket02-red` e `ticket02-green` con `-Dtest=DomainInvariantsTest#testRejectedVehiclePlateChangeLeavesVehicleUnchanged test`; `ticket02-targeted -Dtest=DomainInvariantsTest test`: **15/15**; `ticket02-no-db test`: **28/28**; `ticket02-full -Ppostgres-tests clean test`: **35/35**, 0 failure/errori/saltati, incluse 7 prove PostgreSQL. Compilati 62 sorgenti principali e 8 di test con target 21.
- Cluster temporaneo R00 su `127.0.0.1:55432`: solo DB dedicato e copia applicativa sentinella, isolamento verificato; nessun contatto con il database applicativo preesistente. Primo avvio sandbox impedito dal socket; riavvio e suite DB riusciti con escalation autorizzata. `pg_ctl ... -m fast -w stop` riuscito al termine.
- Revisione finale indipendente Standards: **0 rilievi**; Spec: **0 rilievi**. Hash dei sorgenti e XML Surefire controllati, `git diff --check` superato, 22 file con modifiche locali preesistenti invariati, HEAD invariato, nessuna password nelle evidenze. Nessun commit o modifica alla relazione.
- [Comandi completi, log RED/GREEN/suite, hash, chiamanti e revisione](../../../DriveHub/docs/evidence/r01-vehicle/verification.md). Chiuso il rilievo **#19**; AC13 verificato soltanto nel perimetro del ticket. Tutti i **4/4 criteri** soddisfatti: `State: closed`.

**Limiti:** warning Maven JavaFX preesistente; UI grafica non eseguita, nessuna UI modificata; altri difetti non certificati. Ambiente temporaneo da ricreare se `/tmp` viene rimossa.

**Prossimo passo:** ticket 03 sul cambio email, in una lavorazione separata; R01 resta parziale. Nessun altro ticket avviato in questa sessione.
