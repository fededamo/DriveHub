# 17: Documentare con diagrammi ed evidenze la versione consegnata

Suddivisione e dipendenze approvate dall'utente il 31 ottobre 2026.

**What to build:** Diagrammi e risultati riferibili alla versione corrente sostengono la dimostrazione; artefatti della vecchia versione sono riconoscibili come storici.

**Blocked by:** 02: Conservare il veicolo invariato dopo una modifica non valida; 03: Cambiare email senza compromettere l'accesso; 06: Concludere l'acquisto al totale concordato all'acconto; 10: Accettare o rifiutare una cessione senza doppi pagamenti; 12: Cambiare destinazione senza riaprire auto assegnate o perdere rimborsi; 13: Cancellare identità senza perdere richieste o attribuzioni storiche; 14: Consultare le tabelle senza query nel rendering; 15: Rimuovere FXML e stato di sessione soltanto se inutilizzati

Status: ready-for-agent
State: closed

**Piano:** R09
**Specifica:** AC14
**Storie utente:** US54, US57

## Acceptance criteria

- [x] Diagrammi usati di classi, package, sequenze, casi d'uso e navigazione coerenti con componenti, stati e flussi correnti.
- [x] Individuati e identificati come storici diagrammi e manifest precedenti senza presentarli come prove della nuova versione.
- [x] Nuove evidenze registrano versione/commit e diff, ambiente, comandi, esiti e limiti; nessuna percentuale o riuscita non misurata.
- [x] Diagrammi aggiornati generati/renderizzati quando possibile; assenza degli strumenti registrata senza dichiarare completata quella verifica.
- [x] Riferimenti fra documentazione, flussi e test controllati, mantenendo esclusione completa della relazione.

## Note per l'implementazione

Non rigenerare inutilmente tutti gli artefatti. Preservare la distinzione fra vecchie evidenze e nuove prove; l'eventuale assenza di un commit nuovo richiede identificare anche il diff verificato.

Il ticket comprende chiamanti, dati/fixture, messaggi, test e documentazione interessati. Rispettare i confini di test già approvati; non verificare un effetto PostgreSQL soltanto con DAO simulati. `Relazione_SWE` sempre esclusa.

Fonti: [specifica](../spec.md), [piano e registro](../../../PIANO_REVISIONI_DRIVEHUB.md), [glossario](../../../DriveHub/GLOSSARY.md), [ADR prezzi](../../../DriveHub/docs/adr/0001-base-manuale-e-prezzo-concordato.md).

## Comments

- 31 ottobre 2026: ticket pubblicato da `to-tickets` dopo approvazione di granularità e dipendenze. Esecuzione non ancora avviata; verificare i blocchi prima di iniziare.

- 3 novembre 2026: avviato solo17; letti AGENTS, piano, glossario, ADR0001, testing, installation, architecture ed evidenze16. Verificati01–16 chiusi senza criteri aperti. Baseline completa1507file (anche ignorati, modificati e non tracciati), HEAD/indice e diff iniziale salvati; relazione esclusa. Originali diagrammi/manifest conservati, nuova selezione corrente separata. Java21/PG16 temporanei ricontrollati; nuovo cluster sacrificabile127.0.0.1:55435 con DB dedicati e sentinella.394/394del16 storico; render, prove e review17 ancora da completare. Nessun commit/staging o lavoro18.

- 3 novembre 2026 — chiusura: **5/5criteri verificati**, solo17/AC14/#14 e R09 completati;18/20rilievi chiusi.18sorgenti PlantUML e18SVG correnti per classi/package/sequenze/casi d’uso/navigazione e stati, con riscontri a codice/test e precisazioni teoriche16.37artefatti visivi e vecchi manifest identificati come storici e conservati identici, senza rigenerazione. Baseline1507file inclusi ignorati/modificati/nontracciati; versione con diff locale, non solo HEAD. Nuove prove Java21/PG16 ricontrollati, cluster sacrificabile127.0.0.1:55435 e Xvfb91, DB dedicati/sentinella: mirati79/79, UI CHECK SUCCESS, APP STARTUP SUCCESS, suite finale394/394 (47senzaDB/347PostgreSQL), zero failure/errori/salti;394/394del16 storico. Tentativi fallito/interrotto conservati separatamente. Render SVG/PNG finali exit0 e ispezione, riferimenti controllati. Review indipendenti Standards0violazioni/0smell; Spec1P2 sui ritorni dei dialoghi cliente corretto, nuovo render e follow-up indipendenti0residui. Sentinella READ ONLY e hash13tabelle7sequenze invariati; servizi arrestati.1507file iniziali presenti,1502identici,5aggiornamenti intenzionali,zeroeliminazioni; codice/POM/test/schema/demo/evidenze01–16/ticket18 intatti, HEAD/indice invariati. [Versione, diff, ambiente, comandi, log/XML, render, review e limiti](../../../DriveHub/docs/evidence/r09-diagrams/verification.md). Nessun commit/staging, relazione sempre esclusa, nessun test artificiale della documentazione o lavoro18. Limiti Linux/WSL/Xvfb, nessuna certificazione screen reader/altriOS/stampaA4; non tutti i gesti GUI riesercitati. R11/ticket18 e AC13 trasversale aperti; nessun residuo17.
