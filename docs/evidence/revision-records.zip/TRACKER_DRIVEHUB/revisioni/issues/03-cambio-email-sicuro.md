# 03: Cambiare email senza compromettere l'accesso

Suddivisione e dipendenze approvate dall'utente il 31 ottobre 2026.

**What to build:** L'utente può aggiornare la propria email; un valore invalido o duplicato viene rifiutato prima del salvataggio e l'accesso precedente resta valido.

**Blocked by:** 01: Rendere build e test ripetibili senza toccare i dati applicativi

Status: ready-for-agent
State: closed

**Piano:** R01
**Specifica:** AC08, AC13
**Storie utente:** US06, US07

## Acceptance criteria

- [x] Il servizio applica prima della persistenza la validazione del dominio, preservando normalizzazione e controllo dei duplicati.
- [x] Un'email con spazi interni viene rifiutata senza cambiare il dato persistito; l'utente continua a usare le credenziali precedenti.
- [x] Email valida aggiornata e riletta correttamente; duplicato rifiutato senza effetti parziali.
- [x] Verificati servizio e persistenza isolata per successo e fallimento, oltre ai chiamanti della gestione identità.

## Note per l'implementazione

Riutilizzare regole esistenti. Non cambiare l'intero modello di identità o introdurre nuove politiche di autenticazione.

Il ticket comprende chiamanti, dati/fixture, messaggi, test e documentazione interessati. Rispettare i confini di test già approvati; non verificare un effetto PostgreSQL soltanto con DAO simulati. `Relazione_SWE` sempre esclusa.

Fonti: [specifica](../spec.md), [piano e registro](../../../PIANO_REVISIONI_DRIVEHUB.md), [glossario](../../../DriveHub/GLOSSARY.md), [ADR prezzi](../../../DriveHub/docs/adr/0001-base-manuale-e-prezzo-concordato.md).

## Comments

- 31 ottobre 2026: ticket pubblicato da `to-tickets` dopo approvazione di granularità e dipendenze. Esecuzione non ancora avviata; verificare i blocchi prima di iniziare.
- 31 ottobre 2026 — Avviato soltanto il ticket 03: ticket 01 e 02 verificati chiusi con tutti i criteri soddisfatti. Ripreso ambiente R00 Java 21/PostgreSQL dedicato; regressione tramite `AuthService.changeEmail` e `login`. Nessun commit, modifiche locali precedenti preservate, relazione esclusa.

### 31 ottobre 2026 — implementazione e chiusura verificata

- Causa: `AuthService.changeEmail` scriveva direttamente l'email senza validazione del dominio; il dialog la validava soltanto dopo il commit. Correzione minima: `verifyPasswordBeforeAction` restituisce l'utente già caricato; `changeEmail` chiama `User.updateEmail` e persiste `user.getEmail()` dopo la validazione. Normalizzazione, messaggi, password, UNIQUE/trigger duplicati e rollback preservati; nessuna nuova politica, dipendenza, modifica UI, schema o fixture.
- Regressione pubblica `AuthServiceIntegrationTest.rejectedEmailPreservesStoredIdentityAndLogin`, tre ruoli su PostgreSQL dedicato: **RED 3 failure attese**, nessun errore/salto, perché non veniva sollevata eccezione; **GREEN stesso test 3/3**. Verifica successiva di login/rilettura conferma dato persistito, ID, nome, cognome, hash e ruolo invariati dopo il rifiuto.
- Classe finale: **18/18**. Spazi interni rifiutati (3), successo con normalizzazione e rilettura/nuovo accesso (3), duplicati con entrambe le identità/accessi invariati (5: 2 nello stesso ruolo, 3 fra ruoli), password errata (3), email null/vuota/soli spazi/senza chiocciola (4). Tutte le prove tramite servizio pubblico e DAO PostgreSQL reali; reset isolato prima di ogni caso.
- Chiamanti identità controllati: unico `changeEmail` in `AccountManagementDialog`, tutte le dashboard, `App`/`AppContext`, `LoginView`, `User`/`AbstractUser` e factory dei tre ruoli, `UserDao`/`PostgresUserDao`, routing ruoli, UNIQUE/CHECK/trigger/vista SQL; tutti gli usi dell'helper password (`changeEmail`, `changePassword`, `deleteAccount`). Nessun adeguamento necessario fuori dal servizio.
- Comandi tramite `python3 /tmp/drivehub-r00-maven.py <etichetta> <argomenti Maven>`: `ticket03-red` e `ticket03-green` con `-Ppostgres-tests -Dtest=AuthServiceIntegrationTest#rejectedEmailPreservesStoredIdentityAndLogin test`; `ticket03-targeted -Ppostgres-tests -Dtest=AuthServiceIntegrationTest test` → **18/18**; `ticket03-no-db test` → **28/28**; `ticket03-full -Ppostgres-tests clean test` → **53/53**, 0 failure/errori/saltati, incluse 25 prove PostgreSQL. Totali XML Surefire controllati; ricompilati 62 sorgenti principali e 9 test, target 21.
- Ambiente R00: OpenJDK Linux 21.0.12.1, Maven 3.9.16, PostgreSQL 16.15. Primo avvio sandbox fallito per socket vietato; avvio e test DB riusciti con escalation autorizzata. Solo cluster temporaneo `127.0.0.1:55432`, DB/ruolo dedicato e copia applicativa sentinella; isolamento e fixture verificati nella suite. Nessun SQL al database applicativo preesistente. Server arrestato con `pg_ctl ... -m fast -w stop`.
- Revisione finale skill `code-review`, due agenti indipendenti su diff locale rispetto a HEAD (adattata al divieto di commit): **Standards 0 rilievi; Spec 0 rilievi**. Manifest SHA-256, XML, log e `git diff --check` controllati; 31/31 file locali preesistenti invariati, compresi ticket 01/02; HEAD invariato, nessuna password privata nelle evidenze. Nessun commit, relazione sempre esclusa.
- [Rapporto, comandi, log RED/GREEN/mirati/suite e hash](../../../DriveHub/docs/evidence/r01-email/verification.md). Tutti i **4/4 criteri** soddisfatti: **State: closed**. Chiuso rilievo **#8** e completata **R01**; AC13 soltanto nel perimetro lavorato.

**Limiti:** UI grafica non eseguita, nessuna UI modificata; warning JavaFX preesistente; nessuna certificazione degli altri difetti o nuove politiche/concorrenza identità; ambiente `/tmp` temporaneo.

**Prossimo passo:** ticket 04 / R02 soltanto in una successiva richiesta. Nessun altro ticket avviato in questa sessione.
