# 08: Confermare vendita o noleggio insieme alla cancellazione dei test drive

Suddivisione e dipendenze approvate dall'utente il 31 ottobre 2026.

**What to build:** Vendita e noleggio non possono risultare riusciti se la cancellazione obbligatoria dei test drive futuri fallisce.

**Blocked by:** 04: Eseguire addebiti e rimborsi senza perdere aggiornamenti

Status: ready-for-agent
State: closed

**Piano:** R04, R06
**Specifica:** AC12, AC13
**Storie utente:** US27, US43, US44, US45

## Acceptance criteria

- [x] Vendita e conferma noleggio cancellano tutti i test drive futuri del veicolo nella stessa transazione dell'operazione economica, conservando quelli già avvenuti.
- [x] Observer mantiene una responsabilità motivata; il percorso obbligatorio non apre una seconda transazione dopo il commit e non nasconde errori necessari al rollback.
- [x] Aggiornati interfaccia degli eventi, osservatori, composizione dei servizi e tutti i chiamanti coinvolti senza infrastrutture distribuite.
- [x] Un errore di cancellazione dimostrato attraverso il confine del servizio annulla su PostgreSQL anche addebito, vendita/noleggio, richiesta e stato coinvolti.
- [x] Percorso riuscito e conservazione dello storico verificati per acquisto e noleggio; la conferma noleggio annulla tutti i futuri, anche fuori dal periodo prenotato.

## Note per l'implementazione

La politica commerciale è già approvata; non ridurre la cancellazione ai soli giorni coincidenti. I conflitti concorrenti di prenotazione saranno dimostrati nel ticket 11.

Il ticket comprende chiamanti, dati/fixture, messaggi, test e documentazione interessati. Rispettare i confini di test già approvati; non verificare un effetto PostgreSQL soltanto con DAO simulati. `Relazione_SWE` sempre esclusa.

Fonti: [specifica](../spec.md), [piano e registro](../../../PIANO_REVISIONI_DRIVEHUB.md), [glossario](../../../DriveHub/GLOSSARY.md), [ADR prezzi](../../../DriveHub/docs/adr/0001-base-manuale-e-prezzo-concordato.md).

## Comments

- 31 ottobre 2026: ticket pubblicato da `to-tickets` dopo approvazione di granularità e dipendenze. Esecuzione non ancora avviata; verificare i blocchi prima di iniziare.

- 2 novembre 2026: avviato soltanto il ticket 08, dopo verifica `State: closed`
  di 01–07, incluso prerequisito 04. Baseline locale prima delle modifiche in
  `/tmp/drivehub-ticket08-baseline`; nessun commit/staging, relazione esclusa.
  Consultate evidenze 04/06/07 e `docs/testing.md`. File R00 assenti, ambiente
  temporaneo 07 presente e verificato prima del riuso. Prima partenza sandbox
  rifiutata sui socket; avvio del solo cluster dedicato con escalation autorizzata.
- RED servizi pubblici: entrambi i casi acquisto/noleggio restituiscono successo
  nonostante l'errore PostgreSQL di cancellazione (2 failure attese). Stessa
  regressione GREEN 2/2 dopo notifica sincrona sulla connessione del chiamante.
  Prima estensione 8/8: storico, tutti i futuri, altri veicoli, nessun futuro,
  confine −1/0/+1 microsecondo. Suite e review finali in corso; ticket ancora aperto.

### Chiusura — 2 novembre 2026

- **5/5 criteri soddisfatti e verificati**. Acquisto e conferma noleggio pubblicano
  `VehicleCommitmentEvent` prima del commit, con la connessione economica corrente.
  Observer mantiene la politica di cancellazione di tutti i test drive futuri,
  conservando lo storico; nessuna seconda transazione o eccezione nascosta.
- Mappati acquisto/noleggio/test drive, eventi/publisher/osservatori, tutti i DAO
  coinvolti, AppContext, letture, fixture, chiamanti cliente/venditore e messaggi.
  Nessuna vista modificata: prove JavaFX/tastiera non necessarie in questa sessione.
  Fixture aggiuntive soltanto nel DB dedicato; schema/demo precedenti invariati.
- `python3 /tmp/drivehub-ticket08-maven.py red -Ppostgres-tests
  -Dtest=TestDriveCancellationIntegrationTest test` → 2 failure attese: il servizio
  nasconde l'errore. Stessi argomenti `green` → 2/2; ampliamento `cases` → 8/8.
  Trigger PostgreSQL AFTER DELETE osserva addebito, operazione e tutte le
  cancellazioni già eseguiti, poi fallisce: il servizio propaga l'errore e nuove
  letture confermano rollback di conto, vendita/noleggio, richiesta/accordo,
  stato e due test drive. Nessuna scrittura/cancellazione parziale.
- Successo e confini: ieri conservato, futuri +1/+6/+20 cancellati per più clienti,
  anche fuori noleggio +5…+7; altro veicolo intatto; nessun futuro ammesso.
  Confine transazionale PostgreSQL −1/0/+1 microsecondo coerente nei due servizi:
  uguale e precedente conservati. Nessun cambiamento al clock/schema.
- `python3 /tmp/drivehub-ticket08-maven.py targeted -Ppostgres-tests
  -Dtest=TestDriveCancellationIntegrationTest,PurchaseConcurrencyIntegrationTest,PurchaseAgreementIntegrationTest,BalanceConcurrencyIntegrationTest,PriceCalculatorServiceTest,PriceSelectionIntegrationTest test`
  → **117/117**. `python3 /tmp/drivehub-ticket08-maven.py full -Ppostgres-tests
  clean test` → **171/171**, zero failure/errori/saltati, 40 senza DB e 131 PostgreSQL.
  Inclusi conti04, formula/base/centesimi05, accordo06, lock/rilettura/unicità07,
  fixture, isolamento e sentinella. Java21/PG16 verificati, cluster arrestato.
- Review indipendenti Standards **0 violazioni/0 smell azionabili**, Spec **0 rilievi**,
  sul diff della sola sessione (13 file, SHA256
  `52afb2fc12e7df429001b9c6a7cb78250ff672861b7324d47805513055a95f6c`).
  Baseline, RED/GREEN, XML/log, hash finali, patch e conservazione collegati nelle
  [evidenze](../../../DriveHub/docs/evidence/r04-test-drive-atomic/verification.md).
  Tutto il lavoro 01–07 e le sue prove storiche preservati; HEAD/indice invariati.
- Limiti: nessuna verifica UI perché nessuna vista cambiata; warning JavaFX
  preesistente, /tmp temporanea. Conflitti prenotazioni 11, altre transizioni e
  prestazioni esclusi. AC12/AC13 restano parziali fuori08, 7/20 rilievi chiusi.
  Nessun commit/staging, Relazione_SWE sempre esclusa. R04 completata per06–08.
  Prossimo passo: nessun altro ticket avviato; prosecuzione solo su nuova richiesta.
