# 07: Elaborare saldo, rifiuto e scadenza una sola volta

Suddivisione e dipendenze approvate dall'utente il 31 ottobre 2026.

**What to build:** Due sessioni non possono concludere o rimborsare più volte la stessa richiesta di acquisto, né aggirare approvazione e scadenza.

**Blocked by:** 04: Eseguire addebiti e rimborsi senza perdere aggiornamenti

Status: ready-for-agent
State: closed

**Piano:** R04
**Specifica:** AC06, AC13
**Storie utente:** US23, US24, US25, US26

## Acceptance criteria

- [x] Definita una protezione condivisa della richiesta riletta nella transazione; tutti i percorsi di saldo, rifiuto e scadenza verificano tipo/stato e scritture interessate.
- [x] L'elaborazione delle scadenze non usa come autorità un oggetto letto prima della transazione; chiamanti aggiornati al protocollo condiviso.
- [x] Prove PostgreSQL con connessioni distinte coprono saldo/saldo, saldo/rifiuto e saldo/scadenza senza doppia vendita, doppio addebito o doppio rimborso.
- [x] Approvazione mancante e richiesta scaduta restano rifiutate dal servizio; il rifiuto conserva il rimborso esistente.
- [x] Su acconto 4.000 €, la scadenza genera penale 800 € e rimborso 3.200 € una sola volta; ripetere il controllo non cambia ancora il conto.
- [x] Errori annullano tutte le scritture della fase; oggetti, richieste e registro risultano coerenti dopo rilettura.

## Note per l'implementazione

Il protocollo comune di protezione della richiesta sarà riutilizzato dalla cessione nel ticket 10. Non introdurre nuovi comandi di annullamento o regole economiche.

Il ticket comprende chiamanti, dati/fixture, messaggi, test e documentazione interessati. Rispettare i confini di test già approvati; non verificare un effetto PostgreSQL soltanto con DAO simulati. `Relazione_SWE` sempre esclusa.

Fonti: [specifica](../spec.md), [piano e registro](../../../PIANO_REVISIONI_DRIVEHUB.md), [glossario](../../../DriveHub/GLOSSARY.md), [ADR prezzi](../../../DriveHub/docs/adr/0001-base-manuale-e-prezzo-concordato.md).

## Comments

- 31 ottobre 2026: ticket pubblicato da `to-tickets` dopo approvazione di granularità e dipendenze. Esecuzione non ancora avviata; verificare i blocchi prima di iniziare.

### Implementazione e chiusura — 2 novembre 2026

- Passaggio al 07 autorizzato esplicitamente dall'utente. Prerequisito diretto 04
  controllato chiuso. **Ticket 06 rimane aperto in verifica finale**, file e lavoro
  locale preservati; nessuna attesa della sua chiusura e nessuna chiusura implicita.
- Baseline dedicata acquisita prima degli interventi: 272 file correnti, manifest
  SHA-256 e copie esterne di piano/ticket. Revisionato solo il diff di questa
  sessione, distinto dal lavoro non committato precedente. 266 file preesistenti
  identici; 6 modificati intenzionalmente più un nuovo test. HEAD/indice invariati.
- Mappati saldo, rifiuto, approvazione, scadenza, chiamanti cliente/venditore/accesso
  e tutti gli usi dei DAO condivisi. `findByIdForUpdate` rilegge e protegge la richiesta
  sulla connessione della transazione; approvazione inclusa per evitare aggiornamenti
  obsoleti. Verificati tipo, approvazione/scadenza e transizione da BLOCKED; controllo
  delle righe per conto/richiesta e degli ID per gli inserimenti. La scadenza usa solo
  gli ID dell'elenco iniziale, poi decide sui dati riletti; notifica dopo commit.
- RED reale: `python3 /tmp/drivehub-ticket07-maven.py red -Ppostgres-tests
  -Dtest=PurchaseConcurrencyIntegrationTest#concurrentCompletionsChargeAndSellOnlyOnce test`
  → **1 failure attesa**, entrambe le sessioni concludevano la stessa richiesta.
  Stessi argomenti con etichetta `green` → **1/1** dopo correzione.
- Gare con connessioni distinte, gate SQL e PID/attese attestati prima del rilascio,
  senza sleep/mock: saldo/saldo, saldo/rifiuto nei due ordini, saldo/scadenza,
  rifiuto/rifiuto, scadenza/scadenza, approvazioni obsolete e proroga nei due ordini.
  Letture da nuovi contesti confermano un solo esito. Acconto 4000: penale 800,
  rimborso 3200 una volta; ripetizione senza altri movimenti o record.
- Approvazione incompleta, richieste scadute/tipo errato, stato veicolo incoerente
  e conto mancante verificati. **24** casi PostgreSQL di errore/scrittura saltata
  su conto, vendita, richiesta e veicolo provano rollback integrale; compresi guasti
  successivi al movimento già avvenuto. Totale persistito 06 e protocollo conti 04
  invariati. Nessuna nuova regola economica, modifica UI/schema o fixture applicativa.
- Mirati: `python3 /tmp/drivehub-ticket07-maven.py final-targeted -Ppostgres-tests
  -Dtest=PurchaseConcurrencyIntegrationTest,PurchaseAgreementIntegrationTest,BalanceConcurrencyIntegrationTest test`
  → **88/88** (60 nuovi casi 07, 12 accordo 06, 16 conti 04).
  Suite finale: `python3 /tmp/drivehub-ticket07-maven.py full -Ppostgres-tests clean test`
  → **163/163**, zero failure/errori/saltati; 40 senza DB e 123 PostgreSQL.
  Ricompilati 63 sorgenti principali e 14 test con target 21 e lint.
- Ambiente ripredisposto perché R00 temporaneo assente: Java 21.0.12.1, Maven 3.9.16,
  PostgreSQL 16.15 da pacchetti ufficiali Ubuntu estratti in /tmp; nessuna installazione
  di sistema. Solo cluster sacrificabile 127.0.0.1:55432, drivehub_test non privilegiato
  e nuova copia sentinella drivehub; isolamento/sentinella/fixture passati. Nessun
  contatto al DB applicativo preesistente. Server arrestato al termine.
- Review indipendenti su patch fissata: **Standards 0 violazioni / 1 osservazione
  non bloccante** sul supporto gare simile al 04; **Spec 0 rilievi**. Nessun refactor
  estraneo del supporto test. Hash, XML, link e whitespace controllati; nessuna
  password privata nelle evidenze. Nessun codice/test cambiato dopo suite e review.
- [Rapporto, log, XML, baseline, patch, preservazione e review](../../../DriveHub/docs/evidence/r04-purchase-once/verification.md).
  **6/6 criteri soddisfatti: State: closed.** Rilievo #6 chiuso, totale **6/20**
  (#1, #4, #6, #8, #17, #19); #13 resta parziale e trasversale.
- Limiti: nessuna verifica grafica, nessuna UI modificata; warning JavaFX preesistente;
  Observer/cancellazioni atomiche ai test drive restano al ticket 08. R04 parziale:
  **06 aperto in verifica finale, 07 chiuso, 08 non avviato**. Ambiente /tmp temporaneo;
  relazione sempre esclusa. Nessun commit, staging, push o pubblicazione.
- Prossimo passo: riprendere la verifica finale del 06; altri ticket soltanto in una
  successiva richiesta. Nessun altro ticket lavorato in questa sessione.
