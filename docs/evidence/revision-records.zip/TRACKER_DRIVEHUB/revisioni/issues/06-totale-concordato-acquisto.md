# 06: Concludere l'acquisto al totale concordato all'acconto

Suddivisione e dipendenze approvate dall'utente il 31 ottobre 2026.

**What to build:** Il cliente versa l'acconto e, dopo l'autorizzazione, paga il saldo calcolato sul totale fissato anche se il manager modifica basi o sconti.

**Blocked by:** 04: Eseguire addebiti e rimborsi senza perdere aggiornamenti; 05: Usare prezzo consigliato o base manuale lungo catalogo e noleggio

Status: ready-for-agent
State: closed

**Piano:** R04
**Specifica:** AC11, AC13
**Storie utente:** US19, US20, US21, US22

## Acceptance criteria

- [x] Totale concordato conservato nella richiesta quando viene addebitato l'acconto del 20%; dominio, persistenza e fixture aggiornati insieme.
- [x] Avvio e completamento mantengono prenotazione atomica del veicolo, controlli di approvazione/scadenza e addebiti protetti del conto.
- [x] Con totale 20.000 € e acconto 4.000 €, modifiche successive di basi/sconti lasciano saldo 16.000 € e vendita registrata da 20.000 €.
- [x] La regola vale sia per base del modello sia per base manuale e non dipende dall'anno corrente al momento del saldo.
- [x] Interfaccia mostra totale concordato e saldo coerenti dopo rilettura in una nuova sessione; fondi insufficienti o errori lasciano dati e saldo invariati.
- [x] Flusso servizio/persistenza verificato e documentazione del percorso aggiornata.

## Note per l'implementazione

Riutilizzare ADR 0001. Questo ticket fissa l'accordo economico; la competizione fra diverse elaborazioni della richiesta è verificata nel ticket 07.

Il ticket comprende chiamanti, dati/fixture, messaggi, test e documentazione interessati. Rispettare i confini di test già approvati; non verificare un effetto PostgreSQL soltanto con DAO simulati. `Relazione_SWE` sempre esclusa.

Fonti: [specifica](../spec.md), [piano e registro](../../../PIANO_REVISIONI_DRIVEHUB.md), [glossario](../../../DriveHub/GLOSSARY.md), [ADR prezzi](../../../DriveHub/docs/adr/0001-base-manuale-e-prezzo-concordato.md).

## Comments

- 31 ottobre 2026: ticket pubblicato da `to-tickets` dopo approvazione di granularità e dipendenze. Esecuzione non ancora avviata; verificare i blocchi prima di iniziare.


## Esecuzione — 31 ottobre 2026

- Prerequisiti 04/05 e tutti i ticket 01–05 controllati `State: closed` prima degli interventi.
  Letti AGENTS, piano, glossario, ADR 0001, testing.md ed evidenze del ticket 05.
- Baseline iniziale: `/tmp/drivehub-ticket06-baseline`, 242 file del progetto;
  lavoro locale preesistente incluso e preservato. Confronto della sola sessione,
  nessun commit/staging, Relazione_SWE sempre esclusa.
- Mappati Request/factory, tutti i SELECT/INSERT/UPDATE e mapping del DAO, schema,
  demo e fixture ticket 04, avvio/approvazione/saldo/rifiuto/scadenza, consultazione
  richieste, cessioni e viste cliente/venditore. Snapshot `agreedTotal` e acconto
  immutabili; saldo dalla loro differenza; approvazione conserva l'accordo.
- PostgreSQL reale R00 su 127.0.0.1:55432, DB/ruolo dedicati e copia applicativa
  sentinella; nessun collegamento al DB applicativo preesistente. Formula condivisa,
  selezione esplicita della base e arrotondamento del ticket 05 invariati; prenotazione
  atomica e protocollo conti del ticket 04 conservati.

### Comandi ed esiti

Dalla radice DriveHub; launcher privato documentato in docs/testing.md:

| Comando `python3 /tmp/drivehub-r00-maven.py <etichetta> ...` | Esito |
|---|---|
| `ticket06-agreement-red -Ppostgres-tests -Dtest=PurchaseAgreementIntegrationTest test` | 2 failure attese: vendita 28000/24000 invece di 20000, in automatico/manuale |
| `ticket06-agreement-green-v3` con gli stessi argomenti e la stessa regressione | 2/2 |
| `ticket06-targeted -Ppostgres-tests -Dtest=RequestAgreementTest,PurchaseAgreementIntegrationTest,PriceCalculatorServiceTest,PriceSelectionIntegrationTest,BalanceConcurrencyIntegrationTest,DemoSqlValidationTest test` | 57/57, nessuna failure/errore/salto |
| `ticket06-ui-final-compile -DskipTests test-compile` | BUILD SUCCESS; non esegue test |
| `ticket06-final-full -Ppostgres-tests clean test` | 103/103, 40 senza DB e 63 PostgreSQL, inclusi isolamento/sentinella e 16 test conti; nessuna failure/errore/salto |

La regressione RED/GREEN è stata poi estesa a 12 prove PostgreSQL e 7 di dominio.
Importi 20000/4000/16000, centesimi 20000.03/4000.01/16000.02, entrambe le modalità,
rilettura/nuovo AppContext e accordo riferito all'anno precedente; fondi insufficienti
ad acconto/saldo, approvazione/scadenza preservate. Trigger temporanei osservano
l'addebito e poi fanno fallire inserimento richiesta/vendita, cancellazione richiesta
e aggiornamento veicolo: rilettura senza effetti parziali. Cessioni e prezzi ticket 05
verificati dalla suite. Nessun mock certifica la persistenza.

Prime esecuzioni non contate come successo: sandbox senza server persistente;
primo RED con un caso di fixture accidentalmente a prezzo invariato, poi corretto;
due GREEN bloccati dalla fixture demo incompleta, prima di allineare tutte le 14 righe.
Controllo JavaFX affinato per navigazione tra tab e focus delle sole tabelle modificate;
nessuno di questi tentativi sostituisce le prove finali.

### Limiti e prossimo passo

Schema ricreabile secondo D02, senza migrazione storica: installazioni esistenti
richiedono aggiornamento dello schema e totali realmente concordati, mai dedotti dal
listino corrente. L'anno precedente è una fixture persistita, non una modifica del
clock di sistema. JavaFX su fixture ridotta; prestazioni e screen reader non certificati.
La competizione fra completamento/rifiuto/scadenza resta al ticket 07; eventi e
transizioni ai rispettivi ticket. Ambiente `/tmp` temporaneo.

Raccolta GUI e review indipendente concluse; chiusura registrata qui sotto.
[Evidenze della sessione](../../../DriveHub/docs/evidence/r04-agreement/verification.md).


## Chiusura — 2 novembre 2026

**6/6 criteri verificati, State: closed.** Rilievo #11 / AC11 chiuso.

- Le review indipendenti sul diff della sola sessione, già concluse il 31 ottobre,
  sono ora registrate: [Standards 0 violazioni / 0 smell](../../../DriveHub/docs/evidence/r04-agreement/standards-review.md)
  e [Spec 0 rilievi](../../../DriveHub/docs/evidence/r04-agreement/spec-review.md).
- Confermata da entrambi i revisori la compatibilità con il ticket 07, autorizzato
  e chiuso separatamente: nessun impedimento alla chiusura del 06.
- Verificati i 17 hash interni dello snapshot 06 contro la baseline 07 e i 7 hash
  certificati dal 07 contro i file correnti prima degli aggiornamenti documentali
  di chiusura. Nessun altro sorgente alterato.
  Il vecchio /tmp della sessione 06 è stato rimosso; patch/hash persistenti e
  baseline 07 conservano la tracciabilità. Nessuna rigenerazione del diff 06
  includendo per errore le modifiche del 07.
- XML della [suite corrente del 07](../../../DriveHub/docs/evidence/r04-purchase-once/verification.md)
  ricontrollati: **163/163**, zero failure/errori/salti, compresi i **7 test di dominio
  e 12 PostgreSQL del 06**, isolamento/sentinella e protocollo conti. Restano valide
  le prove RED/GREEN e GUI/tastiera in due JVM del 06: viste e harness immutati.
- Questa ripresa cambia solo documentazione, stato e prove di chiusura: nessun codice,
  test, schema o fixture modificato; nessun nuovo test/DB/GUI eseguito. Hash dei sorgenti,
  collegamenti, whitespace, HEAD e indice verificati. Tutto il lavoro locale, incluso
  il 07, preservato; nessun commit/staging. Relazione_SWE sempre esclusa.
- R04 resta parziale per il solo ticket 08, non avviato. Nessun altro ticket lavorato;
  prossimo passo soltanto su nuova richiesta. Limiti storici/schema ricreabile e GUI
  su fixture ridotta rimangono documentati nelle evidenze.
