# 11: Prenotare noleggi e test drive senza disponibilità impossibili

Suddivisione e dipendenze approvate dall'utente il 31 ottobre 2026.

**What to build:** Più istanze desktop rispettano disponibilità del veicolo, limite dei test drive e priorità commerciale quando prenotano contemporaneamente.

**Blocked by:** 08: Confermare vendita o noleggio insieme alla cancellazione dei test drive

Status: ready-for-agent
State: closed

**Piano:** R06
**Specifica:** AC05, AC13
**Storie utente:** US35, US36, US41, US42

## Acceptance criteria

- [x] Controlli e inserimenti coordinati con lock coerenti su veicolo e cliente, usando la stessa transazione e il protocollo dei conti già disponibile.
- [x] DB protegge periodi di noleggio da sovrapposizioni; unicità test drive per veicolo/data esistente conservata.
- [x] Due prenotazioni di noleggio sovrapposte su connessioni distinte non vengono entrambe confermate; periodi validi non sovrapposti restano prenotabili.
- [x] Test drive concorrenti, anche su veicoli differenti dello stesso cliente, non superano il limite tre; orari e regole esistenti preservati.
- [x] Competizione noleggio/test drive rispetta la priorità commerciale e la cancellazione atomica del ticket 08 senza lasciare prenotazioni incompatibili.
- [x] Date inclusive, limiti temporali, saldo insufficiente e rollback verificati con sincronizzazione esplicita e fixture indipendenti.

## Note per l'implementazione

Non considerare prova di correttezza concorrente un controllo eseguito prima di un inserimento senza lock o un test con soli DAO simulati.

Il ticket comprende chiamanti, dati/fixture, messaggi, test e documentazione interessati. Rispettare i confini di test già approvati; non verificare un effetto PostgreSQL soltanto con DAO simulati. `Relazione_SWE` sempre esclusa.

Fonti: [specifica](../spec.md), [piano e registro](../../../PIANO_REVISIONI_DRIVEHUB.md), [glossario](../../../DriveHub/GLOSSARY.md), [ADR prezzi](../../../DriveHub/docs/adr/0001-base-manuale-e-prezzo-concordato.md).

## Comments

- 31 ottobre 2026: ticket pubblicato da `to-tickets` dopo approvazione di granularità e dipendenze. Esecuzione non ancora avviata; verificare i blocchi prima di iniziare.

- 2 novembre 2026: implementato solo 11, prerequisito08 e ticket 01–10 verificati chiusi. Baseline locale prima delle modifiche **259/259**, lavoro precedente preservato; nessun commit/staging e Relazione_SWE esclusa.
- Lock condivisi veicolo → cliente NO KEY UPDATE → conto; controlli/prezzo/scritture sulla stessa transazione. EXCLUDE PostgreSQL dei periodi inclusivi, unicità e orari TD conservati, limite tre anche su veicoli diversi. Priorità commerciale e rollback Observer 08 preservati.
- Otto regressioni RED/GREEN con sorgenti identici, incluse gara mista e gara a tre con saldo acquisto: riprodotto deadlock reale, poi corretto rifiutando stato non prenotabile prima del lock cliente. Connessioni/PID distinti, gate osservati, nessuno sleep. Rollback dopo INSERT/cancellazioni effettivi e fondi insufficienti verificati.
- Mirati finali **245/245**; suite finale **297/297**, zero failure/errori/salti (**47 senza DB,  250 PostgreSQL**), isolamento/sentinella inclusi. La suite 296/296 è intermedia, precedente all'ultima correzione; 259/259 del 10 resta storica.
- Review indipendenti Standards **0 violazioni/0 smell azionabili**, Spec **0 rilievi**, sul solo diff di 14 file dalla baseline locale. Nessun codice/test modificato dopo suite e review.
- **6/6 criteri verificati, State: closed, AC05/#5 chiuso.** R06 resta parziale per 12, AC13 trasversale. [Versione, comandi, log/XML, review e limiti](../../../DriveHub/docs/evidence/r06-bookings/verification.md).
- Nessuna vista modificata, quindi nessuna nuova prova GUI/tastiera. PG 16 temporaneo arrestato, Xvfb non avviato. Schema esistente da adeguare con btree_gist e risoluzione degli overlap prima dell'uso; nessun reset applicativo. Nessun ticket successivo avviato.
