# 12: Cambiare destinazione senza riaprire auto assegnate o perdere rimborsi

Suddivisione e dipendenze approvate dall'utente il 31 ottobre 2026.

**What to build:** Il venditore alterna vendita e noleggio solo quando consentito; i noleggi futuri cancellati vengono rimborsati integralmente.

**Blocked by:** 11: Prenotare noleggi e test drive senza disponibilità impossibili

Status: ready-for-agent
State: closed

**Piano:** R06
**Specifica:** AC07, AC13
**Storie utente:** US37, US38, US39, US40

## Acceptance criteria

- [x] Il comando consente soltanto gli stati di partenza e destinazione ammessi tra vendita e noleggio; venduto, riservato e in attesa non sono aggirabili.
- [x] Noleggio in corso impedisce il passaggio a vendita anche se iniziato ieri; testati confini inclusivi e noleggio che comprende oggi.
- [x] Per i noleggi futuri, cancellazioni, rimborsi integrali e cambio stato avvengono nella stessa transazione con il protocollo di lock condiviso.
- [x] Conto mancante o errore di un rimborso impedisce il successo parziale, compresi casi di più clienti da rimborsare.
- [x] Competizione tra cambio destinazione e nuova prenotazione non lascia veicolo vendibile con noleggi incompatibili.
- [x] Prove su servizio/persistenza e controlli della vista interessata dimostrano successo, rifiuto e rollback; aggiornati messaggi e documentazione del flusso.

## Note per l'implementazione

La dipendenza 11 porta già con sé conti e cancellazioni atomiche. Nessuna nuova politica di penali per cancellazioni dei noleggi futuri.

Il ticket comprende chiamanti, dati/fixture, messaggi, test e documentazione interessati. Rispettare i confini di test già approvati; non verificare un effetto PostgreSQL soltanto con DAO simulati. `Relazione_SWE` sempre esclusa.

Fonti: [specifica](../spec.md), [piano e registro](../../../PIANO_REVISIONI_DRIVEHUB.md), [glossario](../../../DriveHub/GLOSSARY.md), [ADR prezzi](../../../DriveHub/docs/adr/0001-base-manuale-e-prezzo-concordato.md).

## Comments

- 31 ottobre 2026: ticket pubblicato da `to-tickets` dopo approvazione di granularità e dipendenze. Esecuzione non ancora avviata; verificare i blocchi prima di iniziare.

- 2 novembre 2026: implementato soltanto il ticket 12, prerequisiti 01–11 controllati chiusi. Nuova baseline 297/297 prima delle modifiche; quattro coppie RED/GREEN con sorgente del test identico. Mirati 278/278 e suite completa finale 330/330 (47 senza DB, 283 PostgreSQL), zero failure/errori/salti, inclusi isolamento e sentinella. JavaFX/Robot/tastiera UI CHECK SUCCESS, cinque schermate ispezionate. Lock 11, conti 04 e Observer 08 conservati; nessuna nuova penale. Review indipendenti Standards/Spec in attesa prima della chiusura. [Evidenze](../../../DriveHub/docs/evidence/r06-destination/verification.md). Nessun commit, nessun ticket successivo, Relazione_SWE esclusa.

- Chiusura verificata: **6/6 criteri soddisfatti, State: closed**. Review indipendenti Standards **0 violazioni/0 smell azionabili**, Spec **0 rilievi**, sul solo diff della sessione. Nessun codice/test/harness modificato dopo le prove finali e le review. R06 completata per 08/11/12, AC07/#7 chiuso; AC13 resta trasversale. Conservazione: 617 file iniziali presenti, 612 identici e 5 aggiornamenti intenzionali, nessuna eliminazione; HEAD/indice invariati. Ambiente temporaneo non più presente alla ripresa, nessun processo PostgreSQL/Xvfb residuo. Nessun commit o ticket successivo.
