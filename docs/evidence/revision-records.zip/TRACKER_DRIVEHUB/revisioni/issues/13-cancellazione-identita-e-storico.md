# 13: Cancellare identità senza perdere richieste o attribuzioni storiche

Suddivisione e dipendenze approvate dall'utente il 31 ottobre 2026.

**What to build:** La cancellazione dell'identità rispetta richieste e storico indipendentemente dal nome del ruolo mostrato dall'interfaccia.

**Blocked by:** 01: Rendere build e test ripetibili senza toccare i dati applicativi

Status: ready-for-agent
State: closed

**Piano:** R07
**Specifica:** AC09, AC13
**Storie utente:** US46, US47, US48

## Acceptance criteria

- [x] Ruolo rappresentato coerentemente fra dialog, servizio e DAO, con tutti i chiamanti aggiornati e senza conversioni duplicate.
- [x] Cliente con richieste o operazioni vincolanti non cancellabile; venditore con sole vendite concluse non cancellabile.
- [x] Le attribuzioni storiche non vengono azzerate; identità realmente prive di vincoli restano cancellabili secondo le regole esistenti.
- [x] Controllo e cancellazione restano coerenti in presenza di un'operazione associata concorrente; verificati vincoli e rollback reali.
- [x] Test su ruoli, richieste, storico e casi senza vincoli, con controllo della gestione identità nella UI.

## Note per l'implementazione

Questo ticket riguarda l'identità di accesso; il conto dimostrativo è un concetto distinto, secondo il glossario.

Il ticket comprende chiamanti, dati/fixture, messaggi, test e documentazione interessati. Rispettare i confini di test già approvati; non verificare un effetto PostgreSQL soltanto con DAO simulati. `Relazione_SWE` sempre esclusa.

Fonti: [specifica](../spec.md), [piano e registro](../../../PIANO_REVISIONI_DRIVEHUB.md), [glossario](../../../DriveHub/GLOSSARY.md), [ADR prezzi](../../../DriveHub/docs/adr/0001-base-manuale-e-prezzo-concordato.md).

## Comments

- 31 ottobre 2026: ticket pubblicato da `to-tickets` dopo approvazione di granularità e dipendenze. Esecuzione non ancora avviata; verificare i blocchi prima di iniziare.

- 2 novembre 2026: avviata soltanto la sessione 13; prerequisito 01 e ticket 01–12 chiusi verificati. Nuova baseline completa Java21/PostgreSQL dedicato **330/330**, distinta dal risultato storico12. Fotografia iniziale acquisita; TDD ai confini già approvati, nessun commit.

### 2 novembre 2026 — implementazione e chiusura verificata

- Prerequisito01 e ticket01–12 verificati chiusi prima del lavoro; AGENTS,
  piano, glossario, ADR0001, testing ed evidenze12 letti. Nuova baseline
  Java21/PostgreSQL dedicato **330/330**, distinta dal risultato storico12.
- Riutilizzata la sola mappatura ruoli del DAO in controllo e cancellazione;
  chiamanti dialogo/servizio/DAO censiti nelle evidenze. Richieste cliente e
  richieste/vendite concluse venditore impediscono la cancellazione; storico
  e attribuzioni preservati. Identità senza vincoli cancellabili, conto
  dimostrativo distinto, anche con disponibilità positiva, rimosso per CASCADE.
- Lock identità NO KEY UPDATE → conto → verifica/DELETE sulla stessa
  connessione, esattamente una riga. FK venditore RESTRICT e conflitto FK
  leggibile proteggono anche associazioni successive al controllo. Riprodotto
  e risolto deadlock contro acquisto già sul conto; garanzie04–12 conservate.
- Quattro coppie TDD con sorgente del test identico RED/GREEN. **60/60** casi
  nuovi, mirati **356/356**, suite completa finale **390/390**:47 senzaDB,
  343 PostgreSQL, zero failure/errori/salti, inclusi isolamento e sentinella.
  Gate osservabili, backend distinti, nessuno sleep nelle gare; rollback dopo
  cancellazione identità/conto, accredito/acquisizione e creazione veicolo.
- JavaFX/Robot/tastiera **UI CHECK SUCCESS**, sei schermate finali ispezionate:
  regole/conferma/annullamento, richiesta cliente, storico venditore, password,
  successo; callback solo dopo successo, tutti i ruoli senza vincoli eliminabili.
- Review indipendenti Standards **0 violazioni/0 smell azionabili**, Spec **0**,
  sul solo diff congelato della sessione. Nessun codice/test/harness cambiato
  dopo prove finali e review; documenti di chiusura successivi non sono prove runtime.
- Nuovo ambiente Java21/PG16/Xvfb temporaneo: solo127.0.0.1:55433, ruolo/DB
  dedicati e copia sentinella, riletta in sola lettura dopo suite. Cluster e
  Xvfb arrestati; nessun DB applicativo preesistente contattato. Fotografia846
  file preservata:838 identici,8 aggiornamenti intenzionali, zero eliminazioni;
  ticket/evidenze01–12 e successivi intatti, HEAD/indice invariati, nessun commit.
- **5/5 criteri verificati, ticket13 chiuso, R07 e AC09/#9 completati;13/20
  rilievi integralmente chiusi.** AC13 resta trasversale. Nessun ticket successivo.
- [Evidenze complete, comandi, hash, XML, gare, GUI, review e limiti](../../../DriveHub/docs/evidence/r07-identity/verification.md).
  Prima dell'uso su installazioni esistenti applicare il solo cambio FK
  documentato in testing: non ricostruisce attribuzioni già azzerate. /tmp
  temporanea; nessuna certificazione screen reader o prestazioni.
