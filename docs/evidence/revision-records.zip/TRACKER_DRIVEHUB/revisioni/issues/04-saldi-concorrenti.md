# 04: Eseguire addebiti e rimborsi senza perdere aggiornamenti

Suddivisione e dipendenze approvate dall'utente il 31 ottobre 2026.

**What to build:** Operazioni simultanee sul conto dimostrativo conservano tutti i movimenti e non producono saldo negativo o pagamenti parziali.

**Blocked by:** 01: Rendere build e test ripetibili senza toccare i dati applicativi

Status: ready-for-agent
State: closed

**Piano:** R02
**Specifica:** AC04, AC13
**Storie utente:** US09, US10

## Acceptance criteria

- [x] Individuati tutti i chiamanti di addebito, accredito e rimborso; lettura/modifica del conto protette nella stessa transazione con un protocollo condiviso.
- [x] Definito un ordine di lock coerente, anche quando un'operazione rimborsa più conti, senza duplicare logiche nei servizi.
- [x] Su PostgreSQL con connessioni distinte, da 1.000 € due addebiti concorrenti da 100 € e 200 € lasciano 700 €.
- [x] Addebiti complessivamente non sostenibili non lasciano saldo negativo o operazioni parziali; un errore successivo annulla il movimento della transazione fallita.
- [x] Aggiornati i chiamanti e le prove dei flussi economici coinvolti; verifiche e limiti registrati.

## Note per l'implementazione

Preferire lock/aggiornamenti atomici dei DAO esistenti. Non sostituire PostgreSQL con mock per dimostrare la correttezza concorrente.

Il ticket comprende chiamanti, dati/fixture, messaggi, test e documentazione interessati. Rispettare i confini di test già approvati; non verificare un effetto PostgreSQL soltanto con DAO simulati. `Relazione_SWE` sempre esclusa.

Fonti: [specifica](../spec.md), [piano e registro](../../../PIANO_REVISIONI_DRIVEHUB.md), [glossario](../../../DriveHub/GLOSSARY.md), [ADR prezzi](../../../DriveHub/docs/adr/0001-base-manuale-e-prezzo-concordato.md).

## Comments

- 31 ottobre 2026: ticket pubblicato da `to-tickets` dopo approvazione di granularità e dipendenze. Esecuzione non ancora avviata; verificare i blocchi prima di iniziare.

### Implementazione e chiusura — 31 ottobre 2026

- Ticket 01, 02 e 03 controllati chiusi con tutti i criteri verificati. Ambiente
  Java 21/PostgreSQL R00 ripreso da `DriveHub/docs/testing.md`; solo ticket 04 lavorato.
- Individuati otto movimenti: ricarica, acconto/saldo acquisto, rifiuto/scadenza,
  pagamento cessione, noleggio e rimborsi per annullamento. DAO e quattro servizi
  aggiornati: `findByClientIdForUpdate` blocca la lettura nella stessa connessione
  transazionale; tutti i chiamanti la usano prima del movimento. Letture UI/login
  senza lock. Rimborso multiplo per ID cliente crescente; conto mancante provoca
  rollback invece di un successo parziale. Nessuna nuova dipendenza o modifica schema/demo.
- RED pubblico: `python3 /tmp/drivehub-r00-maven.py ticket04-red -Ppostgres-tests
  -Dtest=BalanceConcurrencyIntegrationTest#concurrentPurchaseDepositsKeepBothDebits test`
  → **1 failure attesa**, saldo 800 invece di 700. Stessi argomenti con etichetta
  `ticket04-green` dopo correzione → **1/1**. Gate PostgreSQL e due backend distinti
  in attesa attestati prima del rilascio, senza sleep o DAO simulati.
- RED rimborsi: `python3 /tmp/drivehub-r00-maven.py ticket04-refunds-red -Ppostgres-tests
  '-Dtest=BalanceConcurrencyIntegrationTest#concurrentRefundsAcquireAccountsInClientOrder+missingRefundAccountRollsBackEveryRefundAndCancellation'
  test` → **2 failure attese**, ordine lock incoerente e conto mancante ignorato.
  Dopo correzione entrambe passano. Un primo ampliamento aveva tre casi falliti
  per ID venditore inesistente nella sola fixture; corretto da 21 a 16, senza
  modifiche alla produzione: 15/15. Aggiunta prova DAO di rifiuto autocommit.
- Mirati finali: `python3 /tmp/drivehub-r00-maven.py ticket04-final-targeted
  -Ppostgres-tests -Dtest=BalanceConcurrencyIntegrationTest test` → **16/16**.
  Verificati 1000−100−200=700, fondi insufficienti senza saldo negativo o scritture
  parziali, tutti gli otto movimenti contro ricarica concorrente, rimborsi ordinati
  su più conti e ripetuti sullo stesso conto. Trigger PostgreSQL temporanei
  provocano errori dopo movimenti effettivi: rollback di saldi, stato veicolo,
  richiesta e cancellazioni verificato tramite servizi pubblici. Attese limitate.
- Suite completa: `python3 /tmp/drivehub-r00-maven.py ticket04-full
  -Ppostgres-tests clean test` → **69 passati, 0 failure/errori/saltati**,
  28 senza DB e 41 PostgreSQL; 62 sorgenti e 10 test ricompilati target 21.
  Isolamento e sentinella passati sulla sola copia applicativa R00, nessun SQL
  al database applicativo preesistente. Prima sonda sandbox con connessione
  rifiutata; riavvio e prove riusciti con escalation autorizzata. Server arrestato.
- Skill `code-review`: diff della sola sessione fissato prima delle revisioni,
  due agenti indipendenti con contesti nuovi, **Standards 0 rilievi; Spec 0 rilievi**.
  XML, log, SHA-256, link e whitespace controllati; nessuna password privata nelle
  evidenze. Dei 40 file locali precedenti, 38 invariati e due modificati solo
  intenzionalmente (AuthService preserva ticket 03, docs/testing conserva il testo
  precedente). HEAD invariato, indice senza staging, nessun commit.
- [Rapporto, log RED/GREEN, suite, XML, patch revisionata e limiti](../../../DriveHub/docs/evidence/r02-balances/verification.md).
  **5/5 criteri soddisfatti: State: closed.** R02 completata e rilievo **#4** chiuso:
  totale **4/20** (#1, #4, #8, #19). AC13 verificato soltanto nel perimetro del ticket.
- Limiti: nessuna UI modificata o prova grafica; warning JavaFX preesistente;
  concorrenza di richieste/prenotazioni, eventi, prezzi, segni contabili e cancellazione
  account restano agli altri ticket. Ordine garantito fra conti, senza certificare
  serializzazione di tutti gli oggetti. Relazione_SWE sempre esclusa; `/tmp` temporanea.
- Prossimo passo: ticket 05 / R03 in una richiesta successiva. Nessun altro ticket avviato.
