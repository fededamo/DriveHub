# 16: Riprodurre l'installazione e spiegare correttamente il progetto

Suddivisione e dipendenze approvate dall'utente il 31 ottobre 2026.

**What to build:** Un valutatore prepara una copia pulita e l'autore spiega pattern, responsabilità e dipendenze sulla base del comportamento consegnato.

**Blocked by:** 02: Conservare il veicolo invariato dopo una modifica non valida; 03: Cambiare email senza compromettere l'accesso; 06: Concludere l'acquisto al totale concordato all'acconto; 10: Accettare o rifiutare una cessione senza doppi pagamenti; 12: Cambiare destinazione senza riaprire auto assegnate o perdere rimborsi; 13: Cancellare identità senza perdere richieste o attribuzioni storiche; 14: Consultare le tabelle senza query nel rendering; 15: Rimuovere FXML e stato di sessione soltanto se inutilizzati

Status: ready-for-agent
State: closed

**Piano:** R09
**Specifica:** AC15, AC18
**Storie utente:** US55, US56

## Acceptance criteria

- [x] Istruzioni complete per Java 21, Maven, PostgreSQL, configurazione, inizializzazione e demo facoltativa; reset distruttivo distinto dall'avvio ordinario.
- [x] Documentati comandi e confini delle prove senza DB, PostgreSQL e verifiche grafiche, con eventuali limitazioni reali.
- [x] Factory statiche distinte da Factory Method GoF; DAO, DI e composition root distinti dai GoF.
- [x] SOLID e uso di DDD motivati con esempi reali e compromessi; direzione delle dipendenze distinta dal flusso dei dati; costruzione dei servizi e accessi globali residui descritti correttamente.
- [x] Prezzi, transazioni, cancellazioni e concorrenza descritti secondo le decisioni e i flussi implementati, senza promettere proprietà non dimostrate.
- [x] Procedura di installazione pulita verificata e incongruenze risolte o registrate come verifiche ancora aperte; relazione sempre esclusa.

## Note per l'implementazione

Le istruzioni necessarie a verificare ogni ticket vengono aggiornate nel ticket stesso. Questo è il consolidamento finale dopo i cambiamenti applicativi, non un rinvio di tutta la documentazione.

Il ticket comprende chiamanti, dati/fixture, messaggi, test e documentazione interessati. Rispettare i confini di test già approvati; non verificare un effetto PostgreSQL soltanto con DAO simulati. `Relazione_SWE` sempre esclusa.

Fonti: [specifica](../spec.md), [piano e registro](../../../PIANO_REVISIONI_DRIVEHUB.md), [glossario](../../../DriveHub/GLOSSARY.md), [ADR prezzi](../../../DriveHub/docs/adr/0001-base-manuale-e-prezzo-concordato.md).

## Comments

- 31 ottobre 2026: ticket pubblicato da `to-tickets` dopo approvazione di granularità e dipendenze. Esecuzione non ancora avviata; verificare i blocchi prima di iniziare.

- 3 novembre 2026: avviato solo16; AGENTS, piano, glossario, ADR0001, testing ed evidenze15 letti. Verificati01–15 chiusi e senza criteri aperti; fotografia iniziale1422file, HEAD/indice conservati. Strumenti temporanei precedenti assenti: ambiente Java21/PG16/Xvfb ricreato senza installazioni di sistema; copia isolata dalla versione locale corrente, inclusi file modificati e non tracciati, esclusa Relazione_SWE. Nuove build/avvio/suite e review ancora da completare;394/394 del15 resta storico. Nessun commit/staging o intervento17.

- 3 novembre 2026 — chiusura: **6/6 criteri verificati**, solo16/AC15/#15 e AC18/#18 completati. README, installazione, architettura e testing consolidati: avvio ordinario distinto da schema/demo distruttivi; configurazione reale, demo facoltativa, pattern/SOLID/DDD e limiti con sorgenti verificati. Nessun codice/POM/test/schema/demo o diagramma modificato. Copia isolata dalla versione locale corrente, non HEAD, inclusi modificati/non tracciati; sola configurazione privata DB differente nei sorgenti. Java21.0.12.1/Maven3.9.16/PG16.15/Xvfb ricreati dopo assenza dei temporanei precedenti; solo127.0.0.1:55434 con ruoli/DB dedicati e sentinella distinta. Schema vuoto e demo separata, build package65sorgenti target21,47/47senzaDB, tre login demo tramite servizi e App.start/Robot riusciti; due veri avvii mvn javafx:run con finestre/PID distinti, interrotti dopo osservazione. Nuova suite completa finale **394/394**,47senzaDB/347PostgreSQL, zero failure/errori/salti, isolamento/sentinella inclusi;394/394del15 resta storico. Hash13tabelle/7sequenze applicative identici prima/dopo, READ ONLY; servizi arrestati, listener/PID assenti. Review indipendenti solo diff sessione: **Standards0violazioni/0smell azionabili, Spec0rilievi**. [Comandi, log/XML, hash, review e limiti](../../../DriveHub/docs/evidence/r09-instructions/verification.md).1422file iniziali presenti,1418identici e4aggiornamenti documentali intenzionali,zeroeliminazioni;01–15 e successivi intatti, HEAD/indice invariati, nessun commit/staging, Relazione_SWE esclusa. R09 resta parziale per17, AC13 trasversale; nessuna migrazione completa, certificazione screen reader/altroOS/installer o prova di tutti i flussi GUI. Nessun ticket successivo avviato.
