# 15: Rimuovere FXML e stato di sessione soltanto se inutilizzati

Suddivisione e dipendenze approvate dall'utente il 31 ottobre 2026.

**What to build:** Il progetto mantiene solo dipendenze e stato realmente usati, senza interrompere compilazione, avvio o chiamanti.

**Blocked by:** 01: Rendere build e test ripetibili senza toccare i dati applicativi

Status: ready-for-agent
State: closed

**Piano:** R10
**Specifica:** AC20
**Storie utente:** US58

## Acceptance criteria

- [x] Ricerca mirata di tutti i riferimenti a FXML e ai membri di sessione conferma quali elementi siano realmente inutilizzati, escludendo sempre la relazione.
- [x] Rimossi soltanto dipendenza, membri e import senza usi; nessun refactor estraneo o nuovo comportamento.
- [x] Compilazione e avvio verificati con l'ambiente corretto; ogni controllo non eseguibile resta esplicitamente aperto.
- [x] Registrata la riduzione effettiva e aggiornate le sole descrizioni divenute incoerenti.

## Note per l'implementazione

Nessun test che si limiti a rispecchiare la rimozione. Le verifiche pertinenti sono riferimenti, compilazione e avvio.

Il ticket comprende chiamanti, dati/fixture, messaggi, test e documentazione interessati. Rispettare i confini di test già approvati; non verificare un effetto PostgreSQL soltanto con DAO simulati. `Relazione_SWE` sempre esclusa.

Fonti: [specifica](../spec.md), [piano e registro](../../../PIANO_REVISIONI_DRIVEHUB.md), [glossario](../../../DriveHub/GLOSSARY.md), [ADR prezzi](../../../DriveHub/docs/adr/0001-base-manuale-e-prezzo-concordato.md).

## Comments

- 31 ottobre 2026: ticket pubblicato da `to-tickets` dopo approvazione di granularità e dipendenze. Esecuzione non ancora avviata; verificare i blocchi prima di iniziare.

- 2 novembre 2026: avviato solo15 dopo lettura AGENTS/piano/glossario/ADR0001, testing ed evidenze14 e verifica01–14 chiusi. Fotografia iniziale1276file, HEAD/indice conservati. Java21/PG16 e configurazione dedicata ricontrollati; nuova baseline `mvn -Ppostgres-tests clean test`394/394, zero failure/errori/salti, isolamento/sentinella compresi. Il394/394 del14 resta storico. Nessuna risorsa/loader FXML né chiamante dei membri di sessione AppContext; compilazione, App.start su Xvfb93 e harness grafico14 riusciti. Suite finale/review ancora in corso. Relazione_SWE esclusa; nessun commit/staging.

- 2 novembre 2026 — chiusura: **4/4 criteri verificati**, solo15/R10/AC20/#20 completati. Rimossi una dipendenza, un campo, tre metodi e un import senza usi: **20 righe nette in meno** nei soli POM/AppContext; corretto soltanto il commento della dipendenza. Ricerca estesa anche a file nascosti/ignorati, nessuna risorsa/loader FXML o chiamante sessione. Chiamanti reali login/logout e test/DAO/schema/demo intatti. Compilazione Java21 riuscita; `App.start` su Xvfb93 **APP STARTUP SUCCESS**, tema e Tab; harness ciclo completo14 **UI CHECK SUCCESS**. Suite completa finale nuova **394/394**,47 senzaDB/347 PostgreSQL, zero failure/errori/salti, isolamento/sentinella. Review indipendenti sul solo diff di sessione: Standards **0 violazioni residue/0 smell azionabili** (ordine commenti corretto e ricontrollato), Spec **0 rilievi**. Nessun codice/test/harness modificato dopo le prove. [Comandi, log/XML, hash, review e limiti](../../../DriveHub/docs/evidence/r10-cleanup/verification.md). Conservati1276file iniziali:1271 identici,5 aggiornamenti intenzionali,zero eliminazioni;01–14 e successivi intatti, HEAD/indice invariati, nessun commit/staging. Sentinella finale riletta READ ONLY, PostgreSQL/Xvfb arrestati e listener assenti. Relazione_SWE sempre esclusa. /tmp temporanea; packaging/goal javafx:run, altri OS/display e screen reader non verificati. Nessun blocco residuo15 o ticket successivo avviato.
