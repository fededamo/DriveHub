# Suddivisione approvata in ticket

Stato: suddivisione e dipendenze approvate dall'utente il 31 ottobre 2026. Pubblicati 18 ticket separati con `Status: ready-for-agent` e `State: open`; nessuno è ancora implementato.

Le attività R00–R11 restano nel [piano](../../PIANO_REVISIONI_DRIVEHUB.md); i ticket ne suddividono i comportamenti in consegne verificabili. La [specifica](spec.md) resta invariata e non viene chiusa.

Ogni ticket comprende tutti gli strati interessati e le proprie prove. Nessun refactor preliminare separato: le protezioni condivise vengono introdotte e dimostrate nei flussi reali di conti, richieste ed eventi. I vincoli del piano sono precisati dai blocchi diretti qui sotto; non si aggiungono dipendenze soltanto per imporre una sequenza.

1. **[Rendere build e test ripetibili senza toccare i dati applicativi](issues/01-ambiente-e-test-isolati.md)**

   **Blocked by:** Nessuno.

   **Consegna:** Lo sviluppatore può compilare con Java 21, eseguire prove senza database e prove PostgreSQL dedicate e ricreare le fixture senza coinvolgere il database applicativo.

2. **[Conservare il veicolo invariato dopo una modifica non valida](issues/02-invarianti-veicolo.md)**

   **Blocked by:** 01.

   **Consegna:** Il manager può ricevere un errore di validazione della targa senza lasciare il veicolo in uno stato invalido.

3. **[Cambiare email senza compromettere l'accesso](issues/03-cambio-email-sicuro.md)**

   **Blocked by:** 01.

   **Consegna:** L'utente può aggiornare la propria email; un valore invalido o duplicato viene rifiutato prima del salvataggio e l'accesso precedente resta valido.

4. **[Eseguire addebiti e rimborsi senza perdere aggiornamenti](issues/04-saldi-concorrenti.md)**

   **Blocked by:** 01.

   **Consegna:** Operazioni simultanee sul conto dimostrativo conservano tutti i movimenti e non producono saldo negativo o pagamenti parziali.

5. **[Usare prezzo consigliato o base manuale lungo catalogo e noleggio](issues/05-prezzo-consigliato-e-base-manuale.md)**

   **Blocked by:** 01.

   **Consegna:** Il manager sceglie la base del modello o una base manuale persistente; clienti e servizi vedono il prezzo effettivo ottenuto dalla stessa formula.

6. **[Concludere l'acquisto al totale concordato all'acconto](issues/06-totale-concordato-acquisto.md)**

   **Blocked by:** 04, 05.

   **Consegna:** Il cliente versa l'acconto e, dopo l'autorizzazione, paga il saldo calcolato sul totale fissato anche se il manager modifica basi o sconti.

7. **[Elaborare saldo, rifiuto e scadenza una sola volta](issues/07-richieste-acquisto-una-volta.md)**

   **Blocked by:** 04.

   **Consegna:** Due sessioni non possono concludere o rimborsare più volte la stessa richiesta di acquisto, né aggirare approvazione e scadenza.

8. **[Confermare vendita o noleggio insieme alla cancellazione dei test drive](issues/08-cancellazioni-test-drive-atomiche.md)**

   **Blocked by:** 04.

   **Consegna:** Vendita e noleggio non possono risultare riusciti se la cancellazione obbligatoria dei test drive futuri fallisce.

9. **[Proporre una cessione solo per un veicolo consentito](issues/09-proposta-cessione-e-titolarita.md)**

   **Blocked by:** 01.

   **Consegna:** Un cliente può proporre un VIN nuovo o il veicolo già venduto a lui, senza sovrascrivere inventario altrui e senza richieste aperte duplicate.

10. **[Accettare o rifiutare una cessione senza doppi pagamenti](issues/10-esito-cessione-e-registro.md)**

   **Blocked by:** 07, 09.

   **Consegna:** Il venditore conclude una cessione una sola volta; il cliente riceve l'accredito dovuto e il manager vede l'acquisizione come uscita della concessionaria.

11. **[Prenotare noleggi e test drive senza disponibilità impossibili](issues/11-prenotazioni-concorrenti.md)**

   **Blocked by:** 08.

   **Consegna:** Più istanze desktop rispettano disponibilità del veicolo, limite dei test drive e priorità commerciale quando prenotano contemporaneamente.

12. **[Cambiare destinazione senza riaprire auto assegnate o perdere rimborsi](issues/12-destinazione-veicolo-e-rimborsi.md)**

   **Blocked by:** 11.

   **Consegna:** Il venditore alterna vendita e noleggio solo quando consentito; i noleggi futuri cancellati vengono rimborsati integralmente.

13. **[Cancellare identità senza perdere richieste o attribuzioni storiche](issues/13-cancellazione-identita-e-storico.md)**

   **Blocked by:** 01.

   **Consegna:** La cancellazione dell'identità rispetta richieste e storico indipendentemente dal nome del ruolo mostrato dall'interfaccia.

14. **[Consultare le tabelle senza query nel rendering](issues/14-tabelle-javafx-reattive.md)**

   **Blocked by:** 05.

   **Consegna:** Catalogo e tabelle interessate restano utilizzabili durante caricamenti lenti, mostrano i prezzi corretti e permettono la riprova dopo errori.

15. **[Rimuovere FXML e stato di sessione soltanto se inutilizzati](issues/15-pulizia-componenti-inutilizzati.md)**

   **Blocked by:** 01.

   **Consegna:** Il progetto mantiene solo dipendenze e stato realmente usati, senza interrompere compilazione, avvio o chiamanti.

16. **[Riprodurre l'installazione e spiegare correttamente il progetto](issues/16-istruzioni-e-rigore-teorico.md)**

   **Blocked by:** 02, 03, 06, 10, 12, 13, 14, 15.

   **Consegna:** Un valutatore prepara una copia pulita e l'autore spiega pattern, responsabilità e dipendenze sulla base del comportamento consegnato.

17. **[Documentare con diagrammi ed evidenze la versione consegnata](issues/17-diagrammi-ed-evidenze-correnti.md)**

   **Blocked by:** 02, 03, 06, 10, 12, 13, 14, 15.

   **Consegna:** Diagrammi e risultati riferibili alla versione corrente sostengono la dimostrazione; artefatti della vecchia versione sono riconoscibili come storici.

18. **[Dimostrare i flussi integrati e chiudere soltanto i rilievi provati](issues/18-verifica-integrata-e-chiusura.md)**

   **Blocked by:** 16, 17.

   **Consegna:** L'autore dispone di un quadro attendibile della correzione dei 20 rilievi, con test dei flussi, limiti e prossimo passo documentati.

## Come leggere i blocchi

I numeri dei ticket sono distinti dagli ID R00–R11 del piano. Un ticket si può prendere soltanto quando tutti i suoi blocchi sono chiusi con le prove richieste. Il ticket 01 è l'unico immediatamente pronto; gli altri sono specificati, ma dipendono dai predecessori. L'etichetta `ready-for-agent` indica una specifica sufficiente, non l'assenza di dipendenze.

Il 04 dimostra il protocollo dei conti, il 07 quello delle richieste e il 08 quello delle cancellazioni obbligatorie; le consegne successive li riutilizzano. Il 16 e il 17 consolidano la documentazione dopo i cambiamenti applicativi; il 18 verifica l'integrazione finale. L'ordine numerico è una sequenza di lavoro valida anche senza agenti paralleli.

La documentazione e i test necessari a ciascun comportamento si aggiornano nel relativo ticket: le verifiche non sono rimandate tutte al 18. Non sono previsti migrazione dei dati esistenti, nuove funzionalità o accessi a `Relazione_SWE`.

## Pubblicazione e prossimo passo

Granularità e dipendenze approvate dall'utente. Ogni ticket è pubblicato nella directory dei ticket effettivi; non serve un ulteriore triage. Prossimo passo: `implement` sul ticket 01, ambiente e test isolati. Registrare in ciascun ticket avanzamento ed evidenze e aggiornare il piano generale.

Il registro deve restare a **0 rilievi su 20 chiusi** finché non ci sono correzioni e prove. La pubblicazione dei ticket non è un'implementazione.
