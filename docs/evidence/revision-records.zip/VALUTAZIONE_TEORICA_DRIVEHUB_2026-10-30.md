# DriveHub — Confronto con il materiale del corso

Data: 30 ottobre 2026.

## Ambito e giudizio

**Il progetto è coerente con l’impostazione del corso, ma non rispetta ancora tutto in modo completo e rigoroso.** Ignorando i bug, la struttura è una buona base universitaria; le debolezze maggiori sono nella precisione teorica e nel collegamento fra analisi, progettazione e verifica.

Questa valutazione riguarda l’impostazione progettuale, separatamente dai difetti di codice descritti in [AUDIT_DRIVEHUB_2026-10-30.md](AUDIT_DRIVEHUB_2026-10-30.md). La cartella `DriveHub/Relazione_SWE` resta esclusa.

Il confronto si basa sui file del corso forniti nella directory `Slides and notes - academic year 202526-20261020`. Il disciplinare `NotesOnTheProjectWork_Jan2025.pdf` riporta internamente l’A.A. 2024/25.

Una distinzione importante: **non è necessario utilizzare tutta la teoria dentro il progetto**. Il disciplinare presenta il progetto come occasione per applicare e discutere concetti pertinenti; richiede però padronanza di tutto ciò che viene presentato. Non emerge l’obbligo di inserire ogni design pattern studiato.

Fonte: [Disciplinare, pp. 3–5](<Slides and notes - academic year 202526-20261020/NotesOnTheProjectWork_Jan2025.pdf>).

## Valutazione per argomento

| Argomento | Valutazione del progetto |
|---|---|
| **Classi, interfacce, ereditarietà e polimorfismo** | **Ben presenti.** La gerarchia degli utenti, le interfacce DAO e il navigatore polimorfico offrono esempi concreti da discutere. |
| **Incapsulamento e invarianti** | **Impostazione corretta.** Campi privati, costruzione controllata e validazioni mostrano l’intenzione di mantenere valide le entità. |
| **Separazione delle responsabilità** | **Generalmente buona.** Persistenza, operazioni applicative, calcolo prezzi e presentazione sono riconoscibili. Alcuni confini possono essere motivati meglio. |
| **Architettura a strati** | **Sostanzialmente presente.** Le viste chiamano servizi e i servizi usano DAO. La rappresentazione nel README, però, non distingue chiaramente flusso dei dati e direzione delle dipendenze. |
| **Dependency injection** | **Presente realmente.** `AppContext` costruisce e passa le dipendenze. Restano anche costruttori che recuperano servizi dal Singleton globale: convivono quindi due modalità di accesso. |
| **Design pattern** | **Ci sono esempi validi**, soprattutto Observer e la struttura di double dispatch usata per la navigazione. Alcune denominazioni nel README sono scorrette. |
| **SOLID** | **Applicazione parziale e plausibile**, ma le affermazioni del README sono troppo assolute rispetto alle prove offerte. |
| **UML e progettazione** | Gli artefatti esistono, ma **diversi diagrammi descrivono un’altra versione**: attualmente non documentano adeguatamente il progetto. |
| **Testing secondo il corso** | **Parziale.** Sono presenti test utili di dominio e calcolo; manca una dimostrazione sistematica dei flussi applicativi e delle alternative. |
| **Analisi dei requisiti e processo di sviluppo** | **Non giudicabili completamente escludendo la relazione**, dove potrebbero trovarsi statement, template, motivazioni e descrizione del processo. |

## Questioni teoriche da consolidare prima dell’orale

### 1. Usare i nomi dei pattern con precisione

`Vehicle.create()` e `Client.create()` sono **factory statiche**. Il Factory Method GoF spiegato nelle slide introduce invece una creazione delegata e polimorfica attraverso Creator e ConcreteCreator.

Inoltre DAO, dependency injection e composition root sono concetti validi, ma **non appartengono ai 23 pattern GoF**, mentre il README li raccoglie sotto quel titolo. Questa è una distinzione teorica da correggere anche supponendo un codice perfettamente funzionante.

Fonte: [DesignPatternsJava22, slide 51–52](<Slides and notes - academic year 202526-20261020/3. Design Patterns/DesignPatternsJava22.pdf>).

### 2. Motivare SOLID attraverso esempi, evitando dichiarazioni generali

È possibile spiegare bene perché `PriceCalculatorService` ha una responsabilità distinta e perché `VehicleDao` separa servizi e persistenza. È invece eccessivo affermare che i servizi dipendono esclusivamente da astrazioni: dipendono anche da classi concrete come `DatabaseManager`.

Questo **non rende automaticamente sbagliato il progetto**. Significa che occorre distinguere il principio applicato, il beneficio ottenuto e il compromesso accettato. Anche LSP e OCP vanno spiegati attraverso comportamenti e possibilità di estensione concrete.

### 3. Rendere visibile il percorso requisiti → progetto → test

Questo è il punto più importante rispetto al corso. Per esempio, per “noleggiare un veicolo” dovrebbe essere possibile mostrare:

- il template con attore, precondizioni, percorso normale, alternative e postcondizioni;
- le responsabilità assegnate a servizio, entità e DAO;
- i test che verificano quei percorsi.

Il disciplinare indica esplicitamente i **template come obbligatori**, raccomanda mockup e navigazione e richiede test funzionali riferiti ai flussi dei casi d’uso, oltre a test strutturali e dei DAO. Nel materiale attualmente valutabile questo collegamento non è sufficientemente dimostrato.

Fonte: [Disciplinare, pp. 13 e 26–29](<Slides and notes - academic year 202526-20261020/NotesOnTheProjectWork_Jan2025.pdf>).

### 4. Distinguere una scelta progettuale dalla sua etichetta

L’organizzazione in entità, servizi e DAO è ragionevole. Definirla “DDD” richiede però una spiegazione del modello di dominio e delle responsabilità, oltre alla disposizione dei package.

Analogamente, usare Observer richiede saper spiegare **quali componenti disaccoppia, quale variazione permette e quali conseguenze comporta**.

## Giudizio complessivo e limiti

**Buona impostazione pratica, applicazione riconoscibile di diversi concetti del corso, ma rigore teorico e documentale ancora da consolidare.** Il lavoro prioritario riguarda spiegazioni corrette, diagrammi coerenti e tracciabilità dei casi d’uso.

Restano esclusi la relazione e i suoi eventuali template. Dai soli sorgenti non è possibile attestare la completezza dell’analisi né ricostruire il processo di sviluppo seguito. Questo documento non certifica la conformità a un programma o a requisiti d’esame successivi ai materiali forniti.
