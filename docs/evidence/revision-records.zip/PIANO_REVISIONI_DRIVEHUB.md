# Revisione DriveHub

Registro operativo avviato il 31 ottobre 2026. Punto di ingresso per riprendere il lavoro: avanzamento, decisioni, attività, verifiche e prossimo passo.

## Stato attuale — ticket18 completato

- Solo18/R11 completato,01–17 verificati chiusi e senza criteri aperti;6/6criteri del18. **AC01–AC20 collegati a comportamenti e prove nominate;20/20rilievi chiusi nei confini verificati.** [Matrice completa](DriveHub/docs/evidence/r11-integrated/acceptance-matrix.md).
- Nuovi mirati **363/363**, sette controlli JavaFX riusciti,18SVG rigenerati identici ai consegnati; finale **394/394** (47senzaDB/347PostgreSQL), zero failure/errori/salti, gare e rollback PostgreSQL reali. Risultati16–17 storici, tentativi falliti separati.
- Java21.0.12.1/Maven3.9.16/PG16.15, solo cluster sacrificabile127.0.0.1:55436. Dopo perdita di/tmp ricreati strumenti/cluster; finale su input produttivi invariati. Sentinella fase2 READ ONLY con13tabelle/7sequenze invariate, cluster arrestato/listener assente. Il confronto esterno finale della sentinella fase1 non è eseguito né contato; GUI già concluse in quella fase su Xvfb90.
- Review indipendenti Standards/Spec sul solo diff rispetto alla baseline locale, con esito nelle [evidenze18](DriveHub/docs/evidence/r11-integrated/verification.md).1796file iniziali preservati,1792identici e4aggiornamenti documentali intenzionali; ignorati/target inclusi, HEAD/indice invariati. Nessuno staging/commit/push/pubblicazione, nessun codice produttivo/testJUnit/POM/schema/demo o artefatto storico modificato. Relazione_SWE sempre esclusa.
- Limiti: Linux/WSL/Xvfb, percorsi/assert GUI specifici e parte dei riscontri statici, niente screen reader/altroOS/installer/migrazione completa/benchmark o garanzia globale contro deadlock. Temporanei da ricontrollare; nessun residuo funzionale dimostrato18, ulteriori certificazioni fuori perimetro.

## Stato al termine del ticket17 — storico


- Solo17 completato,01–16 verificati chiusi;5/5criteri, **AC14/#14 e R09 completati**,18/20rilievi chiusi. R11/ticket18 e AC13 trasversale restano aperti; nessuna verifica integrata anticipata.
- [Indice diagrammi correnti](DriveHub/docs/diagrams/README.md):18sorgenti PlantUML e18SVG per classi, package, sequenze, casi d'uso, navigazione e stati, con rimandi a sorgenti/test reali. Componenti/stati/flussi effettivi e precisazioni teoriche16 mantenuti; nessun refactor, test artificiale del testo o modifica a codice/POM/test/schema/demo.
- Baseline1507file, anche ignorati/modificati/nontracciati: HEAD da solo non identifica la versione.37artefatti visivi e vecchi manifest identificati come storici e conservati; ciascun manifest150voci ha149percorsi mancanti e POM diverso. Nessun ER/draw.io/mockup/screenshot storico rigenerato.
- Java21/PG16 temporanei16 presenti e ricontrollati, PlantUML1.2026.2 predisposto. Nuovo cluster127.0.0.1:55435, DB/ruoli dedicati e sentinella, Xvfb91. Nuovi mirati79/79, UI CHECK SUCCESS, APP STARTUP SUCCESS e finale **394/394** (47senzaDB/347PostgreSQL), zero failure/errori/salti.394/394del16 resta storico. Mirato fallito per server perso e primo avvio finale interrotto143 conservati separatamente, senza attribuirvi riuscite.
- Render SVG/PNG finali exit0, ispezione e correzioni di leggibilità. Review indipendenti sul solo diff locale: Standards0violazioni/0smell; Spec1P2 sui ritorni dei dialoghi cliente corretto, render aggiornato e follow-up indipendenti **0residui**. [Evidenze17](DriveHub/docs/evidence/r09-diagrams/verification.md): versione/diff/hash, comandi/log/XML, storico, review e limiti.
- Sentinella finale READ ONLY e hash13tabelle/7sequenze invariati; PostgreSQL/Xvfb arrestati.1507file iniziali presenti,1502identici,5aggiornamenti documentali intenzionali,zeroeliminazioni. Sorgenti/test/evidenze01–16/ticket18 intatti; HEAD/indice invariati, nessun commit/staging, relazione sempre esclusa.
- Limiti: Linux/WSL/Xvfb, SVG a zoom, niente certificazione screen reader/altriOS/stampaA4; non tutti i gesti GUI riesercitati, parte dei riscontri è statica. Temporanei da ricontrollare. Nessun residuo17;18 solo su nuova richiesta.

## Stato al termine del ticket16 — storico

- Solo16 completato,01–15 verificati chiusi;6/6criteri, **AC15/#15 e AC18/#18 chiusi**. Rilievi integralmente chiusi **17/20** (#1,#2,#3,#4,#5,#6,#7,#8,#9,#10,#11,#15,#16,#17,#18,#19,#20). R09 resta parziale per i diagrammi17; AC13 trasversale, nessun successivo avviato.
- Consolidati README, [installazione](DriveHub/docs/installation.md), [architettura](DriveHub/docs/architecture.md) e testing. Configurazione/inizializzazione/demo facoltativa, reset distruttivo distinto dall'avvio; factory statiche/GoF/DAO/DI, SOLID/DDD, responsabilità/dipendenze/flussi e compromessi sostenuti dai sorgenti. Nessun refactor o modifica a codice/POM/test/schema/demo/diagrammi.
- Installazione provata sulla copia della versione locale corrente, inclusi modificati/non tracciati, non solo HEAD. Temporanei precedenti assenti: Java21.0.12.1/Maven3.9.16/PG16.15/Xvfb ricreati senza installazioni di sistema, solo cluster sacrificabile127.0.0.1:55434, DB/ruoli dedicati e sentinella distinta.
- Nuove prove: schema vuoto e demo separata; build `mvn -DskipTests clean package`65sorgenti target21;47/47senzaDB; tre login demo tramite servizi e App.start/Robot; due avvii reali `mvn javafx:run` con finestre/PID distinti, interrotti dal launcher dopo osservazione. Suite finale **394/394**,47senzaDB/347PostgreSQL, zero failure/errori/salti, isolamento/sentinella;394/394del15 resta storico. Input runtime identici fra build e suite.
- Review indipendenti sul solo diff congelato della sessione: **Standards0violazioni/0smell azionabili, Spec0rilievi**. [Evidenze16](DriveHub/docs/evidence/r09-instructions/verification.md). Sentinella finale READ ONLY e hash13tabelle/7sequenze applicative identici prima/dopo; PostgreSQL/Xvfb arrestati, listener e PID assenti.
- Conservati1422file iniziali:1418identici,4aggiornamenti documentali intenzionali,zeroeliminazioni;01–15 e successivi intatti, HEAD/indice invariati, nessun commit/staging, relazione sempre esclusa. Limiti: Linux/WSL/Xvfb, login tramite servizi anziché tutti i flussi GUI, nessuna certificazione screen reader/altroOS/installer/benchmark o migrazione completa. Prossimo passo: nessun residuo16;17 solo su nuova richiesta.

## Stato durante il ticket 16 — storico

- Solo16, prerequisiti01–15 verificati chiusi e senza criteri aperti; fotografia iniziale1422file, HEAD/indice conservati. Relazione_SWE esclusa, nessun commit/staging.
- Consolidati README, installazione/configurazione e descrizione architetturale: inizializzazione/reset distruttivi distinti dall'avvio, demo facoltativa; factory statiche/GoF/DAO/DI, SOLID/DDD e limiti spiegati con sorgenti concreti. Diagrammi17 esclusi.
- Ambiente temporaneo precedente assente: Java21.0.12.1/Maven3.9.16/PG16.15/Xvfb ricreati senza installazioni di sistema. Nuovo cluster sacrificabile127.0.0.1:55434, DB/ruoli distinti e sentinella; copia dalla versione locale corrente, non solo HEAD, con sola configurazione DB privata diversa nei sorgenti.
- Schema vuoto, demo facoltativa, build `mvn -DskipTests clean package`,47/47 senzaDB, tre login demo, App.start/Robot e due avvii ordinari `mvn javafx:run` verificati. Suite completa finale e review indipendenti Standards/Spec da completare.394/394 del15 resta storico.
- [Evidenze16](DriveHub/docs/evidence/r09-instructions/verification.md). Nessuna chiusura anticipata; R09 resta parziale per17, nessun ticket successivo avviato.

## Stato al termine del ticket 15 — storico

- Solo15: prerequisiti01–14 chiusi e fotografia iniziale1276file. Nuova baseline `mvn -Ppostgres-tests clean test` **394/394**,47 senzaDB/347 PostgreSQL, zero failure/errori/salti, isolamento/sentinella compresi; il394/394 del14 resta storico.
- Ricerca riferimenti completa nel perimetro autorizzato: nessuna risorsa/loader FXML, nessun chiamante dei membri di sessione AppContext. Rimossi soltanto `javafx-fxml`, `currentUser`, tre metodi e l'import User. Login/logout reali, chiamanti, DAO/schema/demo e test invariati; nessun test che rispecchi rimozioni.
- Java21/PG16 ricontrollati nei file temporanei ancora presenti; ruolo/DB dedicati e copia sentinella su127.0.0.1:55433. Compilazione65sorgenti target21 e avvio `App.start` su Xvfb93 **APP STARTUP SUCCESS**, tema e Tab; harness grafico14 **UI CHECK SUCCESS**. Suite finale nuova **394/394**,47 senzaDB/347 PostgreSQL, zero failure/errori/salti, isolamento/sentinella compresi.
- Review indipendenti sul solo diff della sessione: Standards **0 violazioni residue/0 smell azionabili**, Spec **0 rilievi**. Unica osservazione documentale iniziale, ordine dei commenti tracker, corretta e ricontrollata. Nessun codice/test/harness modificato dopo prove e review; chiusura documentale distinta dalle prove runtime.
- Rimossi una dipendenza, un campo, tre metodi e un import: **20 righe nette in meno** nei soli POM/AppContext. Conservati1276file iniziali:1271 identici,5 aggiornamenti intenzionali,zero eliminazioni;01–14 e successivi intatti, HEAD/indice invariati. Sentinella finale READ ONLY e servizi arrestati, listener assenti. Nessun commit/staging; Relazione_SWE sempre esclusa.
- **Ticket15 chiuso,4/4 criteri; R10 e AC20/#20 completati. Rilievi chiusi15/20** (#1,#2,#3,#4,#5,#6,#7,#8,#9,#10,#11,#16,#17,#19,#20); AC13 resta trasversale. [Ticket15](TRACKER_DRIVEHUB/revisioni/issues/15-pulizia-componenti-inutilizzati.md), [evidenze15](DriveHub/docs/evidence/r10-cleanup/verification.md).
- Limiti: /tmp temporanea; verificato App.start, non packaging/goal Maven javafx:run; nessuna nuova certificazione screen reader, altri OS/display o benchmark. Diagrammi con FXML/SessionContext già incoerenti prima15 rimangono al lavoro16–17. Nessun residuo15 né ticket successivo avviato; proseguire solo su nuova richiesta.

## Stato al termine del ticket 14 — storico

- Solo14 implementato dopo verifica del prerequisito05 e della chiusura01–13. Nuova baseline **390/390** prima delle modifiche; il390/390 del13 resta storico. Fotografia iniziale1089file, lavoro precedente preservato.
- Modelli, sconti e prezzi preparati per caricamento dai servizi esistenti; celle senza query, quattro letture collettive per listino e due per sconti modello. Nessuna cache persistente, dipendenza nuova o modifica a DAO/schema/formule/accordi.
- `Task` JavaFX su worker virtuali21, pubblicazione del solo caricamento corrente sul thread grafico; caricamento/errore con riprova da tastiera, vecchi risultati/errori ignorati. Aggiornamenti dopo base/modalità/sconti e cambio modello verificati anche nella vista già aperta.
- Tre coppie TDD con sorgente identico RED/GREEN: rendering856query/connessioni→0, modelli su lock PostgreSQL bloccano FX→reattivo, vecchia lettura dopo marca svuotata→ignorata. Mirati **25/25** e **148/148**; finale `mvn -Ppostgres-tests clean test` **394/394**,47 senzaDB/347 PostgreSQL, zero failure/errori/salti, isolamento/sentinella e regressioni01–13 compresi.
- JavaFX/Robot/tastiera finale e modelli lenti/obsoleti **UI CHECK SUCCESS**, sette schermate ispezionate. Caricamenti sincronizzati tramite proprietà/latch e PID/blocker PostgreSQL osservati; errore SQL reale/riprova e vecchio risultato/errore dopo vera query con chiusura osservata. Errori ambiente/fixture/harness registrati separatamente dai RED.
- Review indipendenti Standards **0 violazioni/0 smell azionabili**, Spec **0 rilievi**, sul diff della sola sessione. Nessun codice/test/harness modificato dopo le prove finali o la review. [Ticket14](TRACKER_DRIVEHUB/revisioni/issues/14-tabelle-javafx-reattive.md), [evidenze](DriveHub/docs/evidence/r08-tables/verification.md).
- Java21/PG16 ricontrollati nell'ambiente13 ancora presente; solo127.0.0.1:55433 e copia sentinella. Xvfb94 astratto senza TCP. Sentinella finale riletta in sola lettura, cluster/display arrestati.1089file iniziali presenti,1082 identici,7 modifiche intenzionali,zero eliminazioni;01–13 e successivi intatti. HEAD/indice invariati; nessun commit/staging, Relazione_SWE esclusa.
- **Ticket14 chiuso,5/5 criteri; R08 e AC16/#16 completati. Rilievi chiusi14/20** (#1,#2,#3,#4,#5,#6,#7,#8,#9,#10,#11,#16,#17,#19); AC13 resta trasversale. Nessun successivo avviato.
- Limiti: cancellare un Task non interrompe immediatamente JDBC già avviato; risultato scartato e risorse chiuse dal worker. Titolo consigliato manager abbreviato a1280px, testo completo e ridimensionamento conservati. Nessuna certificazione screen reader, altri OS/display o benchmark quantitativo; /tmp temporanea. Nessun residuo14, proseguire solo su nuova richiesta.

## Stato al termine del ticket 13 — storico

- Soltanto13 implementato, prerequisito01 e ticket01–12 verificati chiusi; fotografia iniziale846 file e nuova baseline **330/330** prima delle modifiche.
- Mappatura ruoli UI/DAO riusata; richieste e storico impediscono la cancellazione, FK venditore RESTRICT conserva attribuzioni. Identità prive di vincoli cancellabili; conto dimostrativo distinto ed eliminato per CASCADE secondo le regole esistenti.
- Lock identità NO KEY UPDATE → conto → controllo/DELETE nella stessa transazione, una riga effettiva. Gare nei due ordini, vincoli reali e rollback dopo scritture effettive, senza sleep nelle gare. Riprodotto e risolto anche deadlock acquisto/cancellazione; garanzie04–12 preservate.
- Quattro coppie TDD identiche RED/GREEN; nuovi **60/60**, mirati **356/356**, suite completa finale **390/390** (47 senzaDB/343 PostgreSQL), zero failure/errori/salti, inclusi isolamento/sentinella.
- JavaFX/Robot/tastiera **UI CHECK SUCCESS**, sei schermate finali ispezionate. Review indipendenti Standards **0 violazioni/0 smell azionabili**, Spec **0**, sul solo diff congelato della sessione. Nessun codice/test/harness cambiato dopo prove finali e review.
- **Ticket13 chiuso,5/5 criteri; R07 e AC09/#9 completati. Rilievi chiusi13/20** (#1,#2,#3,#4,#5,#6,#7,#8,#9,#10,#11,#17,#19); AC13 resta trasversale.
- [Ticket13](TRACKER_DRIVEHUB/revisioni/issues/13-cancellazione-identita-e-storico.md), [comandi, log/XML, gare, GUI, review e limiti](DriveHub/docs/evidence/r07-identity/verification.md).
- Ambiente Java21/PG16/Xvfb ricreato, solo127.0.0.1:55433 e copia sentinella; sentinella finale in sola lettura, cluster/display arrestati.846 file iniziali presenti,838 identici e8 aggiornamenti intenzionali, nessuna eliminazione; prove/ticket01–12 e successivi intatti. HEAD/indice invariati, nessun commit/staging, Relazione_SWE esclusa.
- Nessun residuo del13 o ticket successivo avviato. Per installazioni esistenti applicare il solo cambio FK prima del codice; attribuzioni già azzerate non ricostruite. Ambiente /tmp temporaneo, screen reader/prestazioni non certificati.

## Stato al termine del ticket 12 — storico

- Solo ticket 12 implementato dopo verifica dei prerequisiti 01–11 chiusi e nuova baseline **297/297**.
- SALE↔RENT soltanto fra stati opposti; SOLD/BLOCKED/WAITING e noleggi in corso con date inclusive protetti. Futuri da domani cancellati e rimborsati integralmente nella transazione; DELETE incompleta, conto mancante o rimborso fallito annullano tutto.
- Gare nei due ordini con connessioni distinte, PID/blocker osservati senza sleep e rollback dopo scritture effettive. Protocollo conti04, lock11 e Observer08 conservati; nessuna nuova penale.
- Mirati **278/278**, suite finale **330/330**, zero failure/errori/salti: 47 senza DB, 283 PostgreSQL. Nuovi 33 casi; quattro coppie RED/GREEN identiche per sorgente del test.
- JavaFX/Robot/tastiera **UI CHECK SUCCESS**, cinque schermate ispezionate. Ambiente Java21/PG16/Xvfb temporaneo ricontrollato; solo cluster sacrificabile e copia sentinella.
- Review indipendenti Standards **0 violazioni/0 smell azionabili**, Spec **0 rilievi**, sul solo diff della sessione. Ticket 12 chiuso, 6/6 criteri; **R06 completata**, AC07/#7 chiuso. Rilievi chiusi **12/20** (#1,#2,#3,#4,#5,#6,#7,#8,#10,#11,#17,#19); AC13 trasversale.
- [Ticket 12](TRACKER_DRIVEHUB/revisioni/issues/12-destinazione-veicolo-e-rimborsi.md), [versione, comandi e prove](DriveHub/docs/evidence/r06-destination/verification.md).
- Conservazione verificata: 617 file iniziali presenti, 612 identici e 5 aggiornamenti intenzionali, zero eliminazioni. HEAD/indice invariati; nessun commit/staging o ticket successivo. Relazione_SWE esclusa. Alla ripresa finale /tmp non più presente e nessun processo PostgreSQL/Xvfb residuo.

## Stato al termine del ticket 11 — storico

- **Ticket 01–11 chiusi e verificati**. Implementato soltanto 11, dopo verifica 01–10 e baseline locale **259/259** prima degli interventi.
- Prenotazioni: lock veicolo → cliente NO KEY UPDATE → conto, disponibilità/limite/prezzo e inserimenti sulla stessa connessione. EXCLUDE PostgreSQL protegge periodi inclusivi, unicità TD e orari conservati; massimo tre anche su veicoli diversi.
- Gare noleggio/test drive nei due ordini, priorità commerciale e cancellazione atomica Observer 08; rollback dopo scritture effettive e saldo insufficiente. Risolto anche il deadlock a tre con saldo acquisto e test drive su veicolo BLOCKED, riprodotto in RED prima della correzione.
- Mirati finali **245/245**, suite finale **297/297**, zero failure/errori/salti: **47 senza DB e 250 PostgreSQL**, inclusi fixture, isolamento/sentinella e regressioni 04–10. Nuovi 38 casi. Suite 296 intermedia; 259 del 10 storica.
- Otto coppie RED/GREEN con sorgente identico. Review indipendenti Standards **0 violazioni/0 smell azionabili**, Spec **0**, sul solo diff di 14 file SHA256 `8344e02efb3cf795d9e287d049a886b51e15dad2e690233416e2587698d2c03e`. Nessun codice/test modificato dopo prove finali/review.
- [Ticket 11](TRACKER_DRIVEHUB/revisioni/issues/11-prenotazioni-concorrenti.md), [versione, prove, comandi e limiti](DriveHub/docs/evidence/r06-bookings/verification.md).
- **AC05/#5 chiuso:11/20** (#1,#2,#3,#4,#5,#6,#8,#10,#11,#17,#19). R06 parziale per 12; AC13 trasversale.
- Ambiente Java 21/PG 16 temporaneo07 ricontrollato prima del riuso; solo 127.0.0.1:55432 e copia sentinella. Cluster arrestato; Xvfb non avviato. Nessun DB applicativo preesistente o installazione di sistema.
- Baseline576file preservata:562 identici,14 modifiche intenzionali inclusi piano/ticket 11, zero eliminazioni; evidenze/ticket 01–10 intatti. Nessun commit/staging, HEAD/indice invariati; Relazione_SWE sempre esclusa.
- Limiti: predisporre btree_gist e risolvere overlap prima di aggiungere il vincolo a installazioni esistenti; nessun reset applicativo. Nessuna vista modificata/nuova prova GUI. /tmp temporanea, warning JavaFX preesistente.
- Nessun blocco residuo del11. Nessun ticket successivo avviato; proseguire solo su nuova richiesta.

## Stato al termine del ticket 10 — storico

- **Ticket 01–10 chiusi e verificati**. In questa sessione lavorato soltanto il 10,
  dopo controllo dei prerequisiti e baseline locale del lavoro 01–09.
- Cessione: richiesta SALE e veicolo WAITING riletti e bloccati nella transazione;
  accredito +16000 una sola volta, acquisizione -16000 con tipo esplicito;
  rifiuto atomico, VIN nuovo rimosso, storico completo conservato e SOLD.
- Mirati **206/206**, suite finale **259/259**, zero failure/errori/salti:
  **45 senza DB, 214 PostgreSQL**, inclusi conti04, prezzi05, accordi06,
  elaborazioni07, Observer08, titolarità/unicità09, fixture e isolamento/sentinella.
  Nuovi 60 casi PostgreSQL e 4 aggiuntivi dominio; suite 195/195 del 09 storica.
- JavaFX/Robot/tastiera finale **UI CHECK SUCCESS**, schermate ispezionate:
  cliente/venditore/manager, esiti e sessione obsoleta, segni/tipi e contrasto.
- Review indipendenti **Standards 0 violazioni/0 smell, Spec 0 rilievi** sul solo
  diff di sessione SHA256 `8da69d421468addde119df3ec2105e40c54c9ff892c49bdfb3b4fe6cacf39f53`.
  Nessun codice/test/harness cambiato dopo prove finali/review.
- [Ticket 10](TRACKER_DRIVEHUB/revisioni/issues/10-esito-cessione-e-registro.md),
  [prove e comandi](DriveHub/docs/evidence/r05-sale-outcome/verification.md).
- **R05 completata; AC03/#3 e AC10/#10 chiusi; totale 10/20**
  (#1, #2, #3, #4, #6, #8, #10, #11, #17, #19). AC13 resta trasversale.
- Ambiente Java21/PG16 del 07 ricontrollato prima del riuso; solo cluster
  sacrificabile 127.0.0.1:55432 e copia sentinella; cluster e Xvfb arrestati.
  Nessun DB applicativo preesistente contattato, nessuna installazione di sistema.
- Baseline: 390 file, 377 identici e 13 modifiche intenzionali, zero eliminazioni;
  evidenze storiche preservate, HEAD/indice invariati. Nessun commit/staging;
  Relazione_SWE sempre esclusa. Schema/importi acquisizioni da adeguare prima
  dell'uso su installazioni esistenti; /tmp temporanea, screen reader non certificato.
- Prossimo passo: nessun residuo del 10; ticket 11 soltanto su nuova richiesta.
  Nessun ticket successivo avviato.

## Stato al termine del ticket 09 — storico

- **Ticket 01–09 chiusi e verificati**. Soltanto il ticket 09 lavorato nella
  sessione corrente, dopo controllo dei precedenti e acquisizione della baseline.
- Proposta di cessione: VIN noto solo SOLD, ultima vendita effettiva al proponente
  e nessuna richiesta aperta, con lock/rilettura e scritture nella transazione.
  Tipo storico esplicito e unicità DB; VIN nuovo con stima esistente preservato.
- Mirati **142/142**, suite completa attuale **195/195**, zero failure/errori/salti:
  41 senza DB e 154 PostgreSQL, inclusi conti 04, formula/base/centesimi 05,
  accordo 06, elaborazioni 07, Observer/cancellazioni 08, fixture e sentinella.
  Nuovi **24/24**. La suite 171/171 del 08 rimane storica.
- Review indipendenti sulla sola sessione: **Standards 0 violazioni/0 smell
  azionabili, Spec 0 rilievi**. Nessun codice/test cambiato dopo suite/review.
- [Ticket 09](TRACKER_DRIVEHUB/revisioni/issues/09-proposta-cessione-e-titolarita.md),
  [prove, comandi e versione](DriveHub/docs/evidence/r05-sale-proposal/verification.md).
- **AC02/#2 chiuso; totale 8/20** (#1, #2, #4, #6, #8, #11, #17, #19).
  R05 parziale per 10; AC03 approvazioni/AC10 ancora aperti, AC13 trasversale.
- Ambiente temporaneo 07 ricontrollato: Java21/PG16, solo 127.0.0.1:55432 e copia
  applicativa sentinella; cluster arrestato. Nessun DB applicativo preesistente.
  Nessuna vista modificata, nessuna nuova verifica JavaFX/tastiera.
- Baseline locale 401 file, 387 identici e 14 aggiornamenti intenzionali, nessuna
  eliminazione; lavoro e prove 01–08 preservati. HEAD/indice invariati, nessun
  commit/staging; Relazione_SWE sempre esclusa. Schema da adeguare prima dell'uso
  su installazioni esistenti, storico da classificare dai fatti; `/tmp` temporanea.
- Prossimo passo: ticket 10 solo su nuova richiesta. Nessun successivo avviato.

## Stato al termine del ticket 08 — storico

- **Ticket 01–08 chiusi e verificati**. Il solo ticket 08 è stato lavorato nella
  sessione corrente, dopo controllo dei precedenti e acquisizione della baseline.
- **R04 completata per 06–08**: accordo immutabile, elaborazione una volta e
  cancellazione atomica dei test drive in acquisto/noleggio. Observer applica la
  priorità commerciale nella transazione del chiamante, senza errori nascosti.
- Suite finale 08 **171/171**, zero failure/errori/saltati: 40 senza DB e 131
  PostgreSQL, inclusi conti 04, prezzi 05, accordo 06, concorrenza richieste 07,
  fixture e isolamento/sentinella. Mirati 117/117, nuovi 8/8; RED 2 failure/GREEN 2/2.
- Review indipendenti sul diff dedicato: **Standards 0 violazioni/0 smell
  azionabili, Spec 0 rilievi**. Nessun codice/test cambiato dopo suite/review.
- R06/AC12 restano parziali per prenotazioni e altre transizioni; AC13 trasversale.
  Rilievi integralmente chiusi invariati a **7/20** (#1, #4, #6, #8, #11, #17, #19).
- [Ticket 08](TRACKER_DRIVEHUB/revisioni/issues/08-cancellazioni-test-drive-atomiche.md),
  [prove 08](DriveHub/docs/evidence/r04-test-drive-atomic/verification.md),
  [prove 06](DriveHub/docs/evidence/r04-agreement/verification.md),
  [prove 07](DriveHub/docs/evidence/r04-purchase-once/verification.md).
- Java 21/PG 16 dell'ambiente temporaneo07 verificati e riusati; vecchi file R00
  assenti. Solo cluster sacrificabile 127.0.0.1:55432 e copia applicativa sentinella;
  cluster arrestato. Nessun DB applicativo preesistente contattato.
- Tutto il lavoro locale e le evidenze 01–07 preservati. Nessun commit/staging,
  HEAD/indice invariati; Relazione_SWE sempre esclusa. Nessuna vista modificata
  nel 08; nessuna nuova prova JavaFX/tastiera. /tmp temporanea.
- Prossimo passo: nessun ticket successivo avviato; nuova richiesta per proseguire.

## Perimetro e fonti

- Fonti: [audit del 30 ottobre](AUDIT_DRIVEHUB_2026-10-30.md) e [valutazione teorica](VALUTAZIONE_TEORICA_DRIVEHUB_2026-10-30.md), accanto a questo piano nella directory esterna al repository. Il piano ne riporta attività e criteri necessari alla lavorazione; gli originali restano riferimenti storici, non prove di correzione.
- Collocazione confermata dall'utente: `PIANO_REVISIONI_DRIVEHUB.md` fuori da `DriveHub/`, come gli audit. I percorsi tecnici citati sotto sono relativi al progetto `DriveHub/`, salvo indicazione diversa. Questo piano non è versionato dal repository del progetto.
- Riferimento didattico: directory esterna `Slides and notes - academic year 202526-20261020`. Il disciplinare citato dagli audit riporta l'A.A. 2024/25: applicabilità al corso attuale non certificata in questa sessione.
- Perimetro approvato: tutti i 20 rilievi, test dei flussi, README, diagrammi e nuove evidenze, mantenendo JavaFX, servizi, DAO e PostgreSQL.
- **Vincolo confermato: ignorare sempre `Relazione_SWE` nelle letture, modifiche, ricerche, generazioni e verifiche. La relazione è gestita dall'utente.**
- Database sacrificabile e ricreabile. La ricreazione riguarda solo il database identificato esplicitamente per il lavoro; i test devono comunque usare un database distinto e riconoscibile.
- Nessuna scadenza fissata; preferire il percorso più breve che completi e verifichi le correzioni.
- Nessun nuovo framework, pattern o cambio di architettura soltanto per correggere le etichette documentali.

## Decisioni raccolte

| ID | Decisione | Stato e origine |
|---|---|---|
| D01 | `Relazione_SWE` sempre esclusa; restante documentazione del repository nel perimetro approvato. | Esclusione confermata dall'utente, Q1; approvazione finale del piano. |
| D02 | Database ricreabile; niente obbligo di migrare dati esistenti. Test e applicazione restano separati. | Ricreabilità confermata, Q2; isolamento richiesto dall'audit #1. |
| D03 | Nessuna scadenza; finire prima possibile con le verifiche necessarie. | Confermata, Q3. |
| D04 | Offrire prezzo consigliato e inserimento manuale; superata la proposta dell'audit #17 di eliminare il manuale. | Confermata, Q4. |
| D05 | Il manuale sostituisce la base su cui applicare la formula; non è il totale finale. | Confermata, Q7; [ADR 0001](DriveHub/docs/adr/0001-base-manuale-e-prezzo-concordato.md). |
| D06 | Totale dell'acquisto fissato all'acconto, invariato dopo modifiche di basi/sconti. | Confermata, Q8; ADR 0001. |
| D07 | VIN esistente: veicolo venduto, ultima vendita al proponente, nessun'altra richiesta aperta. VIN nuovo proponibile come oggi. | Confermata, Q5. |
| D08 | Noleggio → vendita impedito durante un noleggio in corso; futuri annullati e rimborsati integralmente nella stessa transazione. | Confermata, Q6. |
| D09 | Cambio destinazione senza aggirare gli stati venduto, riservato e in attesa di valutazione. | Confermata, Q6. |
| D10 | Un noleggio cancella tutti i test drive futuri del veicolo, conservando il passato; cancellazione e operazione atomiche. | Confermata, Q9. |
| D11 | Piano e confini di verifica approvati; piano conservato fuori dal progetto, accanto agli audit. | Confermata dall'utente dopo il riepilogo finale. |
| D12 | Tracker Markdown locale esterno in `TRACKER_DRIVEHUB/`; un contesto di dominio, glossario/ADR esistenti ed etichette di triage standard. | Destinazione scelta nell'invocazione del setup; etichette confermate dall'utente. |
| D13 | Suddivisione in 18 ticket e relativi blocchi diretti approvati; un file per ticket, con prove proprie e avanzamento distinto dalla triage. | Confermata dall'utente nella revisione della proposta di `to-tickets`. |

Vocabolario: [GLOSSARY.md](DriveHub/GLOSSARY.md). Registrare decisioni nuove o cambiate qui prima di aggiornare le attività.

Tracker: [TRACKER_DRIVEHUB](TRACKER_DRIVEHUB/README.md). Convenzioni e percorsi in [issue-tracker.md](DriveHub/docs/agents/issue-tracker.md), vocabolario in [triage-labels.md](DriveHub/docs/agents/triage-labels.md), regole di dominio in [domain.md](DriveHub/docs/agents/domain.md). [Specifica](TRACKER_DRIVEHUB/revisioni/spec.md) e [18 ticket](TRACKER_DRIVEHUB/revisioni/proposta-ticket.md) pubblicati con `Status: ready-for-agent` e `State: open`; indice, criteri e dipendenze consultabili nel tracker esterno. Non serve un ulteriore triage.

## Come tenere l'avanzamento

Stati: **Proposta** (da approvare), **Pianificata** (approvata, con dipendenze da soddisfare), **Pronta**, **In corso**, **Da verificare**, **Completata**. Indicare prerequisiti mancanti nella colonna dipendenze; non segnare completata un'attività con prove richieste ancora assenti.

Confini di verifica approvati: dominio e servizi tramite interfacce pubbliche; DAO, transazioni e concorrenza su PostgreSQL dedicato con connessioni distinte; controlli mirati sulle parti JavaFX modificate. Relazione sempre esclusa.

Prima di ogni attività: leggere questa pagina, controllare Git, rileggere componenti e tutti i chiamanti interessati, riprodurre il difetto quando possibile. Durante il lavoro: una correzione e un test di comportamento alla volta. Alla fine: controllare il diff, registrare comandi/esiti/limiti e aggiornare stato e documentazione pertinente.

Per chiudere un rilievo servono comportamento corretto, verifiche pertinenti superate, chiamanti/schema/fixture coerenti e prove riferibili alla versione corrente. Se una prova non è eseguibile, registrare il motivo e lasciarla aperta. Risultati dell'audit precedente e test saltati non contano come verifiche attuali riuscite.

## Attività e dipendenze

| ID | Consegna | Audit | Dipendenze | Stato |
|---|---|---|---|---|
| R00 | Build verificabile e test DB isolati | #1, parte #13 | Nessuna; verificare e predisporre JDK 21/PostgreSQL durante R00 | Completata |
| R01 | Invarianti preservati e cambio email sicuro | #8, #19 | R00 per eseguire le prove | Completata: ticket 02 (#19) e 03 (#8) verificati e chiusi |
| R02 | Movimenti del conto corretti sotto concorrenza | #4 | R00 | Completata: ticket 04 verificato e chiuso |
| R03 | Prezzo consigliato/manuale coerente lungo il flusso | #17 | R00, D04–D05 | Completata: ticket 05 verificato e chiuso |
| R04 | Acquisto: totale concordato e conclusione una sola volta | #6, #11, parte #12 | R02, R03, D06 | Completata: 06–08 chiusi e verificati |
| R05 | Cessione: titolarità, richiesta unica, pagamento e contabilità | #2, #3, #10 | R02, R03, D07 | Completata: 09–10 chiusi e verificati |
| R06 | Noleggi/test drive concorrenti e transizioni valide | #5, #7, restante #12 | R02, R03, D08–D10; coordinamento eventi con R04 | Completata: ticket 08, 11 e 12 chiusi e verificati |
| R07 | Cancellazione account rispettosa di storico e richieste | #9 | R00; fixture aggiornate dai flussi interessati | Completata: ticket13 chiuso e verificato |
| R08 | Tabelle JavaFX senza query nel rendering | #16 | R03; verificare aggiornamenti dei flussi corretti | Completata: ticket14 verificato e chiuso |
| R09 | README, diagrammi, teoria ed evidenze coerenti | #14, #15, #18; valutazione teorica | Incrementale; chiusura dopo R01–R08 e R10 | Completata: ticket16 e17 verificati e chiusi |
| R10 | Rimozione dei componenti inutilizzati | #20 | R00; controllo riferimenti prima di rimuovere | Completata: ticket15 verificato e chiuso |
| R11 | Verifica integrata e tracciabilità completa | #13; conferma finale #1–#20 | R01–R10 | Completata:18, matrice AC01–AC20 e prove integrate verificate |

Sequenza suggerita: R00 → R01 → R02 → R03 → R04 → R05 → R06 → R07 → R08 → R10 → chiusura R09 → R11. La tabella indica i blocchi effettivi; la sequenza limita interferenze su servizi e schema condivisi.

### Mappa dei ticket pubblicati

I numeri dei ticket non coincidono con gli ID delle attività. La suddivisione approvata dettaglia i blocchi per singola consegna, evitando di imporre l'ordine generale a comportamenti indipendenti; l'ordine numerico rimane una sequenza di lavoro valida. Ogni ticket mantiene test e documentazione delle parti che modifica.

| Attività | Ticket pubblicati |
|---|---|
| R00 | 01 |
| R01 | 02, 03 |
| R02 | 04 |
| R03 | 05 |
| R04 | 06, 07, 08 |
| R05 | 09, 10 |
| R06 | 08, 11, 12 |
| R07 | 13 |
| R08 | 14 |
| R09 | 16, 17 |
| R10 | 15 |
| R11 | 18 |

### R00 — Ambiente e dati di test

- Usare JDK 21 senza abbassare il requisito del progetto. Verificare Maven e dipendenze disponibili.
- Riutilizzare la configurazione esplicita di `DatabaseManager`; aggiungere soltanto la separazione necessaria. Evitare il Singleton applicativo nei test che modificano dati.
- Configurare PostgreSQL dedicato ai test con protezione contro il collegamento accidentale al DB applicativo. Inizializzare schema e fixture ripetibili solo sul database identificato per i test.
- Separare prove dominio/servizi senza DB dalle prove PostgreSQL e documentare i comandi. Verificare che `DemoSqlValidationTest` e l'elaborazione scadenze nei test di flusso non tocchino dati applicativi.
- **Accettazione:** fixture ricaricabile; dati sentinella del DB applicativo invariati; configurazione non sicura rifiutata prima di SQL distruttivo; comandi ed esiti registrati.

### R01 — Invarianti ed email

- `Vehicle.setLicencePlate`: normalizzare e validare prima dell'assegnazione; verificare tutti i chiamanti.
- `AuthService.changeEmail`: validazione del dominio prima della scrittura, preservando normalizzazione e gestione duplicati.
- **Accettazione:** togliere la targa da un veicolo con 100 km fallisce senza cambiare l'oggetto; email con spazi non persistita e accesso precedente ancora valido.

### R02 — Saldi e transazioni condivise

- Individuare tutti i percorsi di addebito/accredito/rimborso; proteggere lettura e modifica del conto nella stessa transazione, con lock o aggiornamento atomico coerente con i DAO.
- Definire un ordine dei lock condiviso anche per rimborsi su più conti, evitando deadlock prevedibili.
- **Accettazione:** da 1.000 €, addebiti concorrenti di 100 € e 200 € lasciano 700 €; addebiti complessivamente non sostenibili non producono saldo negativo o scritture parziali.
- **Prova:** PostgreSQL reale, connessioni distinte e sincronizzazione esplicita della competizione, senza attese temporali arbitrarie.

### R03 — Prezzo consigliato e base manuale

- Mantenere la formula attuale. Il consigliato parte dalla base del modello; il manuale la sostituisce nella stessa formula con sconti, usato, anno e chilometri.
- Distinguere esplicitamente la modalità automatica dalla base manuale: non dedurre la modalità dal valore numerico. Scegliere la rappresentazione minima dopo aver verificato dominio, SQL e chiamanti.
- Aggiornare `Vehicle`, DAO/mapping, schema e demo se necessario; controllare `PriceCalculatorService`, catalogo, noleggio, cessione e viste manager/cliente. Non applicare due volte la formula a un prezzo già calcolato.
- Mostrare base e risultato con etichette chiare; prevedere il ritorno al consigliato. La stima di una cessione resta distinta dalla base scelta dal manager per il catalogo.
- **Accettazione:** entrambe le modalità producono importi attesi; base manuale 10.000 € e sconto 10%, senza altre riduzioni, danno 9.000 €; ritorno al consigliato dalla base del modello; scelta conservata dopo salvataggio/rilettura.

### R04 — Acquisto completo

- Conservare il totale concordato nella richiesta all'acconto; aggiornare dominio, schema, DAO, fixture e saldo mostrato dalla UI.
- Rileggere/bloccare la richiesta nella transazione per completamento, rifiuto e scadenza. Controllare tipo/stato e righe coinvolte; non riutilizzare oggetti caricati prima della transazione.
- Mantenere i controlli già esistenti su approvazione e scadenza, senza registrarli come funzionalità nuove.
- Cancellare obbligatoriamente i test drive nella transazione dell'acquisto. Preservare un uso motivato di Observer e propagare gli errori che impediscono di mantenere invarianti; nessuna infrastruttura distribuita necessaria.
- **Accettazione:** totale 20.000 €, acconto 4.000 €, modifica basi/sconti, saldo sempre 16.000 €; una sola vendita/addebito; rifiuto e scadenza concorrenti senza rimborsi duplicati.
- Testare rifiuto, scadenza con penale esistente, saldo insufficiente e rollback. Errore di cancellazione obbligatoria dei test drive annulla anche scritture economiche e di stato.

### R05 — Cessione alla concessionaria

- VIN esistente: verificare sotto transazione stato venduto e ultima vendita effettiva al proponente. Una vecchia vendita allo stesso cliente non basta se c'è un compratore successivo.
- Impedire richieste aperte multiple per veicolo anche nel DB; conflitti senza scritture parziali. All'approvazione rileggere/bloccare richiesta e veicolo e verificare stato in attesa.
- Acquisizioni come uscite della concessionaria; vendite ai clienti e penali come entrate. Allineare factory, commenti, DAO, fixture e registro manager.
- Testare anche rifiuto: nuovo veicolo non accettato rimosso secondo regole esistenti; veicolo con operazioni precedenti mantiene storico e stato consentito.
- **Accettazione:** VIN del catalogo/altrui rifiutato senza modifiche; proposte/approvazioni duplicate anche concorrenti producono al massimo una richiesta aperta e un accredito; segno contabile corretto.

### R06 — Noleggio, test drive e stati

- Coordinare su veicolo e cliente disponibilità/limite e inserimenti. Proteggere nel DB i periodi di noleggio dalle sovrapposizioni; conservare l'unicità test drive esistente per veicolo/data.
- Bloccare cambio destinazione dagli stati non ammessi e durante noleggi in corso, anche iniziati ieri. Testare i confini inclusivi delle date adottati dall'applicazione.
- Passaggio a vendita: annullamento/rimborso integrale dei futuri nella stessa transazione; nessun successo parziale se un conto o un rimborso manca/fallisce.
- Noleggio: cancellare tutti i test drive futuri nella stessa transazione e mantenere il passato. Coordinare con R04 interfaccia degli eventi e chiamanti.
- **Accettazione:** noleggi sovrapposti non entrambi confermati; test drive concorrenti senza superare il limite tre; competizione noleggio/test drive coerente con la priorità commerciale.
- Testare `SOLD → SALE`, `BLOCKED → RENT`, noleggio in corso, rimborsi futuri, conservazione storico e rollback per cancellazione obbligatoria fallita.

### R07 — Cancellazione account

- Rappresentazione del ruolo coerente fra dialog, servizio e DAO; controllare ogni chiamante senza conversioni duplicate.
- Includere richieste e storico; controllo e cancellazione coerenti anche con operazioni concorrenti.
- **Accettazione:** venditore con vendite concluse e cliente con richieste non cancellabili; attribuzioni storiche conservate; account senza vincoli cancellabili secondo le regole esistenti.

### R08 — Tabelle JavaFX

- Caricare modelli, sconti e prezzi per aggiornamento della tabella fuori dal thread grafico, con strumenti JavaFX esistenti e query ripetute limitate.
- Celle dedicate alla visualizzazione; gestire caricamento, errori e risultati di caricamenti precedenti senza aggiornamenti dal thread sbagliato.
- **Accettazione:** scorrimento/rendering senza nuove connessioni; caricamento lento senza bloccare la finestra; errore segnalato con riprova; prezzi aggiornati dopo modifica.
- Verificare tastiera/accessibilità delle parti modificate e registrare limiti dell'ambiente grafico.

### R09 — Documentazione e teoria

- Distinguere factory statiche da Factory Method GoF; DAO, DI e composition root dai GoF. Motivare SOLID con esempi e limiti; descrivere DDD solo per ciò che il codice dimostra.
- Distinguere direzione delle dipendenze e flusso dei dati tra presentazione, servizi, dominio e DAO/JDBC. Spiegare costruzione in `AppContext` e accessi globali residui senza promettere DI uniforme inesistente.
- Aggiornare diagrammi usati in `docs`: classi, package, sequenze, casi d'uso e navigazione; identificare quelli storici. Escludere sempre `Relazione_SWE`.
- Conservare vecchi risultati come storici; nuove evidenze con commit/diff, ambiente, comandi ed esiti. I manifest obsoleti non attestano la nuova versione.
- Documentare JDK 21, Maven, PostgreSQL, configurazione, inizializzazione/reset distruttivi, demo facoltativa e comandi dei test.
- **Accettazione:** installazione pulita riproducibile; diagrammi senza componenti/stati inesistenti; teoria sostenuta da esempi; nessun risultato non eseguito presentato come riuscito.

### R10 — Pulizia minima

- Cercare riferimenti FXML e membri di sessione `AppContext`; rimuovere `javafx-fxml`, membri/import inutilizzati solo se realmente senza usi.
- **Accettazione:** chiamanti integri, compilazione/avvio verificati, nessun refactor estraneo.

### R11 — Chiusura e tracciabilità

- Collegare per ogni flusso regola, percorso normale/alternativo, responsabilità e test concreto. Completare la matrice con nomi effettivi dei test quando esistono.
- Prove mirate prima della suite completa sullo stato finale. PostgreSQL dedicato per concorrenza, SQL e rollback reale; DAO simulati per decisioni applicative.
- Verificare flussi JavaFX modificati e renderizzare diagrammi aggiornati se gli strumenti sono disponibili.
- **Accettazione:** tutti i 20 rilievi hanno prove o limiti espliciti; senza verifiche richieste restano aperti. Revisionare il diff rispetto a requisiti e convenzioni, senza auto-commit/pubblicazioni.

## Matrice requisiti → progetto → verifica

La [matrice completa AC01–AC20](DriveHub/docs/evidence/r11-integrated/acceptance-matrix.md)
è il riferimento unico: per ogni rilievo espone ticket/R, comportamento principale,
alternativa lecita, errore/rifiuto/rollback e **nomi effettivi dei test**.
Distingue test dominio/servizi, PostgreSQL reale, controlli JavaFX e ispezioni statiche;
FullWorkflowIntegrationTest prova soprattutto login/caricamenti, non completa da solo
le operazioni economiche.

Nuove esecuzioni18: mirati363/363, sette harnessJavaFX, suite finale394/394
(47senzaDB/347PostgreSQL), gare con PID/blocker distinti e rollback dopo scritture
reali. [Catalogo dei casi eseguiti](DriveHub/docs/evidence/r11-integrated/executed-tests.json),
[versione/input/comandi/risultati/limiti](DriveHub/docs/evidence/r11-integrated/verification.md).
I precedenti numeri01–17 restano storici; nessun tentativo fallito, controllo omesso
oppure schermata semplicemente caricata è promosso a flusso riuscito.

## Evidenze e limiti della baseline

- Riletti componenti mirati: difetti ancora riconoscibili staticamente; nessuna nuova riproduzione runtime.
- `completePurchase` controlla già autorizzazione/scadenza. Unicità test drive veicolo/data già presente: non protegge gli altri controlli concorrenti.
- Ricalcolati due manifest in `docs/evidence`: ciascuno ha 150 voci, 149 percorsi mancanti e hash `pom.xml` diverso. Evidenze storiche, non prove correnti.
- Maven 3.9.16 disponibile; Java Linux 17.0.20.1 attivo, progetto Java 21. JDK 21 Windows trovato ma non utilizzabile nella prova: errore WSL `UtilBindVsockAnyPort:317: socket failed 1`.
- `psql`, `pdftotext`, `mutool`, `gs` assenti dal PATH; librerie Python PDF verificate assenti. Disciplinare non riletto direttamente: riferimenti didattici dai due audit.
- PostgreSQL non contattato: assenza di `psql` non dimostra assenza di server o impossibilità di usare JDBC.
- Prove temporanee dell'audit precedente non disponibili. I suoi 14 test e controlli temporanei sono risultati storici, non eseguiti oggi.

## Registro delle sessioni

| Sessione | Attività e risposte | Stato/prossimo passo |
|---|---|---|
| 2026-10-31 — avvio | Audit e codice mirato; baseline/strumenti verificati. Q1: relazione esclusa. Q2: DB ricreabile. Q3: nessuna scadenza. | Ricognizione registrata; nessuna modifica applicativa. |
| 2026-10-31 — regole | Q4: consigliato e manuale. Q5: titolarità/unicità. Q6: blocco in corso e rimborsi futuri. Q7: manuale come base. Q8: totale fissato. Q9: tutti i test drive futuri cancellati. | Piano, glossario e ADR registrati; riepilogo finale/confini di verifica da confermare. |
| 2026-10-31 — documentazione | Creati registro, glossario, ADR prezzi e istruzioni persistenti; collegamento dal README. Controlli documentali e perimetro Git superati. | Codice applicativo invariato, nessun rilievo chiuso. |
| 2026-10-31 — approvazione e collocazione | L'utente approva il piano e chiede di collocarlo fuori dal progetto, come gli audit. Spostato in `PIANO_REVISIONI_DRIVEHUB.md` nella directory esterna; aggiornati i collegamenti. | Intervista conclusa; R00 pronta; nessuna correzione applicativa eseguita. |
| 2026-10-31 — setup skill | Confermato tracker locale esterno, riutilizzati glossario/ADR esistenti, mostrate bozze e approvate etichette standard. Creati `docs/agents/issue-tracker.md`, `triage-labels.md`, `domain.md` e indice esterno del tracker; aggiornato `AGENTS.md`. Controlli documentali, etichette, percorsi, perimetro Git e `git diff --check` superati. | Setup completato; prossime skill `to-spec` e `to-tickets`; 0/20 rilievi chiusi. |
| 2026-10-31 — specifica | Riutilizzati piano, glossario, ADR e confini di verifica già approvati. Pubblicata nel tracker esterno la specifica con 59 storie utente, decisioni implementative, verifiche e criteri AC01–AC20; nessuna nuova intervista. Controlli di struttura, numerazione, copertura, collegamenti, whitespace, collocazione e perimetro Git superati; `git diff --check` superato. | `ready-for-agent`; prossima skill `to-tickets`; 0/20 rilievi chiusi, nessun test applicativo eseguito. |
| 2026-10-31 — proposta ticket | Preparate 18 bozze separate, riepilogo numerato, blocchi diretti e mappa attività/ticket; specifica lasciata invariata. | In attesa di approvazione della suddivisione, nessun ticket effettivo pubblicato; 0/20 rilievi chiusi. |
| 2026-10-31 — pubblicazione ticket | L'utente approva i 18 ticket e le dipendenze. Pubblicato un file per ticket con `ready-for-agent` e `State: open`; indice e registro aggiornati. Controlli di copertura, metadati, grafo, link, whitespace e perimetro Git superati; specifica invariata verificata con hash; `git diff --check` superato. | Prima attività pronta: ticket 01 / R00; 0/20 rilievi chiusi, nessuna implementazione eseguita. |

| 2026-10-31 — ticket 01 / R00 | Implementati configurazione protetta, fixture, iniezione AppContext, tag/profilo PostgreSQL e documentazione. 70 sorgenti compilati e 21 test senza DB passati con Java 17; prova negativa senza config e controlli statici superati. Verifiche Java 21/DB non disponibili; dettagli e comandi nel ticket. Nessun commit per richiesta utente. | R00 in corso, 0/20 rilievi chiusi; riprendere ticket 01 con JDK 21/PostgreSQL, eseguire fixture, sentinella e suite completa prima di proseguire. |

Per ogni sessione aggiungere attività, decisioni, verifiche realmente eseguite, limiti e prossimo passo. Non ricopiare vecchi esiti come nuovi.

### Dettaglio sessione R00 — 31 ottobre 2026

- Perimetro: `pom.xml`, `AppContext`, test e README/`docs/testing.md`; piano e ticket
  aggiornati fuori dal progetto. Modifiche preesistenti a README, istruzioni e dominio
  preservate; `Relazione_SWE` esclusa da letture, ricerche, modifiche e verifiche.
- Decisione attuativa: database e ruolo di test chiamati `drivehub_test`, senza
  fallback né parametri JDBC; controlli di identità/proprietà/privilegi prima del reset.
  Nessun cambio dei requisiti Java e nessuna nuova dipendenza. Resources fissato a
  3.3.1 per ripetibilità tra versioni Maven; connessione sentinella esplicita e read-only.
- Comandi ed esiti: `java -version`, `mvn -version` mostrano Java 17.0.20.1/Maven 3.9.16;
  JDK 21 Windows fallisce con errore WSL. `mvn -o -Dtest=TestDatabaseConfigurationTest test`
  prima bloccato da resources implicito 3.4.0 mancante, poi da `invalid target release: 21`.
  Anche `mvn -o -Ppostgres-tests test` fallisce prima dei test per target 21 non supportato.
  Cache Surefire 3.2.5 incompleta. `javac -Xlint:all` temporaneo: 70 sorgenti, nessun warning;
  JUnit tramite launcher locale: 7/7 configurazione e 21/21 senza DB, nessun test saltato,
  **solo Java 17**. Test PostgreSQL senza variabili: fallisce prima della connessione,
  come richiesto. XML/tag/chiamanti e `git diff --check` superati.
- Limiti: sei variabili DB/sentinella assenti; `psql` assente, Docker non disponibile
  per WSL; sonda TCP vietata (`Operation not permitted`), DNS download JDK non risolto.
  Non si deduce che il server PostgreSQL non esista. Nessun SQL applicativo eseguito;
  fixture ripetibile e dati sentinella invariati sono prove scritte ma non eseguite.
- Prossimo passo vincolante: lo stesso ticket 01, con JDK 21 Linux e PostgreSQL dedicato;
  comandi mirati e suite completa in `DriveHub/docs/testing.md`. Finché mancano le prove,
  R00 resta in corso e il conteggio rimane **0/20**. Nessun altro ticket avviato.
- Revisione finale con skill `code-review` su diff locale: standard 0 violazioni/smell,
  specifica 0 difetti implementativi confermati ma criteri runtime ancora parziali.
  Richiesta utente recepita: nessun commit, modifiche conservate solo nei file di lavoro;
  selezione nell'indice rimossa. HEAD rimasto alla baseline.

### Ripresa e chiusura R00 — 31 ottobre 2026

- Risolto il blocco d'ambiente: pacchetti JDK Linux 21.0.12.1 da apt Ubuntu,
  PostgreSQL 16.15 e librerie compatibili dal repository ufficiale Ubuntu, estratti
  sotto /tmp senza privilegi root o servizi di sistema. Download IPv4 autorizzati.
- Cluster nuovo `/tmp/drivehub-r00-pgdata`, porta 55432: ruolo e DB dedicati test,
  copia applicativa distinta con sentinella. Mai contattato il DB applicativo preesistente.
- `mvn -Dtest=TestDatabaseConfigurationTest test`: 7 passati; `mvn test`: 21 passati;
  quattro test PostgreSQL mirati: 7 passati; prova ruolo CREATEDB: reset rifiutato,
  sentinelle conservate e ruolo ripristinato. `mvn -Ppostgres-tests clean test`:
  ricompilazione target 21, BUILD SUCCESS, 28 passati, nessun errore o salto.
- Log, versione e hash in `DriveHub/docs/evidence/r00/`; istruzioni di riavvio locale
  in `DriveHub/docs/testing.md`. Server temporaneo arrestato dopo le verifiche;
  binari, cluster e credenziali private restano temporanei e non sono committati.
- Ticket 01 chiuso con tutti i criteri soddisfatti, R00 completata, #1 chiuso e #13
  ancora parziale: **1/20** rilievi chiusi. Le voci storiche 0/20 restano storiche.
- Nessuna modifica al codice nella ripresa; nessun commit e relazione sempre esclusa.
  Prossimo passo: ticket 02, non avviato in questa sessione.
- Controlli finali superati: link/whitespace, hash SHA-256 dei sorgenti verificati, assenza di credenziali nelle evidenze, file ambiente 0600 e perimetro Git; indice vuoto, HEAD invariato. Arresto del server temporaneo confermato con `pg_ctl stop`.


### Ticket 02 — invarianti del veicolo, 31 ottobre 2026

- Ticket 01 controllato: `State: closed`, 6/6 criteri ed evidenze R00 presenti. Ripreso l'ambiente Java 21/PostgreSQL documentato in `DriveHub/docs/testing.md`.
- Prima di modificare il dominio, aggiunta regressione sul comportamento pubblico del veicolo con 100 km: `null`, targa vuota e spazi/tab sollevano l'errore ma perdono la targa nella versione precedente. `Vehicle.setLicencePlate` ora normalizza e valida prima dell'assegnazione. Messaggio, API e modifiche valide preservati.
- Chiamanti verificati: `SaleToDealershipService.submitSaleProposal` unico setter applicativo; controllati anche invio/errore UI, creazione da catalogo, factory, mapping/salvataggio DAO e vincolo SQL. Nessun adeguamento a chiamanti, schema o fixture necessario. Aggiunte prove di normalizzazione, aggiornamento valido e rimozione a zero chilometri.
- Comandi tramite launcher R00: `python3 /tmp/drivehub-r00-maven.py ticket02-red -Dtest=DomainInvariantsTest#testRejectedVehiclePlateChangeLeavesVehicleUnchanged test` → **3 failure attese**, 0 errori/saltati; stesso comando con `ticket02-green` → **3/3** dopo la correzione. `ticket02-targeted -Dtest=DomainInvariantsTest test` → **15/15**; `ticket02-no-db test` → **28/28**; `ticket02-full -Ppostgres-tests clean test` → **35/35**, 0 failure/errori/saltati (62 sorgenti principali e 8 test, target 21).
- Cluster R00 riavviato solo su `127.0.0.1:55432`; avvio sandbox fallito sul socket, poi avvio e suite DB riusciti con escalation autorizzata. Isolamento/sentinella passati sulla copia applicativa; nessun accesso al DB applicativo preesistente. `pg_ctl ... -m fast -w stop` riuscito.
- Revisione finale skill `code-review`, due assi indipendenti: Standards **0**, Spec **0** rilievi. Verificati log, XML Surefire, hash dei sorgenti, assenza di password nelle evidenze e conservazione dei 22 file con modifiche preesistenti. HEAD invariato, nessun commit, relazione sempre esclusa.
- Ticket 02 chiuso con **4/4 criteri** soddisfatti; rilievo #19 chiuso, totale **2/20** (#1 e #19). R01 resta in corso per #8/ticket 03; #13 resta trasversale e parziale. Le voci precedenti 0/20 e 1/20 sono storiche.
- [Evidenze e revisione](DriveHub/docs/evidence/r01-vehicle/verification.md); [ticket aggiornato](TRACKER_DRIVEHUB/revisioni/issues/02-invarianti-veicolo.md). Limiti: warning JavaFX preesistente, nessuna verifica grafica, nessun altro difetto certificato; `/tmp` temporanea.
- Prossimo passo: ticket 03 in una richiesta separata. Nessun altro ticket lavorato durante questa sessione.

### Ticket 03 — cambio email sicuro, 31 ottobre 2026

- Verificati ticket 01 e 02 chiusi con tutti i criteri soddisfatti. Ripreso ambiente R00 Java 21/PostgreSQL da `DriveHub/docs/testing.md`; nessun altro ticket lavorato.
- Riproduzione pubblica tramite `AuthService.changeEmail`: indirizzo con spazi interni accettato sui tre ruoli prima della correzione. Il servizio ora riusa l'utente caricato per verificare la password, applica `User.updateEmail` prima della transazione e persiste l'indirizzo validato/normalizzato. Helper privato restituisce l'utente; nessuna query aggiuntiva. Conservati password, gestione duplicati SQL/rollback, API pubbliche, messaggi, schema e fixture.
- Stesso test prima/dopo: `python3 /tmp/drivehub-r00-maven.py ticket03-red -Ppostgres-tests -Dtest=AuthServiceIntegrationTest#rejectedEmailPreservesStoredIdentityAndLogin test` → **3 failure attese**, nessuna eccezione; etichetta `ticket03-green`, stessi argomenti → **3/3**. `ticket03-targeted -Ppostgres-tests -Dtest=AuthServiceIntegrationTest test` → **18/18**; `ticket03-no-db test` → **28/28**; `ticket03-full -Ppostgres-tests clean test` → **53/53**, 0 failure/errori/saltati, incluse 25 prove PostgreSQL. XML Surefire controllati; ricompilati 62 sorgenti principali e 9 test con target 21.
- PostgreSQL reale dedicato: rifiuto spazi interni con dato precedente e login invariati; successo normalizzato aggiornato e riletto, vecchio indirizzo non più attivo; duplicati nello stesso ruolo e fra ruoli senza modificare nessuna delle due identità/accessi; password errata e altri input invalidi rifiutati. Tutto tramite servizi pubblici, senza mock o Singleton applicativo.
- Controllati tutti i chiamanti: gestione account, dashboard dei tre ruoli, login/registrazione, composizione App/AppContext, dominio/factory, DAO/mapping, routing ruoli, schema/trigger/vista; tutti gli usi dell'helper password. Nessun adeguamento necessario ai chiamanti. Nessuna nuova politica identità o modifica ad altri flussi.
- Solo cluster temporaneo R00 su `127.0.0.1:55432`; primo avvio sandbox fallito sul socket, poi avvio/prove con escalation autorizzata. Sentinella sulla copia applicativa e fixture passate; nessun contatto con DB applicativo preesistente. Server arrestato (`pg_ctl ... -m fast -w stop`).
- Revisione finale skill `code-review`: due agenti con contesti nuovi sul diff locale fissato rispetto a HEAD, **Standards 0 rilievi; Spec 0 rilievi**. SHA-256 sorgenti e dei 31 file locali preesistenti verificati, XML/log e `git diff --check` controllati, nessuna password privata nelle evidenze. HEAD invariato; nessun commit; Relazione_SWE sempre esclusa.
- [Evidenze complete e limiti](DriveHub/docs/evidence/r01-email/verification.md); [ticket aggiornato](TRACKER_DRIVEHUB/revisioni/issues/03-cambio-email-sicuro.md). **4/4 criteri soddisfatti**, ticket 03 chiuso, R01 completata, #8 chiuso: totale **3/20** (#1, #8, #19); #13 resta parziale. Voci precedenti conservate come storico.
- Limiti: UI grafica non eseguita, nessuna UI modificata; warning JavaFX preesistente; altri difetti e nuove politiche/concorrenza identità non verificati; ambiente `/tmp` temporaneo.
- Prossimo passo: ticket 04 / R02 soltanto in una successiva richiesta. Nessun altro ticket avviato in questa sessione.

### Ticket 04 — saldi concorrenti, 31 ottobre 2026

- Verificati 01/02/03 chiusi; ripreso ambiente Java 21/PostgreSQL R00 e preservate tutte le modifiche locali. Solo ticket 04 lavorato, Relazione_SWE esclusa da ogni operazione.
- Mappati ricariche, acconti/saldi acquisto, rifiuti/scadenze, pagamenti cessioni, noleggi e annullamenti. Unica lettura DAO con lock transazionale; quattro servizi aggiornati su tutti gli otto movimenti. Ordine ID cliente crescente nei rimborsi multipli e fallimento atomico se manca un conto. Nessuna nuova dipendenza, modifica schema/demo o correzione di difetti estranei.
- RED tramite servizi pubblici su PostgreSQL reale: da 1000, richieste da 100/200 entrambe riuscite lasciavano 800, test fallito rispetto a 700. Stesso test dopo correzione passa. Gate esterno, due backend distinti e lock osservati con pg_stat_activity/pg_blocking_pids prima del rilascio; niente sleep/mock e attese limitate. Due ulteriori RED prima della correzione dimostrano lock incoerenti nei rimborsi e conto mancante ignorato.
- Comandi launcher: `python3 /tmp/drivehub-r00-maven.py ticket04-red -Ppostgres-tests -Dtest=BalanceConcurrencyIntegrationTest#concurrentPurchaseDepositsKeepBothDebits test` → **1 failure attesa**; stessi argomenti con etichetta `ticket04-green` → **1/1**. `ticket04-refunds-red` con i due metodi riportati nel [ticket](TRACKER_DRIVEHUB/revisioni/issues/04-saldi-concorrenti.md) → **2 failure attese**, poi verdi. Primo ampliamento bloccato in tre casi dalla sola fixture (venditore 21 inesistente, corretto a 16), poi 15/15; aggiunta prova autocommit.
- `python3 /tmp/drivehub-r00-maven.py ticket04-final-targeted -Ppostgres-tests -Dtest=BalanceConcurrencyIntegrationTest test` → **16/16**; `python3 /tmp/drivehub-r00-maven.py ticket04-full -Ppostgres-tests clean test` → **69/69**, nessuna failure/errore/salto: 28 senza DB e 41 PostgreSQL. Ricompilati 62 sorgenti e 10 test target 21. Isolamento/sentinella passati. Verificati fondi insufficienti senza effetti parziali, tutti gli otto flussi contro ricariche concorrenti, più conti e rimborsi ripetuti; errori PostgreSQL dopo movimenti effettivi annullano tutte le scritture fallite.
- Prima sonda nella sandbox con connessione rifiutata perché il processo server non persisteva tra comandi; riavvio e prove riusciti con escalation autorizzata. Solo cluster sacrificabile 127.0.0.1:55432, database test e copia applicativa sentinella; nessun collegamento al DB applicativo preesistente. Server arrestato con `pg_ctl ... -m fast -w stop`.
- Revisione finale skill `code-review`: patch della sola sessione fissata prima delle revisioni, due agenti indipendenti con contesti nuovi, **Standards 0; Spec 0** rilievi. Nessuna modifica a codice/test dopo suite e review. XML/log/hash e whitespace/link controllati; segreti privati assenti dalle evidenze. 38/40 file locali precedenti invariati; soli cambi intenzionali in AuthService (lettura conto) e docs/testing.md (appendice). HEAD invariato e indice senza staging; nessun commit.
- [Evidenze e limiti completi](DriveHub/docs/evidence/r02-balances/verification.md). **5/5 criteri soddisfatti**, ticket 04 chiuso, R02 completata, #4 chiuso: **4/20** (#1, #4, #8, #19); #13 resta trasversale e parziale. Voci precedenti conservate come storico.
- Limiti: UI grafica non eseguita, nessuna UI modificata; warning JavaFX preesistente; concorrenza/transizioni delle richieste, prenotazioni, eventi, prezzi, segni contabili e cancellazione account restano agli altri ticket. Ordine garantito fra conti. Ambiente `/tmp` temporaneo; relazione esclusa.
- Prossimo passo: ticket 05 / R03 in una richiesta successiva. Nessun altro ticket avviato in questa sessione.


### Ticket 05 — prezzo consigliato e base manuale, 31 ottobre 2026

- Ticket 01/02/03/04 controllati chiusi; istruzioni/glossario/ADR letti prima del codice.
  Baseline della sessione separata dal lavoro locale preesistente, nessun commit.
- Mappati dominio, tutti i DAO/mapping, catalogo, acquisto/acconto/saldo, noleggio,
  cessione e viste manager/cliente/venditore. Modalità esplicita persistita in SQL;
  scelta manager limitata ai campi prezzo/modalità, formula condivisa e mai duplicata.
  Automatico dalla base modello corrente, manuale dalla base scelta; consigliato
  sempre distinto. Stima cessione nella richiesta, base commerciale preservata.
- RED pubblico dominio e catalogo PostgreSQL: 18000 anziché 9000 su base manuale
  10000 con sconto 10%; stessi test GREEN dopo correzione. Ulteriore RED cessione
  dimostra base commerciale sovrascritta dalla stima; corretto senza anticipare
  titolarità, unicità richieste o contabilità dei ticket successivi.
- Mirati iniziali 19/19, prima suite 82/82. Revisione Spec indipendente: frazioni di
  centesimo difformi prima/dopo persistenza. Due RED con 10000.005 → 9000.00 anziché
  9000.01; normalizzazione HALF_UP nel dominio prima della formula, dopo controllo
  segno e condivisa da factory manuale/setter. Input -0.001 rifiutato senza mutazioni.
- Comandi tramite launcher R00, log integrali nel rapporto: `ticket05-red/green`,
  `ticket05-persistence-red/green`, `ticket05-cession-red`, `ticket05-rounding-red`.
  `python3 /tmp/drivehub-r00-maven.py ticket05-rounding-green -Ppostgres-tests
  -Dtest=PriceCalculatorServiceTest,PriceSelectionIntegrationTest test` → **21/21**.
  `python3 /tmp/drivehub-r00-maven.py ticket05-final-full -Ppostgres-tests clean test`
  → **84/84**, zero failure/errori/saltati, 33 senza DB e 51 PostgreSQL. Compilati
  63 sorgenti principali e 11 test, target 21. Comprese 16 prove concorrenza conti 04,
  isolamento/sentinella e ripetibilità fixture. Nessun mock certifica la persistenza.
- Persistenza verificata tramite servizi pubblici: manuale uguale al modello resta
  manuale dopo cambio base modello, ritorno automatico riletto, prezzi in acquisto
  e noleggio coerenti, geometrica/date inclusive preservate, stima cessione separata.
- JavaFX Robot sul display isolato Xvfb: scelta e ritorno al consigliato salvati
  da tastiera, focus/frecce/Tab/Spazio/Invio e navigazione al noleggio; risultato
  10000 → 9000 verificato dopo rilettura. Quattro screenshot ispezionati. Primo
  rendering con demo completa oltre timeout per query nelle celle; controllo finale
  su fixture ridotta, limite ticket 14 documentato senza modificarne il perimetro.
- Review finale indipendente su patch fissata della sola sessione e hash 16/16:
  Standards 0, Spec 0 rilievi residui dopo correzione dei centesimi. Nessun cambiamento
  a codice/test dopo suite e review. 57/62 file locali preesistenti identici; i 5 file
  aggiornati intenzionalmente conservano il lavoro precedente. HEAD invariato e
  indice senza staging. PostgreSQL temporaneo e Xvfb arrestati.
- **6/6 criteri soddisfatti, ticket 05 chiuso, R03 completata, #17 chiuso: 5/20**.
  [Evidenze complete e limiti](DriveHub/docs/evidence/r03-prices/verification.md).
  Le voci precedenti restano storiche; #13 rimane trasversale e parziale.
- Limiti: schema ricreabile senza migrazione storica; DB applicativo preesistente
  mai contattato. Nessun congelamento del totale concordato, altri difetti ai ticket
  successivi, nessuna certificazione prestazionale completa/screen reader. Warning
  JavaFX preesistente, /tmp temporanea e relazione sempre esclusa.
- Prossimo passo: ticket 06 / R04 in una richiesta successiva; nessun altro ticket lavorato.


### Ticket 06 — totale concordato all'acconto, 31 ottobre 2026

- Prerequisiti 04 e 05 e precedenti 01–05 controllati chiusi. Baseline completa locale
  acquisita prima degli interventi, comprendente modifiche pregresse; confronto sessione
  separato da HEAD. Nessun commit/staging; Relazione_SWE sempre esclusa.
- Mappati dominio Request, tutti i SELECT/INSERT/UPDATE/mapper DAO, schema e fixture,
  servizi di acquisto/consultazione/cessione e viste cliente/venditore. `agreedTotal`
  persistito insieme ad acconto/addebito/prenotazione; saldo e vendita usano l'accordo.
  Importi immutabili e validati; stima cessione separata e flussi preesistenti preservati.
- Formula condivisa/base esplicita/centesimi del ticket 05 invariati; lock e transazioni
  dei conti e prenotazione atomica conservati. Nessuna anticipazione di competizioni,
  eventi/transizioni o prestazioni appartenenti ad altri ticket.
- Comandi launcher R00: `ticket06-agreement-red -Ppostgres-tests -Dtest=PurchaseAgreementIntegrationTest test`
  → 2 failure (28000/24000 invece di 20000); stessi argomenti `ticket06-agreement-green-v3`
  → 2/2. Mirati `ticket06-targeted` (elenco nel ticket) → 57/57.
  `ticket06-final-full -Ppostgres-tests clean test` → 103/103, zero failure/errori/saltati:
  40 senza DB, 63 PostgreSQL, incluse 16 prove conti, fixture e isolamento/sentinella.
- Verificati 20000/4000/16000 in entrambe le modalità, cambi basi/modalità/sconti,
  rilettura/nuovo AppContext e fixture anno precedente; centesimi, fondi insufficienti,
  controlli approvazione/scadenza e rollback PostgreSQL dopo addebito su ogni scrittura
  principale del percorso. Nessun mock usato come prova della persistenza.
- Solo cluster sacrificabile 127.0.0.1:55432, DB/ruolo dedicati e copia applicativa
  sentinella; nessun contatto con database applicativo preesistente. Primo tentativo
  sandbox non raggiungibile, ripreso con escalation; allineata fixture demo dopo due
  esecuzioni GREEN fallite in setup. Dettagli nel ticket e nelle evidenze.
- JavaFX cliente/venditore: due JVM separate, importi riletti, stima cessione distinta,
  frecce/Tab/Spazio/Invio per approvazione, saldo e avvio acquisto. Corretto soltanto
  contrasto selezione nelle due tabelle modificate. Raccolta finale/review in completamento.
- Limiti: schema ricreabile senza migrazione storica, fixture GUI ridotta, nessuna
  certificazione prestazionale/screen reader; ambiente /tmp temporaneo. Competizione
  completamento/rifiuto/scadenza al ticket 07, eventi/transizioni ai rispettivi ticket.
- Stato: ticket 06 aperto in attesa di verifica finale indipendente; R04 parziale.
  Prossimo passo: completare lo stesso ticket, senza passare al successivo.
  [Evidenze](DriveHub/docs/evidence/r04-agreement/verification.md).


### Ticket 07 — richieste di acquisto una volta, 2 novembre 2026

- Passaggio esplicitamente autorizzato dall'utente; prerequisito diretto 04 chiuso.
  Il ticket 06 rimane **aperto in verifica finale**, file esterno e lavoro preservati.
  La sua chiusura non è stata attesa né implicata. Nessun altro ticket avviato.
- Baseline dedicata prima degli interventi, 272 file locali e copie esterne:
  diff separato da HEAD e dal lavoro dei precedenti ticket. 266 file invariati;
  6 aggiornati intenzionalmente e un nuovo test. Nessun commit/staging/push.
- Mappati tutti i chiamanti. RequestDao offre lettura FOR UPDATE con transazione
  attiva; saldo/rifiuto/scadenza e approvazione usano la stessa connessione protetta.
  Tipo, approvazione, scadenza e transizioni da BLOCKED ricontrollati; zero righe
  aggiornate/eliminate causa rollback. La scadenza usa solo gli ID iniziali, rilegge
  e restituisce notifica soltanto dopo commit. Nessuna modifica a UI/schema/fixture
  applicativa, protocollo conti 04 e totale concordato 06 conservati.
- RED `python3 /tmp/drivehub-ticket07-maven.py red -Ppostgres-tests
  -Dtest=PurchaseConcurrencyIntegrationTest#concurrentCompletionsChargeAndSellOnlyOnce test`
  → 1 failure attesa (anche seconda sessione conclude); stessi argomenti `green` → 1/1.
  Connessioni reali distinte, gate SQL e attese osservate tramite PID PostgreSQL:
  saldo/saldo, saldo/rifiuto nei due ordini, saldo/scadenza, rifiuti/scadenze ripetuti,
  approvazioni obsolete, proroga concorrente nei due ordini. Nessuno sleep o mock.
- Verificati 4000 → penale 800/rimborso 3200 una volta, saldo senza approvazione
  o scaduto rifiutato, conto mancante/stato incoerente, notifiche con rimborso effettivo.
  24 casi errore/scrittura saltata provano rollback dopo movimenti effettivi, con
  rilettura di accordo, richiesta, veicolo, conto e registro da nuovi AppContext.
- Mirati finali `python3 /tmp/drivehub-ticket07-maven.py final-targeted -Ppostgres-tests
  -Dtest=PurchaseConcurrencyIntegrationTest,PurchaseAgreementIntegrationTest,BalanceConcurrencyIntegrationTest test`
  → **88/88** (60 ticket07 + 12 accordo 06 + 16 conti 04).
  Suite `python3 /tmp/drivehub-ticket07-maven.py full -Ppostgres-tests clean test`
  → **163/163**, 0 failure/errori/saltati, 40 senza DB e 123 PostgreSQL; 63 sorgenti
  principali + 14 test ricompilati con target 21 e lint, fixture/isolamento/sentinella passati.
- Ambiente R00 assente: verificati inizialmente Java17 e Maven; ricreati JDK Linux
  21.0.12.1/PostgreSQL16.15 da pacchetti Ubuntu ufficiali estratti in /tmp. Download
  sandbox fallito per DNS, poi riuscito con escalation. Nuovo cluster sacrificabile
  127.0.0.1:55432, DB/ruolo drivehub_test e nuova copia applicativa con sentinella;
  nessun accesso al DB applicativo preesistente. Segreti 0600 fuori repository,
  nessuna password privata nelle evidenze; server arrestato alla fine.
- Review indipendente sul solo diff 07 fissato: **Standards 0 violazioni / 1
  osservazione non bloccante** sul supporto gare simile al 04; **Spec 0 rilievi**.
  Supporto lasciato separato per le differenze nei gate, senza refactor estraneo.
  Hash/XML/log/link/whitespace e preservazione controllati, HEAD/indice invariati.
  Nessun codice/test cambiato dopo suite/review. Relazione sempre esclusa.
- [Evidenze e limiti](DriveHub/docs/evidence/r04-purchase-once/verification.md).
  **6/6 criteri soddisfatti, ticket 07 chiuso e rilievo #6 chiuso: 6/20**.
  AC13 ancora parziale; R04 resta in corso, **06 aperto in verifica finale / 08 non avviato**.
- Limiti: nessuna UI modificata/prova grafica; warning JavaFX preesistente; Observer
  transazionale e cancellazione obbligatoria dei test drive al ticket 08; nessuna
  nuova regola economica o migrazione. Ambiente /tmp temporaneo.
- Prossimo passo: riprendere la verifica finale del 06; altri ticket soltanto in
  successiva richiesta. Voci storiche precedenti conservate senza riscriverne gli esiti.


### Chiusura ticket 06 — 2 novembre 2026

- Registrati gli esiti delle review indipendenti della sessione del 31 ottobre:
  Standards 0 violazioni / 0 smell, Spec 0 rilievi. Conferma read-only di entrambi
  i revisori sul codice corrente dopo il 07: nessun impedimento alla chiusura 06.
- Verificati 17/17 file interni dello snapshot 06 nella baseline 07; i 7 file
  certificati del 07 erano identici al corrente prima degli aggiornamenti documentali
  di chiusura; nessun altro sorgente cambiato.
  XML della suite 07 ricontrollati: 163/163, zero failure/errori/salti, compresi i
  19 test del 06, conti e isolamento/sentinella. Nessun test/DB/GUI rieseguito:
  questa ripresa modifica soltanto documenti, stato e prove di chiusura.
- Restano valide le prove RED/GREEN, 57 mirati, 103 della suite del 06 e GUI/tastiera
  in due JVM; viste e harness immutati. Patch e hash originali del 06 conservati,
  senza includere il lavoro successivo del 07 nel diff. Vecchia /tmp del 06 rimossa;
  nuova baseline documentale in /tmp/drivehub-ticket06-closure-20261102.
- **6/6 criteri verificati, State: closed, rilievo #11 chiuso**. Totale aggiornato
  **7/20** con #6 già chiuso dal 07; AC13 resta trasversale e parziale. R04 in corso
  soltanto per 08. Le sezioni precedenti descrivono lo stato storico di ogni sessione.
- Tutti gli 81 file src sono rimasti identici durante la chiusura; controllati hash,
  link, whitespace, HEAD e indice. Nessun commit/staging, nessuna modifica al 07 o
  agli altri ticket, Relazione_SWE sempre esclusa. Limiti schema/GUI già documentati.
- Prossimo passo: 08 su nuova richiesta; nessun altro lavoro avviato.
  [Evidenze](DriveHub/docs/evidence/r04-agreement/verification.md).

### Ticket 08 — cancellazione atomica dei test drive, 2 novembre 2026

- Prerequisito 04 e precedenti 01–07 controllati chiusi. Baseline dedicata prima
  degli interventi, senza includere Relazione_SWE. Lavoro preesistente preservato;
  confronto della sessione distinto da HEAD. Nessun commit/staging.
- Difetto riprodotto tramite completePurchase/bookRental: 2 failure attese,
  errore di cancellazione nascosto dopo il commit. Stessa regressione GREEN 2/2.
- Observer conserva la priorità commerciale sui test drive, sincrono nella
  transazione del chiamante; nessuna seconda transazione o errore nascosto.
  Evento di conferma vendita/noleggio senza finta transizione RENT → RENT.
- PostgreSQL reale dedicato, ambiente temporaneo del 07 presente e verificato;
  vecchi file R00 assenti. Avvio sandbox rifiutato sui socket, poi escalation
  autorizzata su 127.0.0.1:55432, nessun DB applicativo preesistente contattato.
- Primi 8 casi passati: rollback integrale dopo tutte le cancellazioni e scritture
  economiche, successo, storico/altri veicoli, nessun futuro, confine temporale
  −1/0/+1 microsecondo. Suite completa e review Standards/Spec da completare.
- Nessuna vista modificata. Formula/accordo/protocolli 04–07 preservati; conflitti
  di prenotazione 11 e altre transizioni restano esclusi. Ticket 08 in-progress.
  Prossimo passo: completare questo stesso ticket; non passare al successivo.

### Chiusura ticket 08 — 2 novembre 2026

- **5/5 criteri soddisfatti, State: closed**. I progressi sopra restano storici.
  Notifica commerciale sincrona sulla connessione del chiamante, Observer mantiene
  la politica sui test drive; cancellazione obbligatoria prima del commit.
  Tutti i futuri cancellati anche fuori periodo noleggio, storico conservato.
- Nuovi 8/8: errore PostgreSQL AFTER DELETE dopo addebito/operazione/cancellazioni
  annulla conto, vendita/noleggio, richiesta/accordo, stato e test drive; servizio
  fallisce, nuove sessioni rileggono dati integri. Successo, altro veicolo, nessun
  futuro e confine transazionale −1/0/+1 microsecondo coperti nei due servizi.
- Launcher `/tmp/drivehub-ticket08-maven.py`: `red -Ppostgres-tests
  -Dtest=TestDriveCancellationIntegrationTest test` → 2 failure attese; stessi
  argomenti `green` → 2/2; `cases` → 8/8. `targeted -Ppostgres-tests
  -Dtest=TestDriveCancellationIntegrationTest,PurchaseConcurrencyIntegrationTest,PurchaseAgreementIntegrationTest,BalanceConcurrencyIntegrationTest,PriceCalculatorServiceTest,PriceSelectionIntegrationTest test`
  → **117/117**; `full -Ppostgres-tests clean test` → **171/171**, zero
  failure/errori/salti. Java 21, PG 16 reale dedicato, 40 senza DB / 131 PostgreSQL;
  conti 04/prezzi 05/accordo 06/concorrenza 07, fixture e isolamento/sentinella passati.
- Review indipendenti Standards **0 violazioni/0 smell azionabili**, Spec **0**,
  sul solo diff 08 fissato (13 file). Nessun codice/test modificato dopo suite/review.
  [Evidenze, patch, hash, log/XML e conservazione](DriveHub/docs/evidence/r04-test-drive-atomic/verification.md).
  Baseline 352 file, 340 intatti, 10 aggiornamenti intenzionali inclusi piano/ticket,
  2 vecchie interfacce sostituite; tutte le evidenze e i ticket 01–07 intatti.
- Solo 127.0.0.1:55432, nessun DB applicativo preesistente; cluster arrestato.
  Nessun commit/staging; HEAD/indice invariati. Nessuna vista modificata quindi
  nessuna prova JavaFX/tastiera nuova. Warning JavaFX preesistente, /tmp temporanea.
- **R04 completata per 06–08**; R06/AC12 parziali per altri comportamenti, AC13
  trasversale. Non chiuso un rilievo intero aggiuntivo: totale resta **7/20**.
  Nessun conflitto prenotazioni 11, altra transizione o prestazione anticipati.
  Prossimo passo: nessun altro ticket avviato; proseguire solo su nuova richiesta.


### Ticket 09 — proposta di cessione e titolarità, 2 novembre 2026

- Solo ticket 09; 01–08 controllati chiusi. Baseline 401 file e istruzioni lette
  prima delle modifiche; lavoro locale e prove storiche preservati. Nessun commit,
  staging o accesso a Relazione_SWE.
- VIN noto: lock/rilettura nella transazione, stato SOLD, ultima vendita effettiva
  al proponente, nessuna richiesta aperta, identità modello/anno coerente. Tipo
  storico esplicito, tutte le factory/mapping aggiornate senza cambiare importi
  o segni. Base/modalità e storico conservati; demo con le stesse 40 operazioni.
- Vincoli DB VIN e UNIQUE request(vehicle), gare VIN noto e nuovo osservate su
  due connessioni distinte, nessuno sleep o mock. Trigger PostgreSQL verificano
  rollback dopo scrittura effettiva del veicolo e UPDATE saltata. Vincoli/controlli
  impediscono richieste parziali e sovrascritture del concorrente perdente.
- TDD dai servizi pubblici: RED concessionaria, assenza vendita, duplicati/gara,
  scrittura saltata/modello incongruente e messaggio generico; stessi confini
  GREEN, poi 31/31 casi e 142/142 mirati. Comando finale tramite launcher 09:
  `-Ppostgres-tests clean test` → **195/195**, zero failure/errori/saltati; 41
  senza DB, 154 PostgreSQL, inclusi conti 04, prezzi 05, accordo 06,
  elaborazioni 07, Observer/cancellazioni 08, fixture e isolamento/sentinella.
- Ripreso ambiente temporaneo 07 soltanto dopo verifica file/configurazione:
  JDK 21, Maven 3.9.16, PG16, ruolo dedicato e copia applicativa sentinella su
  127.0.0.1:55432. Primo avvio sandbox negato, escalation riuscita. Nessun DB
  applicativo preesistente contattato; cluster arrestato. `/tmp` temporanea.
- [Comandi esatti, log/XML, hash, baseline e limiti](DriveHub/docs/evidence/r05-sale-proposal/verification.md).
  171/171 del 08 rimane storico. Nessuna vista modificata; messaggi dal servizio
  al catch esistente; nessun nuovo controllo JavaFX/tastiera.
- **6/6 criteri runtime verificati, revisione indipendente Standards/Spec ancora
  in corso, ticket in-progress.** Nessuna accettazione/rifiuto, doppio accredito
  o segno contabile del 10, prenotazione 11, altra transizione o prestazione
  anticipati. Prossimo passo: completare questo stesso ticket, nessun successivo.


### Chiusura ticket 09 — 2 novembre 2026

- **6/6 criteri soddisfatti, State: closed**. La nota di avanzamento precedente
  resta storica. Review indipendenti Standards **0 violazioni/0 smell azionabili**,
  Spec **0 rilievi**, sul diff congelato rispetto alla baseline locale di 401
  file; lavoro 01–08 escluso. Nessun codice/test cambiato dopo suite e review.
- Finale **195/195**, mirati **142/142**, nuovi **24/24**, zero errori/failure/salti.
  Formula/base/centesimi05, totale06, conti04, elaborazioni07 e Observer08
  preservati; vincoli, concorrenza, rollback, fixture e sentinella verificati su
  PostgreSQL reale dedicato. Cluster arrestato dopo i controlli in sola lettura.
- [Prove, comandi, patch, hash, report indipendenti e limiti](DriveHub/docs/evidence/r05-sale-proposal/verification.md).
  387 file preesistenti intatti, 14 aggiornamenti intenzionali, nessuna
  eliminazione; ticket/evidenze01–08 e dati storici demo preservati. Nessun commit
  o staging, HEAD/indice invariati, Relazione_SWE esclusa da tutte le operazioni.
- Chiuso **AC02/#2**, totale **8/20**. R05 parziale per 10; AC03 per le
  approvazioni/AC10 restano aperti, AC13 trasversale. Nessuna vista modificata,
  nessuna prova JavaFX/tastiera nuova, nessun segno contabile o accettazione/rifiuto
  anticipato. Schema ricreabile D02; installazioni esistenti richiedono adeguamento
  e classificazione fattuale dello storico. `/tmp` temporanea da ricontrollare.
- Nessun blocco residuo del 09. Prossimo passo: ticket 10 soltanto in una nuova
  richiesta; nessun successivo avviato.


### 2 novembre 2026 — ticket 10 completato

Implementato soltanto accettazione/rifiuto cessione e registro. Tutti i criteri
verificati; [ticket](TRACKER_DRIVEHUB/revisioni/issues/10-esito-cessione-e-registro.md)
e [prove della versione](DriveHub/docs/evidence/r05-sale-outcome/verification.md).
Comandi del launcher `/tmp/drivehub-ticket10/maven.py` equivalenti a Maven JDK21:
RED/GREEN stato/importi/storico/validazioni, gare con PID e blocker osservati;
mirati estesi 206/206 e `mvn -Ppostgres-tests clean test` finale 259/259,
45 senza DB e 214 PostgreSQL, zero failure/errori/salti, isolamento/sentinella.
La prima suite completa 259/259 è intermedia: la finale ricompila anche l'ultimo
riuso CSS del registro, dopo GUI/Robot/tastiera riuscita e review indipendenti
Standards/Spec senza rilievi. Nessun codice/test/harness cambiato successivamente.

Ambiente temporaneo 07 ricontrollato (R00 assente); Java21/PG16, DB/ruoli dedicati,
file privato 0600, nessun segreto nelle evidenze. Lettura finale sentinella riuscita,
cluster e Xvfb arrestati. Preservati lavoro locale e prove storiche 01–09;
377/390 file identici, 13 modifiche intenzionali, nessuna eliminazione, HEAD/indice
invariati. Nessun commit o staging; Relazione_SWE sempre esclusa.

R05 e AC03/AC10 completati; rilievi integralmente chiusi 10/20, AC13 trasversale.
Limiti e prossimo passo: D02 richiede adeguamento schema/importi storici prima
uso applicativo; /tmp temporanea, screen reader non certificato. Prenotazioni11,
altre transizioni, account e prestazioni esclusi. Nessun blocco residuo del ticket10;
nessun successivo avviato, ticket11 soltanto su nuova richiesta.


### 2 novembre 2026 — chiusura ticket 11

Solo 11 implementato e verificato,01–10 preservati. Baseline locale259/259,
otto regressioni RED/GREEN identiche e PostgreSQL reale dedicato con PID/gate
osservati senza sleep. Lock veicolo/cliente/conti, periodi inclusivi nel DB,
limite tre, orari e gara noleggio/TD nei due ordini verificati. La prova a tre
con saldo acquisto ha riprodotto un deadlock; il rifiuto dello stato TD prima
del lock cliente lo elimina senza cambiare protocollo economico04 o Observer 08.

Launcher `/tmp/drivehub-ticket11/maven.py`: `final-targeted -Ppostgres-tests
-Dtest=BookingRulesTest,BookingConcurrencyIntegrationTest,TestDriveCancellationIntegrationTest,BalanceConcurrencyIntegrationTest,PriceCalculatorServiceTest,PriceSelectionIntegrationTest,PurchaseAgreementIntegrationTest,PurchaseConcurrencyIntegrationTest,SaleProposalIntegrationTest,SaleOutcomeIntegrationTest,SaleTypeTest,DemoSqlValidationTest,DatabaseIsolationIntegrationTest test`
→245/245; `final-full -Ppostgres-tests clean test` →297/297 (47 senza DB, 
250 PostgreSQL), zero failure/errori/salti. Suite 296/296 intermedia, storici01–10 invariati.
Review indipendenti Standards 0/Spec0 sul diff fissato14file; sorgenti e test
immutati dopo suite/review. [Evidenze](DriveHub/docs/evidence/r06-bookings/verification.md).

6/6 criteri, ticket 11 e AC05/#5 chiusi; totale 11/20. R06 resta parziale per 12,
AC13 trasversale. Schema ricreabile D02: predisporre btree_gist e risolvere
overlap preesistenti prima dell'uso; nessuna migrazione o reset applicativo.
Solo cluster sacrificabile 127.0.0.1:55432 e copia sentinella, riletta dopo suite;
cluster arrestato. Nessuna vista modificata/Xvfb avviato, nessuna nuova provaGUI.
Baseline576file:562 intatti,14 aggiornamenti intenzionali, nessuna eliminazione;
01–10 e prove storiche intatti, HEAD/indice invariati, nessun commit/staging.
Relazione_SWE esclusa. Nessun blocco residuo e nessun successivo avviato.

### 2 novembre 2026 — ticket 12 completato

Verificati prerequisiti 01–11 chiusi, istruzioni, glossario, ADR0001 e confini già approvati. Nuova baseline `mvn -Ppostgres-tests clean test` **297/297** prima delle modifiche. Quattro coppie RED/GREEN con sorgente del test identico: stati (8 failure→8/8), date inclusive (4→12/12), futuro (1→13/13), DELETE saltata (1→14/14). Estensione finale **33/33**, mirati estesi **278/278**, suite completa finale **330/330** (47 senza DB, 283 PostgreSQL), zero failure/errori/salti, inclusi isolamento/sentinella e regressioni 04–11.

Il comando rilegge lo stato dopo il lock veicolo11, consente solo i due versi SALE↔RENT e blocca ogni noleggio che comprende oggi. Futuri da domani cancellati e rimborsati100% per ID cliente crescente nella transazione; scritture saltate, conto mancante o errore annullano tutto. Gare nei due ordini con PID distinti, pg_blocking_pids, nessuno sleep e rollback dopo scritture effettive; conti04 e Observer08 conservati. Nessuna nuova penale. JavaFX/Robot/tastiera **UI CHECK SUCCESS**, cinque schermate ispezionate.

Review indipendenti Standards **0 violazioni/0 smell azionabili**, Spec **0**, sul solo diff rispetto alla fotografia iniziale. [Evidenze, comandi, hash, log/XML e limiti](DriveHub/docs/evidence/r06-destination/verification.md). Nessun codice/test/harness cambiato dopo prove finali/review; i documenti di chiusura non costituiscono nuove prove runtime. Conservazione: 617 file presenti, 612 identici, 5 aggiornamenti intenzionali, zero eliminazioni; HEAD/indice invariati, nessun commit/staging. Alla ripresa l’ambiente temporaneo era già assente e non risultano processi PostgreSQL/Xvfb residui. Relazione_SWE sempre esclusa.

**Ticket12 chiuso, 6/6 criteri; R06 completata per 08/11/12, AC07/#7 chiuso, totale12/20.** AC13 resta trasversale; nessun ticket successivo avviato. Ambiente /tmp da ricreare prima di nuove prove.


### 2 novembre 2026 — ticket 13 completato

Solo13,01–12 controllati chiusi. Letti AGENTS, piano, glossario, ADR0001,
testing ed evidenze12; ambiente /tmp precedente assente. Nuovo Java21 Linux,
PostgreSQL16 e Xvfb estratti da pacchetti Ubuntu ufficiali, senza installazioni
di sistema. Solo cluster sacrificabile127.0.0.1:55433, ruolo/DB di test non
amministrativo e copia applicativa sentinella. Nuova baseline **330/330**;
primo tentativo sandbox283 errori di connessione documentato separatamente,
non presentato come regressione o verifica riuscita.

Mappatura ruoli unica riusata, richieste incluse e attribuzione venditore
RESTRICT. Lock identità NO KEY UPDATE → conto → controllo e cancellazione
nella stessa transazione; rifiuti leggibili, DELETE verificata. Conservata
cancellabilità delle identità senza vincoli e distinzione dal conto dimostrativo.
Quattro coppie identiche RED/GREEN: ruoli3failure→6/6, richieste4→10/10,
storico/gare5→15/15 (deadlock PostgreSQL reale incluso), DELETE saltata1→16/16.
Estesi **60/60**, mirati **356/356**, suite finale **390/390** (47 senzaDB,
343 PostgreSQL), zero failure/errori/salti; isolamento/sentinella e regressioni
precedenti compresi. Gare nei due ordini con backend distinti e blocker osservati
senza sleep; rollback dopo scritture effettive di identità/conto, accredito e
acquisizione, nuovo veicolo e approvazione. Un'aspettativa errata della fixture
estesa e due errori dell'harness GUI registrati, senza attribuirli al prodotto.

JavaFX/Robot/tastiera **UI CHECK SUCCESS**, sei schermate finali ispezionate;
conferma/annullamento, password, richiesta cliente e sola vendita storica
venditore, successo senza vincoli e callback verificati. Review indipendenti
Standards **0 violazioni/0 smell azionabili**, Spec **0**, sul solo diff della
sessione rispetto alla fotografia locale846 file. Nessun codice/test/harness
modificato dopo prove finali e review; aggiornamenti documentali di chiusura
non sono nuove prove runtime.

Conservazione:846 file presenti,838 identici,8 aggiornamenti intenzionali,
zero eliminazioni. Ticket/evidenze01–12 e successivi intatti, HEAD/indice
invariati, nessun commit/staging. Sentinella finale riletta in sola lettura,
cluster e Xvfb arrestati; nessun DB applicativo preesistente contattato.
Relazione_SWE sempre esclusa. [Evidenze](DriveHub/docs/evidence/r07-identity/verification.md).

**Ticket13 chiuso,5/5 criteri, R07 e AC09/#9 completati;13/20 rilievi chiusi.**
AC13 resta trasversale. Nessun ticket successivo. Prima dell'uso su installazioni
esistenti aggiornare il solo vincolo FK secondo testing; eventuali attribuzioni
già azzerate non ricostruite. /tmp temporanea, nessuna certificazione screen
reader o benchmark prestazioni. Prossimo passo: nessun residuo del13;
proseguire solo su nuova richiesta.

### 2 novembre 2026 — ticket 14 completato
Solo14, prerequisito05 e01–13 verificati chiusi, AGENTS/piano/glossario/ADR0001 e testing/evidenze13 letti prima degli interventi. Nuova baseline390/390 e fotografia1089file. Preparazione collettiva di modelli/sconti/prezzi fuori FX, righe senza query nei renderer di cliente/manager/venditore; prezzo e tariffa dal calcolatore esistente, nessuna cache o riscrittura. Task correnti e callback JavaFX, stato/progresso/riprova; modifica prezzi/sconti aggiorna veicoli. Tre coppie RED/GREEN identiche e caricamenti osservati, GUI finale/Robot/tastiera riuscite, sette schermate ispezionate. Mirati25/25 e148/148, finale394/394 (47 senzaDB/347 PostgreSQL), zero failure/errori/salti, isolamento/sentinella e precedenti compresi. Review indipendenti Standards0/Spec0 sul diff congelato14file, nessun codice/test/harness successivo; [prove](DriveHub/docs/evidence/r08-tables/verification.md). Ambiente13 ricontrollato, Java21/PG16, solo127.0.0.1:55433 e copia sentinella; Xvfb94 astratto senzaTCP. Sentinella finale in sola lettura e servizi arrestati.1089file presenti,1082 identici,7 modifiche intenzionali,zero eliminazioni; HEAD/indice invariati, nessun commit/staging,01–13 e successivi preservati, Relazione_SWE esclusa. **5/5 criteri, ticket14/R08/AC16/#16 chiusi,14/20 rilievi**; AC13 trasversale. /tmp temporanea, cancellazione JDBC non immediata, titolo consigliato abbreviato a1280px e nessuna certificazione screen reader/benchmark; nessun ticket successivo avviato.

### 2 novembre 2026 — ticket 15 completato
Solo15,01–14 controllati chiusi; AGENTS/piano/glossario/ADR0001 e testing/evidenze14
letti prima degli interventi. Nuova baseline394/394, distinta dallo storico14,
e fotografia1276file. Ricerca completa FXML/sessione, anche nascosti/ignorati:
nessuna risorsa/loader o chiamante dei membri AppContext rimossi. Tolti soltanto
javafx-fxml,currentUser,tre metodi e importUser; commento POM coerente,20righe
nette in meno. Login/logout effettivi, servizi,DAO,schema,demo e test invariati;
nessun test specchio delle rimozioni e nessun refactor.
Java21.0.12.1/Maven3.9.16/PG16.15 ricontrollati nei file temporanei ancora presenti;
solo127.0.0.1:55433 con ruolo/DB dedicati e copia sentinella. Compilazione65sorgenti
target21 riuscita, App.start su Xvfb93 APP STARTUP SUCCESS e screenshot/Tab/tema;
harness ciclo14 UI CHECK SUCCESS. Finale nuova394/394 (47senzaDB/347PostgreSQL),
zero failure/errori/salti, isolamento/sentinella e regressioni01–14 compresi.
Input runtime identici fra compile,avvio,GUI e finale; nessun codice/test/harness
cambiato dopo prove/review. Review indipendenti Standards0residui/Spec0 sul solo
diff congelato7file; ordine commenti tracker corretto e ricontrollato. Chiusura
documentale separata. [Prove,comandi,hash,patch,review e limiti](DriveHub/docs/evidence/r10-cleanup/verification.md).
1276file iniziali presenti,1271identici,5aggiornamenti intenzionali,zeroeliminazioni;
01–14 e successivi intatti, HEAD/indice invariati, nessun commit/staging e relazione
sempre esclusa. Sentinella finale READ ONLY, PostgreSQL e Xvfb arrestati,
listener55433/X93 assenti. Ticket15/R10/AC20/#20 chiusi,4/4criteri e15/20rilievi;
AC13 trasversale. /tmp temporanea, packaging/goal javafx:run e altri OS/display
non verificati; nessuna certificazione screen reader o benchmark. Nessun blocco
residuo15 o successivo avviato; proseguire solo su nuova richiesta.


### 3 novembre 2026 — ticket16 completato

Solo16,01–15 chiusi verificati con hash; letti AGENTS/piano/glossario/ADR0001,
testing/evidenze15. Installazione/configurazione e teoria consolidate in README,
docs/installation.md, docs/architecture.md e testing, con esempi/compromessi reali.
Nessun refactor, test artificiale o modifica ai diagrammi17; codice/POM/test/fixture
preesistenti identici. Fotografia1422file e copia della versione locale corrente,
non solo HEAD, inclusi untracked/modificati; sola configurazione DB privata diversa.
Ambiente temporaneo assente e ricreato: Java21.0.12.1/Maven3.9.16/PG16.15/Xvfb92,
cluster nuovo127.0.0.1:55434 con ruoli/DB dedicati e sentinella distinta.
Schema vuoto/demo facoltativa verificati separatamente, build package65sorgenti
target21,47/47senzaDB, tre login demo via servizi, App.start/Robot e due avvii
Maven reali con finestre/PID distinti (processi interrotti dopo osservazione).
Finale nuova394/394,47senzaDB/347PostgreSQL, zero failure/errori/salti,
isolamento/sentinella; risultato15 storico. Hash applicativi13tabelle7sequenze
identici prima/dopo, letture READ ONLY. Review indipendenti sul solo diff
Standards0violazioni/0smell azionabili e Spec0rilievi. Chiusura documentale
separata dalle prove runtime; input invariati build→suite. Servizi arrestati,
listener/PID assenti;1422file conservati,1418identici+4aggiornamenti documentali,
zeroeliminazioni. HEAD/indice invariati, nessun commit/staging, relazione esclusa.
**6/6criteri,16/AC15/#15/AC18/#18 chiusi,17/20rilievi.** R09 parziale per17,
AC13 trasversale; nessun altro ticket avviato. Limiti Linux/WSL/Xvfb, nessuna
migrazione completa/certificazione screen reader/installer/benchmark o prova
di tutti i flussi GUI. [Prove16](DriveHub/docs/evidence/r09-instructions/verification.md).

### 3 novembre 2026 — ticket17 completato

Solo17/AC14,01–16 chiusi verificati.18diagrammi correnti con sorgenti/render e
riscontri a codice/test;37artefatti visivi e vecchi manifest conservati come storici.
Precisazioni teoriche16 mantenute; nessun codice/POM/test/schema/demo modificato.
Baseline1507file inclusi ignorati/modificati/nontracciati, diff della sola sessione.
Java21.0.12.1/Maven3.9.16/PG16.15 ricontrollati; nuovo cluster55435 e display91,
ruoli/DB dedicati e sentinella. Mirati nuovi79/79, UI CHECK SUCCESS,
APP STARTUP SUCCESS, finale nuova394/394 (47senzaDB/347PostgreSQL), zero
failure/errori/salti.394/394del16 storico; tentativi fallito/interrotto distinti.
Render finali SVG/PNG exit0 e ispezione. Standards0violazioni/0smell, Spec1P2
sui ritorni dei dialoghi corretto e follow-up indipendenti0residui; nessun input
runtime cambiato dopo prove. Sentinella READ ONLY/hash13tabelle7sequenze invariati,
servizi arrestati.1507file presenti,1502identici,5aggiornamenti intenzionali,
zeroeliminazioni; HEAD/indice invariati. Nessun commit/staging, relazione esclusa.
**17chiuso,5/5criteri; AC14/#14 e R09 completati,18/20rilievi chiusi.**
[Evidenze17](DriveHub/docs/evidence/r09-diagrams/verification.md). Limiti GUI/OS/display,
stampa e temporanei espliciti. Nessun residuo17 o anticipo18/R11; prossimo passo18
soltanto su nuova richiesta.

### 3 novembre2026 — ticket18, verifica integrata e chiusura

Letti tutti i contesti richiesti,01–17 chiusi verificati. Baseline1796file inclusi
326ignorati/target, non solo HEAD; relazione esclusa. Matrice20criteri con ticket,
comportamenti P/A/E e metodi effettivi; coerenza di istruzioni/diagrammi/evidenze
riscontrata sul codice corrente,18renderSVG nuovi identici ai consegnati.
Mirati363/363 e sette harnessJavaFX riusciti; preservati tentativo mirato con4timeout,
primo fermo modale cessione e cast obsoleto dell'harness12. Adattata soltanto la
copia18 di quel cast a VehicleRow, più percorsi output/diagnostica, assert invariati.
Nessuna regressione produttiva dimostrata: nessun refactor o nuovo test artificiale.

All'interruzione /tmp scomparsa; recuperata fotografia iniziale1796/1796SHA256,
ricreati strumenti e cluster dedicato, nuova sentinella. Finale394/394, zero
failure/errori/salti,47senzaDB/347PostgreSQL, input produttivi invariati fra fasi;
sentinella fase2 READ ONLY13tabelle/7sequenze identiche, cluster arrestato.
Il confronto esterno finale della sentinella fase1 manca e resta esplicito;
non si dichiara un arresto controllato dei suoi processi scomparsi.

Review indipendenti sul solo delta locale, conservazione1796file/zeroeliminazioni,
HEAD/indice invariati.6/6criteri18, R11 e AC12/AC13 chiusi:20/20rilievi verificati
nei confini e limiti dichiarati. Nessuno staging/commit/push/pubblicazione.
[Rapporto18](DriveHub/docs/evidence/r11-integrated/verification.md) e
[matrice](DriveHub/docs/evidence/r11-integrated/acceptance-matrix.md).
Prossimo passo: nessun residuo funzionale dimostrato18; prove su altriOS/display,
screenreader, installer o migrazioni complete restano fuori perimetro.
