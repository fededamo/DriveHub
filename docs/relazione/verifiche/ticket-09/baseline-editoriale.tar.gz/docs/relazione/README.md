# Relazione DriveHub

**16 novembre 2026 — riallineamento pianificato.** Gli autori chiedono maggiore
fedeltà a struttura interna e contenuti di `Relazione_SWE`. Sono pronti la
[matrice completa](allineamento.md), l'[indice dettagliato](indice.md) e la
[specifica aggiornata](tracker/spec.md), con ticket 09–13. La pianificazione
copre tutte le 102 voci e i 23 frammenti originali; la riscrittura dei LaTeX
non è ancora iniziata. [Controlli della pianificazione](verifiche/allineamento-2026-11-16/verifica.md).
Il PDF e gli ZIP collegati sotto restano la prima stesura, da riallineare;
le verifiche storiche non attestano la nuova struttura proposta.

Precisati i [vincoli sui diagrammi](allineamento.md#diagrammi-vincoli-operativi):
rifare/riadattare tutte le tavole originali con la skill `drawio:drawio`,
partendo dai disegni degli autori. La richiesta riguarda tutti i contenuti
della vecchia relazione, riadattati esattamente all'implementazione corrente.

Sorgenti della nuova relazione di Ingegneria del Software. **Capitoli 1–5 e
appendici A–C completi e proposti agli autori per revisione**, non approvati.
Il capitolo 1 è conservato dal ticket 01. Il PDF è completo nei contenuti
concordati; la revisione degli autori precede la consegna al docente.

Il ticket 08 è concluso tecnicamente il 15 novembre 2026: documento unitario
verificato e pacchetto pronto, con [review Standards e Spec](verifiche/ticket-08/revisione.md)
e nessun rilievo aperto. Restano cinque messaggi TeX
[valutati sulle pagine interessate](verifiche/ticket-08/valutazione-messaggi-tex.md).
Completamento tecnico e review assistite restano distinti dalla revisione
degli autori ancora da svolgere; nessun invio o pubblicazione.

- [Pacchetto sorgenti autonomo aggiornato](verifiche/tavole-autori/sorgenti-relazione.zip) e [istruzioni incluse](LEGGIMI-consegna.md)
- [Verifiche finali 08](verifiche/ticket-08/README.md), con matrice finale, osservazione di tutte le pagine e prova di compilazione dello ZIP estratto

- [PDF compilato](relazione-drivehub.pdf)

15 novembre 2026: su richiesta degli autori, il PDF include anche le copie
corrette delle loro tre tavole, mantenendone stile, notazione e struttura:
[casi d'uso](diagrammi/casi-uso-autori.drawio),
[navigazione](diagrammi/navigazione-autori.drawio) ed
[ER con legenda](diagrammi/database-er-autori.drawio).
Sono fogli A3 d'insieme, affiancati ai dettagli A4 già presenti.
[Correzioni e verifiche della nuova versione](verifiche/tavole-autori/README.md).
Le review e le impronte del ticket 08 attestano il pacchetto precedente;
non sono presentate come una nuova review delle tavole integrate.
- [Capitolo 5 — Uso dell'AI](capitoli/5_uso_ai.tex) e [estratto per gli autori](verifiche/ticket-07/capitolo-5-per-revisione.pdf)
- [Verifiche ticket 07](verifiche/ticket-07/README.md): dichiarazioni, matrice affermazioni→fonti, baseline, delta dei non tracciati, compilazione e controllo visivo
- [Revisioni indipendenti Standards e Spec del ticket 07](verifiche/ticket-07/revisione.md)
- [Capitolo 4 — Testing](capitoli/4_testing.tex), [appendice C](appendici/c_verifiche.tex) e [estratto 4/C per gli autori](verifiche/ticket-06/ticket-06-per-revisione.pdf)
- [Verifiche ticket 06](verifiche/ticket-06/README.md): fonti, matrice, risultati storici, conservazione, PDF e revisioni indipendenti
- [Capitolo 3 — Implementazione](capitoli/3_implementazione.tex) e [PDF per gli autori](verifiche/ticket-05/capitolo-3-per-revisione.pdf)
- [Verifiche ticket 05](verifiche/ticket-05/README.md): fonti e frammenti esatti, compilazione, conservazione e controllo visivo
- [Revisioni indipendenti Standards e Spec del ticket 05](verifiche/ticket-05/revisione.md)
- [Sorgente principale](main.tex)
- [Capitolo 1](capitoli/1_introduzione.tex)
- [Sezioni 2.1–2.4](capitoli/2_funzioni.tex) e [appendice A](appendici/a_casi_uso.tex)
- [Sezioni 2.5–2.6](capitoli/2_architettura.tex) e [appendice B](appendici/b_classi.tex)
- [Sezione 2.7](capitoli/2_sequenze.tex) e [sezione 2.8](capitoli/2_database.tex)
- [Capitolo 2 per la revisione degli autori](verifiche/ticket-04/capitolo-2-per-revisione.pdf), con [estratto delle nuove 2.7–2.8](verifiche/ticket-04/ticket-04-per-revisione.pdf)
- [Verifiche ticket 04](verifiche/ticket-04/README.md): sequenze, ER e modello relazionale, riscontro statico, compilazione e controllo visivo
- [Revisioni indipendenti Standards e Spec del ticket 04](verifiche/ticket-04/revisione.md)
- [Estratto del ticket 03 per la revisione degli autori](verifiche/ticket-03/ticket-03-per-revisione.pdf)
- [Verifiche del ticket 03](verifiche/ticket-03/README.md), con matrice package–tavole–sorgenti e revisioni indipendenti
- [Revisioni Standards e Spec del ticket 03](verifiche/ticket-03/revisione.md): concluse e conformi, nessun rilievo aperto
- [Estratto del ticket 02 per revisione](verifiche/ticket-02/ticket-02-per-revisione.pdf)
- [Diagrammi draw.io ed esportazioni](diagrammi/README.md), [screenshot attuali](screenshot/)
- [Verifiche del ticket 02](verifiche/ticket-02/README.md)
- [Revisioni indipendenti concluse dei ticket 01 e 02](verifiche/ticket-02/revisione.md): Standards e Spec conformi, nessun rilievo aperto.
- [Verifiche del ticket 01](verifiche/ticket-01/README.md)
- [Indice dettagliato del riallineamento](indice.md), [matrice](allineamento.md), [piano](piano.md) e [specifica aggiornata](tracker/spec.md)

## Compilazione

Per il pacchetto finale è verificato **XeLaTeX, TeX Live 2025/Debian**:
seguire i tre passaggi nelle [istruzioni di consegna](LEGGIMI-consegna.md).
La compilazione non richiede il repository applicativo né contenuti editoriali
in `/tmp`. La prova nell'ambiente temporaneo, i prerequisiti e i limiti sono
registrati nelle verifiche 08; motore e risorse LaTeX restano prerequisiti esterni.

Procedura Tectonic usata nei ticket 01–07, non rieseguita nel ticket 08:

Eseguire dalla directory `docs/relazione`. Con **Tectonic 0.17.0**, che gestisce
automaticamente i passaggi necessari per indice e riferimenti:

```bash
mkdir -p build
tectonic --untrusted --keep-intermediates --keep-logs --outdir build main.tex
cp build/main.pdf relazione-drivehub.pdf
```

La prima compilazione richiede Internet per scaricare le risorse LaTeX.
Il ticket 07 ricontrolla Tectonic 0.17.0 GNU e PyMuPDF già disponibili
nell'ambiente temporaneo del ticket 06; versioni, impronte e
comandi effettivi sono nelle [verifiche](verifiche/ticket-07/README.md).
Il pacchetto LaTeX `listings`, usato nei capitoli 3–4, è stato
recuperato nella cache. I frammenti sono incorporati nel LaTeX e
confrontati con gli intervalli dei Java correnti: la compilazione non
richiede file di contenuto in `/tmp`. Gli eseguibili e le cache temporanee
non sono prerequisiti garantiti su un altro PC: occorre fornire Tectonic
oppure un ambiente LaTeX compatibile.
Il PDF distribuito non richiede tali strumenti per
essere aperto.

I sorgenti usano pacchetti LaTeX comuni (`babel` con italiano, `geometry`,
`graphicx`, `enumitem`, `xcolor`, `listings`, `longtable`, `array`, `hyperref`) e mantengono le convenzioni di
`Relazione_SWE/main.tex`: classe `report`, A4, corpo 12 pt, margini di 2,5 cm,
frontespizio, indice in numeri romani e capitoli in numeri arabi. Il ramo per
`pdfminorversion` è condizionale per consentire anche il motore di Tectonic.
Il ticket 08 verifica anche la distribuzione XeLaTeX sopra indicata;
identità binaria fra motori e funzionamento Windows/macOS non sono garantiti.

## Materiali e perimetro

`capitoli/` e `appendici/` contengono il testo; `main.tex` ne fissa l'ordine.
L'indice include tutte le sezioni concordate e le sottosezioni strutturali
di progettazione. I contenuti sono stati riscontrati durante la rispettiva
stesura, senza riproporre come correnti classi o meccanismi rimossi.

`verifiche/ticket-01/drawio/` contiene esclusivamente la prova tecnica di
esportazione: non è una figura della relazione e non è inclusa da LaTeX.
I diagrammi del ticket 02 sono in `diagrammi/`, con sorgenti modificabili
ed esportazioni PDF; le schermate sono acquisizioni della versione corrente
con dati demo su PostgreSQL temporaneo. Le verifiche del ticket 01 sono
conservate intatte e descrivono il risultato storico di quel ticket: non
vanno rieseguite contro il documento avanzato per pretendere che l'appendice A
sia ancora provvisoria. Il controllo aggiornato è in `verifiche/ticket-02/`.
Il ticket 03 completa 2.5–2.6 e B con tredici nuove tavole draw.io
(package diagram e dodici tavole delle classi per undici package).
Le verifiche 01 e 02, inclusi i rispettivi manifest e PDF estratti, restano
fotografie intatte delle stesure precedenti.
Il ticket 04 completa 2.7–2.8 con otto tavole di sequenza coordinate,
due viste ER e tre viste relazionali delle tredici tabelle applicative.
Anche le verifiche e i manifest del ticket 03 rimangono intatti;
il controllo aggiornato è in `verifiche/ticket-04/`. Non vanno applicate
al PDF attuale le vecchie asserzioni sulle sezioni allora provvisorie.
La relazione precedente, il software, lo schema, i
dati e le evidenze storiche restano separati da questa stesura.

Gli intermedi di compilazione sono ignorati da Git; il PDF e i verbali di
verifica sono conservati. Questa attività non esegue test applicativi e non
crea commit.

Il ticket 05 completa il capitolo 3 e lo propone alla revisione degli autori.
Riusati i diagrammi esistenti, senza nuove tavole. Anche evidenze e manifest
01–04 restano intatti: i loro stati provvisori fotografano la rispettiva
stesura e non vanno imposti al PDF aggiornato. Il capitolo 5
restava allora provvisorio; nessuna approvazione degli autori è presunta.

Il ticket 06 completa il capitolo 4 e l’appendice C e li propone agli autori.
I risultati applicativi citati restano storici; sono nuove soltanto le verifiche
documentali, la compilazione e l’ispezione del PDF. Nessun software, test, SQL,
dato o manifest 01–05 modificato; in capitolo 3 aggiornata la sola frase di stato.
Il capitolo 5 restava allora provvisorio e nessuna approvazione degli autori è presunta.

Il ticket 07 completa il capitolo 5 distinguendo dichiarazioni degli autori,
riscontri documentati e lacune sull'uso dell'AI. Riusati i diagrammi esistenti;
nessuna nuova tavola. Capitoli 1–4 e appendici A–C conservati, con sola rimozione
delle due frasi di stato sul capitolo 5 provvisorio in 3–4. Evidenze e manifest
01–06 intatti, compresi i loro stati storici. Le nuove verifiche riguardano
documentazione e PDF; nessuna nuova prova applicativa. Il capitolo è proposto
agli autori, senza attribuirne l'approvazione.
