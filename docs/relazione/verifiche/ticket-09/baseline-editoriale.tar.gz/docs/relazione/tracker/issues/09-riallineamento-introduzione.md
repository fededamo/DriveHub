# 09 — Riallineamento dell'introduzione

Status: ready-for-agent

Blocked by: None.

## What to build

Un capitolo introduttivo che mantenga descrizione, stack e semplificazioni
dell'originale, con contenuto attuale e profondità proporzionata. Riusare il
testo valido della prima stesura: questo capitolo richiede soprattutto una
verifica di corrispondenza, non una riscrittura senza motivo.

Riferimenti: [specifica](../spec.md), [matrice, capitolo 1](../../allineamento.md#capitolo-1)
e [indice](../../indice.md#1-introduzione).

## Acceptance criteria

- [ ] Tutte le voci 1–1.3 e i loro argomenti hanno un riscontro esplicito:
  contesto, tre ruoli, catalogo comune, tecnologie e limiti del prototipo.
- [ ] Le descrizioni di UI, PostgreSQL, avvio e registrazione corrispondono
  alle fonti attuali; nessun ripristino di H2, FXML o registrazione staff.
- [ ] Conservati punto di vista della concessionaria e contenuti validi;
  eventuali differenze dall'originale sono motivate per la relativa voce.
- [ ] Conservata prima delle modifiche una baseline del materiale coinvolto,
  compresi i file non tracciati; vecchia relazione e verifiche restano intatte.
- [ ] Verificati sorgenti, rinvii e compilazione reale; controllate visivamente
  le pagine del capitolo e registrati esiti, data e limiti. Anche se il testo
  non richiede cambiamenti, il confronto deve dimostrarlo.
- [ ] Aggiornati i soli stati documentali pertinenti e proposto il capitolo
  agli autori, senza attribuire approvazione umana o nuove prove applicative.

## Comments

16 novembre 2026: ticket della nuova fase autorizzata dagli autori. Primo
nell'ordine di lavorazione; il completamento tecnico non blocca gli altri
capitoli per una dipendenza inesistente. Nessun commit o invio previsto.
