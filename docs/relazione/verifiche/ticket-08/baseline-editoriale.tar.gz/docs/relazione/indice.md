# Indice commentato della nuova relazione

L'indice mantiene i primi quattro capitoli, le sezioni e l'ordine
effettivamente inclusi da `Relazione_SWE/main.tex`, aggiungendo un capitolo 5
dedicato all'uso dell'AI. Si riscrivono i contenuti per la versione attuale.

I titoli delle sezioni restano quelli esistenti. Le sottosezioni che citano
componenti, test o meccanismi rimossi saranno aggiornate soltanto quanto serve
per descrivere correttamente il sistema attuale.

## Frontespizio e indice

Sono confermati Federico D'Amodio e Matteo Orlandi, Ingegneria del Software,
prof. Enrico Vicario, A.A. 2025/2026.

## 1. Introduzione

- **1.1 Descrizione.** Contesto della concessionaria, obiettivi e ruoli.
- **1.2 Stack tecnologico.** Tecnologie e strumenti realmente utilizzati:
  Java, JavaFX, Maven, JDBC e PostgreSQL.
- **1.3 Semplificazioni adottate.** Perimetro dell'applicazione e limiti effettivi,
  senza riproporre H2 o bootstrap non più presenti.

## 2. Analisi dei requisiti e progettazione

- **2.1 Diagramma dei casi d'uso.** Obiettivi dei tre ruoli e funzionalità di
  supporto, distinguendo i livelli di astrazione.
- **2.2 Template dei casi principali.** Sintesi dei casi nel testo e rimandi alle
  schede complete in appendice A, mantenendo coerenti identificativi e titoli.
- **2.3 Mockups.** Si mantiene il titolo e l'organizzazione per autenticazione,
  cliente, venditore e manager; le figure vengono aggiornate con screenshot
  dell'interfaccia reale, consentiti in sostituzione dei mockup dalla consegna.
- **2.4 Page Navigation Diagram.** Percorsi, dashboard, tab e dialoghi per ruolo.
- **2.5 Package Diagram.** Responsabilità e dipendenze dell'architettura attuale.
- **2.6 Class Diagram.** Si conserva l'organizzazione Domain Model, Business
  Layer, DAO e Presentation Layer, coprendo tutti gli undici package attuali.
  Le tavole più estese sono raccolte in appendice B.
- **2.7 Sequence Diagram.** Si conservano i tre flussi già presenti: acquisto del
  cliente, noleggio e acquisizione del veicolo ceduto dal cliente. Nella
  spiegazione si usa sempre la terminologia concordata della concessionaria.
- **2.8 Database.** Si conservano Schema ER, Modello relazionale e Utenti,
  vincoli e semplificazioni, aggiornati allo schema PostgreSQL corrente.

## 3. Implementazione

- **3.1 Domain Model.** Entità, invarianti, gerarchie e riferimenti per ID.
- **3.2 Business Layer.** Responsabilità dei servizi, transazioni, flussi
  applicativi, prezzi e sconti, identità, conto e notifiche Observer.
- **3.3 Presentation Layer.** Viste JavaFX, navigazione, dialoghi e caricamenti
  asincroni, correggendo i riferimenti ai componenti precedenti.
- **3.4 Persistenza: livello DAO e mapping oggetti/tabelle.** Contratti e
  implementazioni PostgreSQL, mapping, vincoli e connessione transazionale.
- **3.5 Idiomi e Design Pattern.** Meccanismi effettivamente adottati,
  motivazioni e limiti. Nessuna attribuzione di pattern basata soltanto sui nomi.

Ogni sezione impiega frammenti significativi e commentati. Si mantiene l'ordine
esistente delle responsabilità; le descrizioni dei vecchi componenti vengono
sostituite con quelle dei componenti attuali.

## 4. Testing

- **4.1 Strategia di verifica.** Obiettivi, livelli, tecnologie e strumenti.
- **4.2 Livello 1: Business Logic.** Invarianti, regole e flussi principali e
  alternativi, citando le classi di test correnti.
- **4.3 Livello 2: Persistence Layer (DAO).** Integrazione PostgreSQL, mapping,
  vincoli e rollback.
- **4.4 Verifiche funzionali e della presentazione.** Scenari utente, controlli
  JavaFX, caricamenti ed errori significativi.
- **4.5 Esecuzione della suite e portata dei risultati.** Ambiente, comandi,
  risultati attribuiti alla versione verificata e limiti. I risultati storici
  non diventano nuove esecuzioni.

## 5. Uso dell'AI

- **5.1 Progettazione e sviluppo iniziale manuali.** Descrivere la progettazione,
  la struttura iniziale e le prime classi realizzate manualmente, secondo la
  dichiarazione degli autori.
- **5.2 Revisione assistita da Codex.** Ricostruire attività, parti interessate
  e modalità di lavoro attraverso piano, ticket, audit ed evidenze disponibili.
- **5.3 Verifica e controllo umano.** Distinguere contributi dell'AI, decisioni
  degli autori e controlli documentati, mantenendo i risultati attribuiti alle
  rispettive versioni del software.
- **5.4 Documentazione, diagrammi e limiti.** Descrivere anche la riscrittura
  della relazione e la produzione dei diagrammi, chiarendo i limiti delle
  tracce disponibili senza inventare prompt, modelli o percentuali di codice.

## Appendici

Si conserva la scelta già concordata di spostare i dettagli estesi in appendice,
senza cambiare il percorso dei capitoli:

- **A — Schede complete dei casi d'uso.** Attori, livello, condizioni, flusso
  principale e alternative numerate.
- **B — Tavole delle classi.** Viste che completano la copertura dei package,
  con osservazioni per interpretarle.
- **C — Matrice delle verifiche.** Requisiti, flussi, test, risultati e limiti.

Le istruzioni di esecuzione pertinenti restano in 4.5, con riferimenti coerenti
a `docs/installation.md` e `docs/testing.md`.

## Elenco proposto dei diagrammi

Tutti i nuovi diagrammi saranno realizzati con draw.io. I sorgenti `.drawio`
resteranno in `docs/relazione/diagrammi/`, insieme alle esportazioni impiegate.
Le tavole saranno progettate per spiegare il sistema e riscontrate sul codice;
non saranno un'esportazione automatica delle classi e dei relativi membri.

| Vista | Copertura |
| --- | --- |
| Package e dipendenze | Architettura, responsabilità e direzione delle dipendenze. |
| Casi d'uso del cliente | Catalogo, vendita al cliente, noleggio, test drive, cessione e consultazione delle proprie operazioni. |
| Casi d'uso del venditore | Gestione degli esiti delle richieste e destinazione dei veicoli. |
| Casi d'uso del manager | Catalogo, prezzi, sconti e consultazione del registro economico. |
| Casi d'uso di supporto | Registrazione, accesso, identità e conto dimostrativo; livelli dichiarati nei template. |
| Classi: avvio e composizione | Package `it.unifi.drivehub`. |
| Classi: identità | Package `domain.user`. |
| Classi: catalogo | Package `domain.vehicle`. |
| Classi: sconti | Package `domain.discount`. |
| Classi: operazioni | Package `domain.operation`. |
| Classi: servizi | Package `service`. |
| Classi: eventi | Package `event`. |
| Classi: contratti DAO e transazioni | Package `dao`. |
| Classi: persistenza PostgreSQL | Package `dao.postgres`. |
| Classi: presentazione | Package `presentation.view`. |
| Classi: credenziali | Package `security`. |
| ER | Entità, cardinalità e vincoli pertinenti allo schema corrente. |
| Navigazione del cliente | Accesso alla dashboard, tab e dialoghi del cliente. |
| Navigazione del venditore | Accesso alla dashboard, tab e azioni del venditore. |
| Navigazione del manager | Accesso alla dashboard, tab e azioni del manager. |

Le undici viste delle classi potranno essere affiancate nell'impaginazione quando
restano leggibili. I package intermedi senza tipi propri non richiedono una
tavola delle classi vuota.

La sezione Sequence Diagram conserva i tre flussi già presenti nella relazione,
aggiornati all'implementazione corrente. Non sono obbligatori nella consegna:

- vendita al cliente, dall'acconto all'esito e al saldo;
- acquisto dal cliente, dalla proposta all'esito e alla registrazione;
- noleggio, compresi i conflitti e le cancellazioni collegate dei test drive.

Queste sequenze devono chiarire collaborazioni e transazioni. Eventuali altre
viste saranno aggiunte soltanto per risolvere un'esigenza esplicativa concreta.
