# 13 — Integrazione e verifica del riallineamento

Status: ready-for-agent

Blocked by: 09 — Riallineamento dell'introduzione; 10 — Riallineamento di
requisiti e progettazione; 11 — Riallineamento dell'implementazione;
12 — Riallineamento del testing.

## What to build

Una relazione completa e un pacchetto autonomo che seguano il percorso
originale e descrivano il progetto corrente. Integrare i quattro capitoli
riallineati con il capitolo sull'AI e le appendici, poi verificare contenuti,
rinvii, compilazione e leggibilità del PDF completo.

Riferimenti: [specifica](../spec.md), [matrice](../../allineamento.md)
e [indice dettagliato](../../indice.md).

## Acceptance criteria

- [ ] Ticket 09–12 conclusi con verifiche documentate; nessuna approvazione
  umana dedotta dalla loro chiusura tecnica.
- [ ] Tutte le 102 voci originali e i 23 frammenti hanno trattamento
  verificato; controllate anche diciotto schermate, undici diagrammi, sei
  template e due tabelle argomentative originali. Ogni scostamento residuo
  è motivato; la sola corrispondenza dei titoli non vale come completezza.
- [ ] Capitolo 5 conservato, con riferimenti coerenti e ricostruzione anche
  del riallineamento; nessuna attribuzione o metrica AI inventata.
- [ ] Tutti gli undici diagrammi originali rifatti/riadattati con la skill
  `drawio:drawio`, secondo i [vincoli operativi](../../allineamento.md#diagrammi-vincoli-operativi).
  Verificate le basi degli autori, lo stile riconoscibile, i sorgenti nativi,
  le esportazioni e la corrispondenza al codice attuale per ciascuna tavola;
  il semplice riuso delle viste della prima stesura non vale come completamento.
- [ ] Appendice A contiene le schede aggiuntive senza duplicare le sei
  principali; B conserva tutti i package; C conserva tracciabilità e limiti.
  Rimandi, etichette, didascalie e indice riflettono la collocazione definitiva.
- [ ] Nessuna funzionalità o componente rimossi presentati come attuali;
  limiti reali, risultati storici e nuove verifiche documentali distinti.
- [ ] Compilazione reale e osservazione di tutte le pagine del nuovo PDF,
  comprese le A3; valutazione esplicita dei messaggi TeX residui e assenza di
  rinvii irrisolti o stati provvisori fuorvianti.
- [ ] ZIP autonomo aggiornato e ricompilato dopo estrazione; istruzioni,
  README, piano e stato della matrice aggiornati, con impronte del PDF/ZIP
  effettivamente verificati e baseline dei materiali precedenti conservata.
- [ ] Revisione finale separata di conformità alle istruzioni e aderenza
  alla specifica; eventuali rilievi risolti o dichiarati, senza usare i
  verbali della prima stesura come review della nuova versione.
- [ ] PDF e sorgenti proposti agli autori, con limiti residui espliciti;
  nessun invio, pubblicazione, commit o modifica al software/schema/dati.

## Comments

16 novembre 2026: il ticket dipende da tutti i capitoli perché verifica il
documento integrato. Le compilazioni e i pacchetti dei ticket 01–08 e delle
tavole degli autori restano fotografie storiche e non soddisfano questi
criteri per la versione riallineata.
