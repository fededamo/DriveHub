# 12 — Riallineamento del testing

Status: ready-for-agent

Blocked by: None.

## What to build

Un capitolo di testing che mantenga le cinque sezioni e gli argomenti
specifici dell'originale: tecnologie, invarianti, autenticazione, prezzi e
sicurezza, vendite, noleggio/conto, transazioni/Observer, mapping e schema/demo.
Descrivere le prove attuali attraverso preparazione, azione, oracolo,
estratto significativo e limite, mantenendo corretta la classificazione.

Riferimenti: [specifica](../spec.md), [matrice, capitolo 4](../../allineamento.md#capitolo-4),
[censimento dei frammenti](../../allineamento.md#frammenti-ed-esempi-da-conservare-per-funzione)
e [indice](../../indice.md#4-testing).

## Acceptance criteria

- [ ] Tutte le voci 4–4.5 hanno un argomento identificabile e profondità
  analoga all'originale, conservando i contenuti validi della prima stesura.
- [ ] Ripristinata la sottosezione Tecnologie e strumenti, con dipendenze e
  profili reali: niente H2, Mockito, JaCoCo o ciclo Maven inesistenti.
- [ ] Sei sottosezioni del Business Logic coprono gli argomenti originali,
  usando classi correnti; dove manca un test unitario equivalente, assenza
  esplicita e rinvio alla prova di integrazione, senza riclassificarla.
- [ ] Mapping/DAO e schema/demo hanno sottosezioni proprie; mantenuti rollback
  dopo scritture, conflitti concorrenti e isolamento del DB di test con
  descrizione degli oracoli e dei limiti effettivi.
- [ ] I nove frammenti originali di testing, compresi workflow e comando
  d'esecuzione, hanno esempi attuali o scostamenti motivati. Nessuna prova
  dedicata a errore del commit/rollback viene dichiarata senza riscontro.
- [ ] Scenari funzionali e harness UI distinti dalla suite JUnit; il nome
  FullWorkflow non è presentato come prova di tutti i flussi completi.
- [ ] Risultati storici associati a fonte, versione, ambiente e data; comandi
  attuali distinti dai comandi effettivamente eseguiti in passato. Nessuna
  nuova esecuzione o percentuale di copertura inventata.
- [ ] Appendice C e rinvii restano coerenti con i casi principali ricollocati
  e le schede aggiuntive. La matrice estesa completa gli esempi nel corpo.
- [ ] Baseline dei materiali, anche non tracciati; evidenze pregresse intatte.
  Verifica esatta degli estratti, compilazione reale e ispezione visiva delle
  pagine coinvolte; estratto e risultati proposti agli autori.

## Comments

16 novembre 2026: quarto capitolo nell'ordine di lavorazione; nessun prerequisito
tecnico negli altri riallineamenti. Le evidenze esistenti permettono di
documentare le prove senza rieseguirle. Non aggiungere test applicativi per
riempire un titolo storico; nessun accesso a DB operativi, commit o invio.
