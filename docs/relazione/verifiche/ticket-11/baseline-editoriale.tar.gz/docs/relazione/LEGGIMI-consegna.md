# DriveHub — sorgenti per la revisione finale degli autori

15 novembre 2026. Relazione completa, capitoli 1–5 e appendici A–C,
con le tre tavole originali degli autori corrette e integrate.
Il pacchetto è proposto agli autori per la revisione finale: non ne attesta
l'approvazione e non autorizza invio al docente o pubblicazione.

## Compilare lo ZIP estratto

Estrarre tutto lo ZIP in una directory e aprire un terminale in quella
directory, dove si trova `main.tex`. Occorre una distribuzione LaTeX con
XeLaTeX, lingua italiana e pacchetti `geometry`, `graphicx`, `enumitem`,
`xcolor`, `listings`, `longtable`, `array`, `hyperref`, `pdfpages` e font Latin Modern.
Nel ticket 08 è stata verificata TeX Live 2025/Debian, XeTeX 0.999997,
con pacchetti Ubuntu `2025.20260124-1`.

```bash
mkdir -p build
xelatex -no-shell-escape -halt-on-error -interaction=nonstopmode -recorder -output-directory=build main.tex
xelatex -no-shell-escape -halt-on-error -interaction=nonstopmode -recorder -output-directory=build main.tex
xelatex -no-shell-escape -halt-on-error -interaction=nonstopmode -recorder -output-directory=build main.tex
```

Il risultato è `build/main.pdf`. I passaggi successivi al primo stabilizzano
indice, numeri e riferimenti; leggere gli avvisi del log. Nessun accesso a
Java, Maven, database o servizi applicativi è necessario. Tutti gli input
editoriali sono inclusi: 14 file LaTeX, 35 figure PDF con i rispettivi
35 sorgenti draw.io modificabili e 16 screenshot PNG. Le tre tavole degli
autori occupano quattro fogli A3 orizzontali (l'ER comprende la legenda);
le altre pagine restano A4. I frammenti di codice
sono incorporati nei sorgenti LaTeX.

Per modificare una tavola aprire il `.drawio` e aggiornare anche il relativo
`.drawio.pdf`, mantenendo il nome usato dal LaTeX. La compilazione non richiede
draw.io perché usa le esportazioni incluse. Le copie corrette degli autori
sono `casi-uso-autori`, `navigazione-autori` e `database-er-autori`.
Per stampare le quattro pagine A3 mantenere il formato originale o usare
il ridimensionamento del visualizzatore, tenendo conto della leggibilità.

## Provenienza e limiti

La compilazione del pacchetto estratto è stata eseguita separatamente da
quella nel repository; gli input registrati non dipendono da percorsi
editoriali esterni. Distribuzione, font ed eseguibili sono prerequisiti,
non contenuti dello ZIP. Non si garantisce identità binaria o impaginazione
identica fra versioni dei motori e dei pacchetti. Tectonic 0.17.0 era stato
usato nei ticket precedenti; non è stato nuovamente eseguito nel ticket 08.
Windows e macOS non sono stati verificati.

Le citazioni a sorgenti, ADR ed evidenze indicano percorsi nel repository
DriveHub, HEAD `61ce18ae1d4e0458b63e970b793b0b3a634a3adf`, e richiedono quel
repository per approfondire le fonti; non sono input necessari alla compilazione.
Le verifiche del precedente pacchetto restano conservate in
`docs/relazione/verifiche/ticket-08/`. L'integrazione delle tavole, i nuovi
controlli e il pacchetto corrente sono in `docs/relazione/verifiche/tavole-autori/`.
Le prove applicative citate restano storiche. I limiti su importi zero,
unicità delle identità, aggiornamenti UI dopo commit e riproduzione degli
harness storici restano dichiarati e non sono corretti da questo pacchetto.
